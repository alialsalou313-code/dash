/**
 * Skipped minification because the original files appears to be already minified.
 * Original file: /npm/@supabase/supabase-js@2.118.0/dist/umd/supabase.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
var supabase=(function(e){function t(e,t){var n={};for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&t.indexOf(r)<0&&(n[r]=e[r]);if(e!=null&&typeof Object.getOwnPropertySymbols==`function`)for(var i=0,r=Object.getOwnPropertySymbols(e);i<r.length;i++)t.indexOf(r[i])<0&&Object.prototype.propertyIsEnumerable.call(e,r[i])&&(n[r[i]]=e[r[i]]);return n}function n(e,t,n,r){function i(e){return e instanceof n?e:new n(function(t){t(e)})}return new(n||=Promise)(function(n,a){function o(e){try{c(r.next(e))}catch(e){a(e)}}function s(e){try{c(r.throw(e))}catch(e){a(e)}}function c(e){e.done?n(e.value):i(e.value).then(o,s)}c((r=r.apply(e,t||[])).next())})}let r=e=>e?(...t)=>e(...t):(...e)=>fetch(...e);var i=class extends Error{constructor(e,t=`FunctionsError`,n){super(e),this.name=t,this.context=n}toJSON(){return{name:this.name,message:this.message,context:this.context}}},a=class extends i{constructor(e){super(`Failed to send a request to the Edge Function`,`FunctionsFetchError`,e)}},o=class extends i{constructor(e){super(`Relay Error invoking the Edge Function`,`FunctionsRelayError`,e)}},s=class extends i{constructor(e){super(`Edge Function returned a non-2xx status code`,`FunctionsHttpError`,e)}},c;(function(e){e.Any=`any`,e.ApNortheast1=`ap-northeast-1`,e.ApNortheast2=`ap-northeast-2`,e.ApSouth1=`ap-south-1`,e.ApSoutheast1=`ap-southeast-1`,e.ApSoutheast2=`ap-southeast-2`,e.CaCentral1=`ca-central-1`,e.EuCentral1=`eu-central-1`,e.EuWest1=`eu-west-1`,e.EuWest2=`eu-west-2`,e.EuWest3=`eu-west-3`,e.SaEast1=`sa-east-1`,e.UsEast1=`us-east-1`,e.UsWest1=`us-west-1`,e.UsWest2=`us-west-2`})(c||={});var l=class{constructor(e,{headers:t={},customFetch:n,region:i=c.Any}={}){this.url=e,this.headers=t,this.region=i,this.fetch=r(n)}setAuth(e){this.headers.Authorization=`Bearer ${e}`}invoke(e){return n(this,arguments,void 0,function*(e,t={}){var n;let r,i,c;try{let{headers:n,method:l,body:u,signal:d,timeout:f}=t,p={},{region:m}=t;m||=this.region;let h=new URL(`${this.url}/${e}`);m&&m!==`any`&&(p[`x-region`]=m,h.searchParams.set(`forceFunctionRegion`,m));let g,ee=!!n&&Object.keys(n).some(e=>e.toLowerCase()===`content-type`);u&&!ee?typeof Blob<`u`&&u instanceof Blob||u instanceof ArrayBuffer?(p[`Content-Type`]=u.type||`application/octet-stream`,g=u):typeof u==`string`?(p[`Content-Type`]=`text/plain`,g=u):typeof FormData<`u`&&u instanceof FormData?g=u:(p[`Content-Type`]=`application/json`,g=JSON.stringify(u)):g=u&&typeof u!=`string`&&!(typeof Blob<`u`&&u instanceof Blob)&&!(u instanceof ArrayBuffer)&&!(typeof FormData<`u`&&u instanceof FormData)?JSON.stringify(u):u;let te=d;f&&(i=new AbortController,r=setTimeout(()=>i.abort(),f),d?(te=i.signal,c=()=>i.abort(),d.addEventListener(`abort`,c)):te=i.signal);let _=yield this.fetch(h.toString(),{method:l||`POST`,headers:Object.assign(Object.assign(Object.assign({},p),this.headers),n),body:g,signal:te}).catch(e=>{throw new a(e)}),ne=_.headers.get(`x-relay-error`);if(ne&&ne===`true`)throw new o(_);if(!_.ok)throw new s(_);let re=(_.headers.get(`Content-Type`)??`text/plain`).split(`;`)[0].trim().toLowerCase(),ie;return ie=re===`application/json`?yield _.json():re===`application/octet-stream`||re===`application/pdf`?yield _.blob():re===`text/event-stream`?_:re===`multipart/form-data`?yield _.formData():yield _.text(),{data:ie,error:null,response:_}}catch(e){return{data:null,error:e,response:e instanceof s||e instanceof o?e.context:void 0}}finally{r&&clearTimeout(r),c&&((n=t.signal)==null||n.removeEventListener(`abort`,c))}})}},u=class extends Error{constructor(e){super(e.message),this.name=`PostgrestError`,this.details=e.details,this.hint=e.hint,this.code=e.code}toJSON(){return{name:this.name,message:this.message,details:this.details,hint:this.hint,code:this.code}}};let d=e=>Math.min(1e3*2**e,3e4),f=[520,503],p=[`GET`,`HEAD`,`OPTIONS`];function m(e){"@babel/helpers - typeof";return m=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},m(e)}function h(e,t){if(m(e)!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t||`default`);if(m(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}function g(e){var t=h(e,`string`);return m(t)==`symbol`?t:t+``}function ee(e,t,n){return(t=g(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function te(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function _(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?te(Object(n),!0).forEach(function(t){ee(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):te(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}function ne(e,t){return new Promise(n=>{if(t?.aborted){n();return}let r=setTimeout(()=>{t?.removeEventListener(`abort`,i),n()},e);function i(){clearTimeout(r),n()}t?.addEventListener(`abort`,i)})}function re(e,t,n,r){return!(!r||n>=3||!p.includes(e)||!f.includes(t))}async function ie(e,t,n,r){let i=0;for(;;){let a=_({},n.headers);i>0&&(a[`X-Retry-Count`]=String(i));let o;try{o=await e(t,{method:n.method,headers:a,body:n.body,signal:n.signal})}catch(e){if(e?.name===`AbortError`||e?.code===`ABORT_ERR`||e?.name===`TimeoutError`&&n.signal?.aborted||!p.includes(n.method))throw e;if(r&&i<3){let e=d(i);i++,await ne(e,n.signal);continue}throw e}if(re(n.method,o.status,i,r)){let e=o.headers?.get(`Retry-After`)??null,t=e===null?d(i):Math.max(0,parseInt(e,10)||0)*1e3;await o.text(),i++,await ne(t,n.signal);continue}return o}}var ae=class{constructor(e){this.shouldThrowOnError=!1,this.retryEnabled=!0,this.method=e.method,this.url=e.url,this.headers=new Headers(e.headers),this.schema=e.schema,this.body=e.body,this.shouldThrowOnError=e.shouldThrowOnError??!1,this.signal=e.signal,this.isMaybeSingle=e.isMaybeSingle??!1,this.shouldStripNulls=e.shouldStripNulls??!1,this.urlLengthLimit=e.urlLengthLimit??8e3,this.retryEnabled=e.retry??!0,e.fetch?this.fetch=e.fetch:this.fetch=fetch}throwOnError(){return this.shouldThrowOnError=!0,this}stripNulls(){if(this.headers.get(`Accept`)===`text/csv`)throw Error(`stripNulls() cannot be used with csv()`);return this.shouldStripNulls=!0,this}setHeader(e,t){return this.headers=new Headers(this.headers),this.headers.set(e,t),this}retry(e){return this.retryEnabled=e,this}then(e,t){var n=this;if(this.schema===void 0||([`GET`,`HEAD`].includes(this.method)?this.headers.set(`Accept-Profile`,this.schema):this.headers.set(`Content-Profile`,this.schema)),this.method!==`GET`&&this.method!==`HEAD`&&this.headers.set(`Content-Type`,`application/json`),this.shouldStripNulls){let e=this.headers.get(`Accept`);e===`application/vnd.pgrst.object+json`?this.headers.set(`Accept`,`application/vnd.pgrst.object+json;nulls=stripped`):(!e||e===`application/json`)&&this.headers.set(`Accept`,`application/vnd.pgrst.array+json;nulls=stripped`)}let r=this.fetch,i=(async()=>{let e={};n.headers.forEach((t,n)=>{e[n]=t});let t=await ie(r,n.url.toString(),{method:n.method,headers:e,body:JSON.stringify(n.body,(e,t)=>typeof t==`bigint`?t.toString():t),signal:n.signal},n.retryEnabled);return await n.processResponse(t)})();return this.shouldThrowOnError||(i=i.catch(e=>{let t=``,n=``,r=``,i=e?.cause;if(i){let n=i?.message??``,r=i?.code??``;t=`${e?.name??`FetchError`}: ${e?.message}`,t+=`\n\nCaused by: ${i?.name??`Error`}: ${n}`,r&&(t+=` (${r})`),i?.stack&&(t+=`\n${i.stack}`)}else t=e?.stack??``;let a=this.url.toString().length;return e?.name===`AbortError`||e?.code===`ABORT_ERR`?(r=``,n=`Request was aborted (timeout or manual cancellation)`,a>this.urlLengthLimit&&(n+=`. Note: Your request URL is ${a} characters, which may exceed server limits. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [many IDs])), consider using an RPC function to pass values server-side.`)):(i?.name===`HeadersOverflowError`||i?.code===`UND_ERR_HEADERS_OVERFLOW`)&&(r=``,n=`HTTP headers exceeded server limits (typically 16KB)`,a>this.urlLengthLimit&&(n+=`. Your request URL is ${a} characters. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [200+ IDs])), consider using an RPC function instead.`)),{success:!1,error:{message:`${e?.name??`FetchError`}: ${e?.message}`,details:t,hint:n,code:r},data:null,count:null,status:0,statusText:``}})),i.then(e,t)}async processResponse(e){var t=this;let n=null,r=null,i=null,a=e.status,o=e.statusText;if(e.ok){if(t.method!==`HEAD`){let i=await e.text();if(i!==``)if(t.headers.get(`Accept`)===`text/csv`)r=i;else if(t.headers.get(`Accept`)&&t.headers.get(`Accept`)?.includes(`application/vnd.pgrst.plan+text`))r=i;else try{r=JSON.parse(i)}catch{if(n={message:i},r=null,t.shouldThrowOnError)throw new u({message:i,details:``,hint:``,code:``})}}let s=t.headers.get(`Prefer`)?.match(/count=(exact|planned|estimated)/),c=e.headers.get(`content-range`)?.split(`/`);if(s&&c&&c.length>1&&(i=parseInt(c[1])),t.isMaybeSingle&&Array.isArray(r))if(r.length>1){if(n={code:`PGRST116`,details:`Results contain ${r.length} rows, application/vnd.pgrst.object+json requires 1 row`,hint:null,message:`JSON object requested, multiple (or no) rows returned`},r=null,i=null,a=406,o=`Not Acceptable`,t.shouldThrowOnError)throw new u(_(_({},n),{},{hint:n.hint??``}))}else r=r.length===1?r[0]:null}else{let i=await e.text();try{n=JSON.parse(i),Array.isArray(n)&&e.status===404&&(r=[],n=null,a=200,o=`OK`)}catch{e.status===404&&i===``?(a=204,o=`No Content`):n={message:i}}if(n&&t.shouldThrowOnError)throw new u(n)}return{success:n===null,error:n,data:r,count:i,status:a,statusText:o}}returns(){return this}overrideTypes(){return this}},oe=class extends ae{throwOnError(){return super.throwOnError()}select(e){let t=!1,n=(e??`*`).split(``).map(e=>/\s/.test(e)&&!t?``:(e===`"`&&(t=!t),e)).join(``);return this.url.searchParams.set(`select`,n),this.headers.append(`Prefer`,`return=representation`),this}order(e,{ascending:t=!0,nullsFirst:n,foreignTable:r,referencedTable:i=r}={}){let a=i?`${i}.order`:`order`,o=this.url.searchParams.get(a);return this.url.searchParams.set(a,`${o?`${o},`:``}${e}.${t?`asc`:`desc`}${n===void 0?``:n?`.nullsfirst`:`.nullslast`}`),this}limit(e,{foreignTable:t,referencedTable:n=t}={}){let r=n===void 0?`limit`:`${n}.limit`;return this.url.searchParams.set(r,`${e}`),this}range(e,t,{foreignTable:n,referencedTable:r=n}={}){let i=r===void 0?`offset`:`${r}.offset`,a=r===void 0?`limit`:`${r}.limit`;return this.url.searchParams.set(i,`${e}`),this.url.searchParams.set(a,`${t-e+1}`),this}abortSignal(e){return this.signal=e,this}single(){return this.headers.set(`Accept`,`application/vnd.pgrst.object+json`),this}maybeSingle(){return this.isMaybeSingle=!0,this}csv(){return this.headers.set(`Accept`,`text/csv`),this}geojson(){return this.headers.set(`Accept`,`application/geo+json`),this}explain({analyze:e=!1,verbose:t=!1,settings:n=!1,buffers:r=!1,wal:i=!1,format:a=`text`}={}){let o=[e?`analyze`:null,t?`verbose`:null,n?`settings`:null,r?`buffers`:null,i?`wal`:null].filter(Boolean).join(`|`),s=this.headers.get(`Accept`)??`application/json`;return this.headers.set(`Accept`,`application/vnd.pgrst.plan+${a}; for="${s}"; options=${o};`),this}rollback(){return this.headers.append(`Prefer`,`tx=rollback`),this}returns(){return this}maxAffected(e){return this.headers.append(`Prefer`,`handling=strict`),this.headers.append(`Prefer`,`max-affected=${e}`),this}};let se=RegExp(`[,()]`);var ce=class extends oe{throwOnError(){return super.throwOnError()}eq(e,t){return this.url.searchParams.append(e,`eq.${t}`),this}neq(e,t){return this.url.searchParams.append(e,`neq.${t}`),this}gt(e,t){return this.url.searchParams.append(e,`gt.${t}`),this}gte(e,t){return this.url.searchParams.append(e,`gte.${t}`),this}lt(e,t){return this.url.searchParams.append(e,`lt.${t}`),this}lte(e,t){return this.url.searchParams.append(e,`lte.${t}`),this}like(e,t){return this.url.searchParams.append(e,`like.${t}`),this}likeAllOf(e,t){return this.url.searchParams.append(e,`like(all).{${t.join(`,`)}}`),this}likeAnyOf(e,t){return this.url.searchParams.append(e,`like(any).{${t.join(`,`)}}`),this}ilike(e,t){return this.url.searchParams.append(e,`ilike.${t}`),this}ilikeAllOf(e,t){return this.url.searchParams.append(e,`ilike(all).{${t.join(`,`)}}`),this}ilikeAnyOf(e,t){return this.url.searchParams.append(e,`ilike(any).{${t.join(`,`)}}`),this}regexMatch(e,t){return this.url.searchParams.append(e,`match.${t}`),this}regexIMatch(e,t){return this.url.searchParams.append(e,`imatch.${t}`),this}is(e,t){return this.url.searchParams.append(e,`is.${t}`),this}isDistinct(e,t){return this.url.searchParams.append(e,`isdistinct.${t}`),this}in(e,t){let n=Array.from(new Set(t)).map(e=>typeof e==`string`&&se.test(e)?`"${e}"`:`${e}`).join(`,`);return this.url.searchParams.append(e,`in.(${n})`),this}notIn(e,t){let n=Array.from(new Set(t)).map(e=>typeof e==`string`&&se.test(e)?`"${e}"`:`${e}`).join(`,`);return this.url.searchParams.append(e,`not.in.(${n})`),this}contains(e,t){return typeof t==`string`?this.url.searchParams.append(e,`cs.${t}`):Array.isArray(t)?this.url.searchParams.append(e,`cs.{${t.join(`,`)}}`):this.url.searchParams.append(e,`cs.${JSON.stringify(t)}`),this}containedBy(e,t){return typeof t==`string`?this.url.searchParams.append(e,`cd.${t}`):Array.isArray(t)?this.url.searchParams.append(e,`cd.{${t.join(`,`)}}`):this.url.searchParams.append(e,`cd.${JSON.stringify(t)}`),this}rangeGt(e,t){return this.url.searchParams.append(e,`sr.${t}`),this}rangeGte(e,t){return this.url.searchParams.append(e,`nxl.${t}`),this}rangeLt(e,t){return this.url.searchParams.append(e,`sl.${t}`),this}rangeLte(e,t){return this.url.searchParams.append(e,`nxr.${t}`),this}rangeAdjacent(e,t){return this.url.searchParams.append(e,`adj.${t}`),this}overlaps(e,t){return typeof t==`string`?this.url.searchParams.append(e,`ov.${t}`):this.url.searchParams.append(e,`ov.{${t.join(`,`)}}`),this}textSearch(e,t,{config:n,type:r}={}){let i=``;r===`plain`?i=`pl`:r===`phrase`?i=`ph`:r===`websearch`&&(i=`w`);let a=n===void 0?``:`(${n})`;return this.url.searchParams.append(e,`${i}fts${a}.${t}`),this}match(e){return Object.entries(e).filter(([e,t])=>t!==void 0).forEach(([e,t])=>{this.url.searchParams.append(e,`eq.${t}`)}),this}not(e,t,n){return this.url.searchParams.append(e,`not.${t}.${n}`),this}or(e,{foreignTable:t,referencedTable:n=t}={}){let r=n?`${n}.or`:`or`;return this.url.searchParams.append(r,`(${e})`),this}filter(e,t,n){return this.url.searchParams.append(e,`${t}.${n}`),this}},le=class{constructor(e,{headers:t={},schema:n,fetch:r,urlLengthLimit:i=8e3,retry:a}){this.url=e,this.headers=new Headers(t),this.schema=n,this.fetch=r,this.urlLengthLimit=i,this.retry=a}cloneRequestState(){return{url:new URL(this.url.toString()),headers:new Headers(this.headers)}}select(e,t){let{head:n=!1,count:r}=t??{},i=n?`HEAD`:`GET`,a=!1,o=(e??`*`).split(``).map(e=>/\s/.test(e)&&!a?``:(e===`"`&&(a=!a),e)).join(``),{url:s,headers:c}=this.cloneRequestState();return s.searchParams.set(`select`,o),r&&c.append(`Prefer`,`count=${r}`),new ce({method:i,url:s,headers:c,schema:this.schema,fetch:this.fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}insert(e,{count:t,defaultToNull:n=!0}={}){let{url:r,headers:i}=this.cloneRequestState();if(t&&i.append(`Prefer`,`count=${t}`),n||i.append(`Prefer`,`missing=default`),Array.isArray(e)){let t=e.reduce((e,t)=>e.concat(Object.keys(t)),[]);if(t.length>0){let e=[...new Set(t)].map(e=>`"${e}"`);r.searchParams.set(`columns`,e.join(`,`))}}return new ce({method:`POST`,url:r,headers:i,schema:this.schema,body:e,fetch:this.fetch??fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}upsert(e,{onConflict:t,ignoreDuplicates:n=!1,count:r,defaultToNull:i=!0}={}){let{url:a,headers:o}=this.cloneRequestState();if(o.append(`Prefer`,`resolution=${n?`ignore`:`merge`}-duplicates`),t!==void 0&&a.searchParams.set(`on_conflict`,t),r&&o.append(`Prefer`,`count=${r}`),i||o.append(`Prefer`,`missing=default`),Array.isArray(e)){let t=e.reduce((e,t)=>e.concat(Object.keys(t)),[]);if(t.length>0){let e=[...new Set(t)].map(e=>`"${e}"`);a.searchParams.set(`columns`,e.join(`,`))}}return new ce({method:`POST`,url:a,headers:o,schema:this.schema,body:e,fetch:this.fetch??fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}update(e,{count:t}={}){let{url:n,headers:r}=this.cloneRequestState();return t&&r.append(`Prefer`,`count=${t}`),new ce({method:`PATCH`,url:n,headers:r,schema:this.schema,body:e,fetch:this.fetch??fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}delete({count:e}={}){let{url:t,headers:n}=this.cloneRequestState();return e&&n.append(`Prefer`,`count=${e}`),new ce({method:`DELETE`,url:t,headers:n,schema:this.schema,fetch:this.fetch??fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}};function ue(e,t){try{let t=JSON.parse(e);if(t&&typeof t==`object`&&!Array.isArray(t))return new u({message:String(t.message??e),details:t.details??``,hint:t.hint??``,code:t.code??``})}catch{}return new u({message:e||t,details:``,hint:``,code:``})}function de(e,t,n){let r=e;return{success:!1,error:new u({message:`${r?.name??`FetchError`}: ${r?.message}`,details:``,hint:``,code:``}),data:null,count:null,status:t,statusText:n}}var fe=class e{constructor(e,{headers:t={},schema:n,fetch:r,timeout:i,urlLengthLimit:a=8e3,retry:o}={}){this.url=e,this.headers=new Headers(t),this.schemaName=n,this.urlLengthLimit=a;let s=r??globalThis.fetch;i!==void 0&&i>0?this.fetch=(e,t)=>{let n=new AbortController,r=setTimeout(()=>n.abort(),i),a=t?.signal;if(a){if(a.aborted)return clearTimeout(r),s(e,t);let i=()=>{clearTimeout(r),n.abort()};return a.addEventListener(`abort`,i,{once:!0}),s(e,_(_({},t),{},{signal:n.signal})).finally(()=>{clearTimeout(r),a.removeEventListener(`abort`,i)})}return s(e,_(_({},t),{},{signal:n.signal})).finally(()=>clearTimeout(r))}:this.fetch=s,this.retry=o}from(e){if(!e||typeof e!=`string`||e.trim()===``)throw Error(`Invalid relation name: relation must be a non-empty string.`);return new le(new URL(`${this.url}/${e}`),{headers:new Headers(this.headers),schema:this.schemaName,fetch:this.fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}schema(t){return new e(this.url,{headers:this.headers,schema:t,fetch:this.fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}async getOpenApiSpec(){var e=this;let t=new Headers(e.headers);t.set(`Accept`,`application/openapi+json`),e.schemaName&&t.set(`Accept-Profile`,e.schemaName);let n={};t.forEach((e,t)=>{n[t]=e});let r=e.fetch??globalThis.fetch,i;try{i=await ie(r,`${e.url}/`,{method:`GET`,headers:n},e.retry??!0)}catch(e){return de(e,0,``)}let a;try{a=await i.text()}catch(e){return de(e,i.status,i.statusText)}if(i.ok)try{return{success:!0,error:null,data:JSON.parse(a),count:null,status:i.status,statusText:i.statusText}}catch{}return{success:!1,error:ue(a,i.statusText),data:null,count:null,status:i.status,statusText:i.statusText}}rpc(e,t={},{head:n=!1,get:r=!1,count:i}={}){let a,o=new URL(`${this.url}/rpc/${e}`),s,c=e=>typeof e==`object`&&!!e&&(!Array.isArray(e)||e.some(c)),l=n&&Object.values(t).some(c);l?(a=`POST`,s=t):n||r?(a=n?`HEAD`:`GET`,Object.entries(t).filter(([e,t])=>t!==void 0).map(([e,t])=>[e,Array.isArray(t)?`{${t.join(`,`)}}`:`${t}`]).forEach(([e,t])=>{o.searchParams.append(e,t)})):(a=`POST`,s=t);let u=new Headers(this.headers);return l?u.set(`Prefer`,i?`count=${i},return=minimal`:`return=minimal`):i&&u.set(`Prefer`,`count=${i}`),new ce({method:a,url:o,headers:u,schema:this.schemaName,body:s,fetch:this.fetch??fetch,urlLengthLimit:this.urlLengthLimit,retry:this.retry})}},pe=class{constructor(){}static detectEnvironment(){if(typeof WebSocket<`u`)return{type:`native`,wsConstructor:WebSocket};let e=globalThis;if(typeof globalThis<`u`&&e.WebSocket!==void 0)return{type:`native`,wsConstructor:e.WebSocket};let t=typeof global<`u`?global:void 0;if(t&&t.WebSocket!==void 0)return{type:`native`,wsConstructor:t.WebSocket};if(typeof globalThis<`u`&&e.WebSocketPair!==void 0&&globalThis.WebSocket===void 0)return{type:`cloudflare`,error:`Cloudflare Workers detected. WebSocket clients are not supported in Cloudflare Workers.`,workaround:`Use Cloudflare Workers WebSocket API for server-side WebSocket handling, or deploy to a different runtime.`};if(typeof globalThis<`u`&&e.EdgeRuntime||typeof navigator<`u`&&navigator.userAgent?.includes(`Vercel-Edge`))return{type:`unsupported`,error:`Edge runtime detected (Vercel Edge/Netlify Edge). WebSockets are not supported in edge functions.`,workaround:`Use serverless functions or a different deployment target for WebSocket functionality.`};let n=globalThis.process;if(n){let e=n.versions;if(e&&e.node)return{type:`unsupported`,error:`Node.js detected but native WebSocket not found.`,workaround:`Ensure you are running Node.js 22+ or provide a WebSocket implementation via the transport option.`}}return{type:`unsupported`,error:`Unknown JavaScript runtime without WebSocket support.`,workaround:`Ensure you're running in a supported environment (browser, Node.js, Deno) or provide a custom WebSocket implementation.`}}static getWebSocketConstructor(){let e=this.detectEnvironment();if(e.wsConstructor)return e.wsConstructor;let t=e.error||`WebSocket not supported in this environment.`;throw e.workaround&&(t+=`\n\nSuggested solution: ${e.workaround}`),Error(t)}static isWebSocketSupported(){try{return this.detectEnvironment().type===`native`}catch{return!1}}};let v={closed:`closed`,errored:`errored`,joined:`joined`,joining:`joining`,leaving:`leaving`},me={close:`phx_close`,error:`phx_error`,join:`phx_join`,reply:`phx_reply`,leave:`phx_leave`,access_token:`access_token`},he={connecting:`connecting`,open:`open`,closing:`closing`,closed:`closed`};var ge=class{constructor(e){this.HEADER_LENGTH=1,this.USER_BROADCAST_PUSH_META_LENGTH=6,this.KINDS={userBroadcastPush:3,userBroadcast:4},this.BINARY_ENCODING=0,this.JSON_ENCODING=1,this.BROADCAST_EVENT=`broadcast`,this.allowedMetadataKeys=[],this.allowedMetadataKeys=e??[]}encode(e,t){if(e.event===this.BROADCAST_EVENT&&!(e.payload instanceof ArrayBuffer)&&typeof e.payload.event==`string`)return t(this._binaryEncodeUserBroadcastPush(e));let n=[e.join_ref,e.ref,e.topic,e.event,e.payload];return t(JSON.stringify(n))}_binaryEncodeUserBroadcastPush(e){return this._isArrayBuffer(e.payload?.payload)?this._encodeBinaryUserBroadcastPush(e):this._encodeJsonUserBroadcastPush(e)}_encodeBinaryUserBroadcastPush(e){let t=e.payload?.payload??new ArrayBuffer(0);return this._encodeUserBroadcastPush(e,this.BINARY_ENCODING,t)}_encodeJsonUserBroadcastPush(e){let t=e.payload?.payload??{},n=new TextEncoder().encode(JSON.stringify(t)).buffer;return this._encodeUserBroadcastPush(e,this.JSON_ENCODING,n)}_encodeUserBroadcastPush(e,t,n){let r=new TextEncoder,i=r.encode(e.topic),a=r.encode(e.ref??``),o=r.encode(e.join_ref??``),s=r.encode(e.payload.event),c=this.allowedMetadataKeys?this._pick(e.payload,this.allowedMetadataKeys):{},l=r.encode(Object.keys(c).length===0?``:JSON.stringify(c));if(o.length>255)throw Error(`joinRef length ${o.length} exceeds maximum of 255`);if(a.length>255)throw Error(`ref length ${a.length} exceeds maximum of 255`);if(i.length>255)throw Error(`topic length ${i.length} exceeds maximum of 255`);if(s.length>255)throw Error(`userEvent length ${s.length} exceeds maximum of 255`);if(l.length>255)throw Error(`metadata length ${l.length} exceeds maximum of 255`);let u=this.USER_BROADCAST_PUSH_META_LENGTH+o.length+a.length+i.length+s.length+l.length,d=new ArrayBuffer(this.HEADER_LENGTH+u),f=new DataView(d),p=new Uint8Array(d),m=0;f.setUint8(m++,this.KINDS.userBroadcastPush),f.setUint8(m++,o.length),f.setUint8(m++,a.length),f.setUint8(m++,i.length),f.setUint8(m++,s.length),f.setUint8(m++,l.length),f.setUint8(m++,t),p.set(o,m),m+=o.length,p.set(a,m),m+=a.length,p.set(i,m),m+=i.length,p.set(s,m),m+=s.length,p.set(l,m),m+=l.length;var h=new Uint8Array(d.byteLength+n.byteLength);return h.set(new Uint8Array(d),0),h.set(new Uint8Array(n),d.byteLength),h.buffer}decode(e,t){if(this._isArrayBuffer(e))return t(this._binaryDecode(e));if(typeof e==`string`){let[n,r,i,a,o]=JSON.parse(e);return t({join_ref:n,ref:r,topic:i,event:a,payload:o})}return t({})}_binaryDecode(e){let t=new DataView(e),n=t.getUint8(0),r=new TextDecoder;switch(n){case this.KINDS.userBroadcast:return this._decodeUserBroadcast(e,t,r)}}_decodeUserBroadcast(e,t,n){let r=t.getUint8(1),i=t.getUint8(2),a=t.getUint8(3),o=t.getUint8(4),s=this.HEADER_LENGTH+4,c=n.decode(e.slice(s,s+r));s+=r;let l=n.decode(e.slice(s,s+i));s+=i;let u=n.decode(e.slice(s,s+a));s+=a;let d=e.slice(s,e.byteLength),f=o===this.JSON_ENCODING?JSON.parse(n.decode(d)):d,p={type:this.BROADCAST_EVENT,event:l,payload:f};return a>0&&(p.meta=JSON.parse(u)),{join_ref:null,ref:null,topic:c,event:this.BROADCAST_EVENT,payload:p}}_isArrayBuffer(e){return e instanceof ArrayBuffer||e?.constructor?.name===`ArrayBuffer`}_pick(e,t){return!e||typeof e!=`object`?{}:Object.fromEntries(Object.entries(e).filter(([e])=>t.includes(e)))}},y;(function(e){e.abstime=`abstime`,e.bool=`bool`,e.date=`date`,e.daterange=`daterange`,e.float4=`float4`,e.float8=`float8`,e.int2=`int2`,e.int4=`int4`,e.int4range=`int4range`,e.int8=`int8`,e.int8range=`int8range`,e.json=`json`,e.jsonb=`jsonb`,e.money=`money`,e.numeric=`numeric`,e.oid=`oid`,e.reltime=`reltime`,e.text=`text`,e.time=`time`,e.timestamp=`timestamp`,e.timestamptz=`timestamptz`,e.timetz=`timetz`,e.tsrange=`tsrange`,e.tstzrange=`tstzrange`})(y||={});let _e=(e,t,n={})=>{let r=n.skipTypes??[];return t?Object.keys(t).reduce((n,i)=>(n[i]=ve(i,e,t,r),n),{}):{}},ve=(e,t,n,r)=>{let i=t.find(t=>t.name===e)?.type,a=n[e];return i&&!r.includes(i)?ye(i,a):be(a)},ye=(e,t)=>{if(e.charAt(0)===`_`)return we(t,e.slice(1,e.length));switch(e){case y.bool:return xe(t);case y.float4:case y.float8:case y.int2:case y.int4:case y.int8:case y.numeric:case y.oid:return Se(t);case y.json:case y.jsonb:return Ce(t);case y.timestamp:return Te(t);case y.abstime:case y.date:case y.daterange:case y.int4range:case y.int8range:case y.money:case y.reltime:case y.text:case y.time:case y.timestamptz:case y.timetz:case y.tsrange:case y.tstzrange:return be(t);default:return be(t)}},be=e=>e,xe=e=>{switch(e){case`t`:return!0;case`f`:return!1;default:return e}},Se=e=>{if(typeof e==`string`){let t=parseFloat(e);if(!Number.isNaN(t))return t}return e},Ce=e=>{if(typeof e==`string`)try{return JSON.parse(e)}catch{return e}return e},we=(e,t)=>{if(typeof e!=`string`)return e;let n=e.length-1,r=e[n];if(e[0]===`{`&&r===`}`){let r,i=e.slice(1,n);try{r=JSON.parse(`[`+i+`]`)}catch{r=i?i.split(`,`):[]}return r.map(e=>ye(t,e))}return e},Te=e=>typeof e==`string`?e.replace(` `,`T`):e,Ee=e=>{let t=new URL(e);return t.protocol=t.protocol.replace(/^ws/i,`http`),t.pathname=t.pathname.replace(/\/+$/,``).replace(/\/socket\/websocket$/i,``).replace(/\/socket$/i,``).replace(/\/websocket$/i,``),t.pathname===``||t.pathname===`/`?t.pathname=`/api/broadcast`:t.pathname+=`/api/broadcast`,t.href};var b=e=>typeof e==`function`?e:function(){return e},De=typeof self<`u`?self:null,Oe=typeof window<`u`?window:null,x=De||Oe||globalThis,ke=`2.0.0`,Ae=1e4,je=1e3,Me=100,S={connecting:0,open:1,closing:2,closed:3},C={closed:`closed`,errored:`errored`,joined:`joined`,joining:`joining`,leaving:`leaving`},w={close:`phx_close`,error:`phx_error`,join:`phx_join`,reply:`phx_reply`,leave:`phx_leave`},Ne={longpoll:`longpoll`,websocket:`websocket`},Pe={complete:4},Fe=`base64url.bearer.phx.`,Ie=class{constructor(e,t,n,r){this.channel=e,this.event=t,this.payload=n||function(){return{}},this.receivedResp=null,this.timeout=r,this.timeoutTimer=null,this.recHooks=[],this.sent=!1,this.ref=void 0}resend(e){this.timeout=e,this.reset(),this.send()}send(){this.hasReceived(`timeout`)||(this.startTimeout(),this.sent=!0,this.channel.socket.push({topic:this.channel.topic,event:this.event,payload:this.payload(),ref:this.ref,join_ref:this.channel.joinRef()}))}receive(e,t){return this.hasReceived(e)&&t(this.receivedResp.response),this.recHooks.push({status:e,callback:t}),this}reset(){this.cancelRefEvent(),this.ref=null,this.refEvent=null,this.receivedResp=null,this.sent=!1}destroy(){this.cancelRefEvent(),this.cancelTimeout()}matchReceive({status:e,response:t,_ref:n}){this.recHooks.filter(t=>t.status===e).forEach(e=>e.callback(t))}cancelRefEvent(){this.refEvent&&this.channel.off(this.refEvent)}cancelTimeout(){clearTimeout(this.timeoutTimer),this.timeoutTimer=null}startTimeout(){this.timeoutTimer&&this.cancelTimeout(),this.ref=this.channel.socket.makeRef(),this.refEvent=this.channel.replyEventName(this.ref),this.channel.on(this.refEvent,e=>{this.cancelRefEvent(),this.cancelTimeout(),this.receivedResp=e,this.matchReceive(e)}),this.timeoutTimer=setTimeout(()=>{this.trigger(`timeout`,{})},this.timeout)}hasReceived(e){return this.receivedResp&&this.receivedResp.status===e}trigger(e,t){this.channel.trigger(this.refEvent,{status:e,response:t})}},Le=class{constructor(e,t){this.callback=e,this.timerCalc=t,this.timer=void 0,this.tries=0}reset(){this.tries=0,clearTimeout(this.timer)}scheduleTimeout(){clearTimeout(this.timer),this.timer=setTimeout(()=>{this.tries+=1,this.callback()},this.timerCalc(this.tries+1))}},Re=class{constructor(e,t,n){this.state=C.closed,this.topic=e,this.params=b(t||{}),this.socket=n,this.bindings=[],this.bindingRef=0,this.timeout=this.socket.timeout,this.joinedOnce=!1,this.joinPush=new Ie(this,w.join,this.params,this.timeout),this.pushBuffer=[],this.stateChangeRefs=[],this.rejoinTimer=new Le(()=>{this.socket.isConnected()&&this.rejoin()},this.socket.rejoinAfterMs),this.stateChangeRefs.push(this.socket.onError(()=>this.rejoinTimer.reset())),this.stateChangeRefs.push(this.socket.onOpen(()=>{this.rejoinTimer.reset(),this.isErrored()&&this.rejoin()})),this.joinPush.receive(`ok`,()=>{this.state=C.joined,this.rejoinTimer.reset(),this.pushBuffer.forEach(e=>e.send()),this.pushBuffer=[]}),this.joinPush.receive(`error`,e=>{this.state=C.errored,this.socket.hasLogger()&&this.socket.log(`channel`,`error ${this.topic}`,e),this.socket.isConnected()&&this.rejoinTimer.scheduleTimeout()}),this.onClose(()=>{this.rejoinTimer.reset(),this.socket.hasLogger()&&this.socket.log(`channel`,`close ${this.topic}`),this.state=C.closed,this.socket.remove(this)}),this.onError(e=>{this.socket.hasLogger()&&this.socket.log(`channel`,`error ${this.topic}`,e),this.isJoining()&&this.joinPush.reset(),this.state=C.errored,this.socket.isConnected()&&this.rejoinTimer.scheduleTimeout()}),this.joinPush.receive(`timeout`,()=>{this.socket.hasLogger()&&this.socket.log(`channel`,`timeout ${this.topic}`,this.joinPush.timeout),new Ie(this,w.leave,b({}),this.timeout).send(),this.state=C.errored,this.joinPush.reset(),this.socket.isConnected()&&this.rejoinTimer.scheduleTimeout()}),this.on(w.reply,(e,t)=>{this.trigger(this.replyEventName(t),e)})}join(e=this.timeout){if(this.joinedOnce)throw Error(`tried to join multiple times. 'join' can only be called a single time per channel instance`);return this.timeout=e,this.joinedOnce=!0,this.rejoin(),this.joinPush}teardown(){this.pushBuffer.forEach(e=>e.destroy()),this.pushBuffer=[],this.rejoinTimer.reset(),this.joinPush.destroy(),this.state=C.closed,this.bindings=[]}onClose(e){this.on(w.close,e)}onError(e){return this.on(w.error,t=>e(t))}on(e,t){let n=this.bindingRef++;return this.bindings.push({event:e,ref:n,callback:t}),n}off(e,t){this.bindings=this.bindings.filter(n=>!(n.event===e&&(t===void 0||t===n.ref)))}canPush(){return this.socket.isConnected()&&this.isJoined()}push(e,t,n=this.timeout){if(t||={},!this.joinedOnce)throw Error(`tried to push '${e}' to '${this.topic}' before joining. Use channel.join() before pushing events`);let r=new Ie(this,e,function(){return t},n);return this.canPush()?r.send():(r.startTimeout(),this.pushBuffer.push(r)),r}leave(e=this.timeout){this.rejoinTimer.reset(),this.joinPush.cancelTimeout(),this.state=C.leaving;let t=()=>{this.socket.hasLogger()&&this.socket.log(`channel`,`leave ${this.topic}`),this.trigger(w.close,`leave`)},n=new Ie(this,w.leave,b({}),e);return n.receive(`ok`,()=>t()).receive(`timeout`,()=>t()),n.send(),this.canPush()||n.trigger(`ok`,{}),n}onMessage(e,t,n){return t}filterBindings(e,t,n){return!0}isMember(e,t,n,r){return this.topic===e?r&&r!==this.joinRef()?(this.socket.hasLogger()&&this.socket.log(`channel`,`dropping outdated message`,{topic:e,event:t,payload:n,joinRef:r}),!1):!0:!1}joinRef(){return this.joinPush.ref}rejoin(e=this.timeout){this.isLeaving()||(this.socket.leaveOpenTopic(this.topic),this.state=C.joining,this.joinPush.resend(e))}trigger(e,t,n,r){let i=this.onMessage(e,t,n,r);if(t&&!i)throw Error(`channel onMessage callbacks must return the payload, modified or unmodified`);let a=this.bindings.filter(r=>r.event===e&&this.filterBindings(r,t,n));for(let e=0;e<a.length;e++)a[e].callback(i,n,r||this.joinRef())}replyEventName(e){return`chan_reply_${e}`}isClosed(){return this.state===C.closed}isErrored(){return this.state===C.errored}isJoined(){return this.state===C.joined}isJoining(){return this.state===C.joining}isLeaving(){return this.state===C.leaving}},ze=class{static request(e,t,n,r,i,a,o){if(x.XDomainRequest){let n=new x.XDomainRequest;return this.xdomainRequest(n,e,t,r,i,a,o)}else if(x.XMLHttpRequest){let s=new x.XMLHttpRequest;return this.xhrRequest(s,e,t,n,r,i,a,o)}else if(x.fetch&&x.AbortController)return this.fetchRequest(e,t,n,r,i,a,o);else throw Error(`No suitable XMLHttpRequest implementation found`)}static fetchRequest(e,t,n,r,i,a,o){let s={method:e,headers:n,body:r},c=null;return i&&(c=new AbortController,setTimeout(()=>c.abort(),i),s.signal=c.signal),x.fetch(t,s).then(e=>e.text()).then(e=>this.parseJSON(e)).then(e=>o&&o(e)).catch(e=>{e.name===`AbortError`&&a?a():o&&o(null)}),c}static xdomainRequest(e,t,n,r,i,a,o){return e.timeout=i,e.open(t,n),e.onload=()=>{let t=this.parseJSON(e.responseText);o&&o(t)},a&&(e.ontimeout=a),e.onprogress=()=>{},e.send(r),e}static xhrRequest(e,t,n,r,i,a,o,s){e.open(t,n,!0),e.timeout=a;for(let[t,n]of Object.entries(r))e.setRequestHeader(t,n);return e.onerror=()=>s&&s(null),e.onreadystatechange=()=>{e.readyState===Pe.complete&&s&&s(this.parseJSON(e.responseText))},o&&(e.ontimeout=o),e.send(i),e}static parseJSON(e){if(!e||e===``)return null;try{return JSON.parse(e)}catch{return console&&console.log(`failed to parse JSON response`,e),null}}static serialize(e,t){let n=[];for(var r in e){if(!Object.prototype.hasOwnProperty.call(e,r))continue;let i=t?`${t}[${r}]`:r,a=e[r];typeof a==`object`?n.push(this.serialize(a,i)):n.push(encodeURIComponent(i)+`=`+encodeURIComponent(a))}return n.join(`&`)}static appendParams(e,t){return Object.keys(t).length===0?e:`${e}${e.match(/\?/)?`&`:`?`}${this.serialize(t)}`}},Be=e=>{let t=``,n=new Uint8Array(e),r=n.byteLength;for(let e=0;e<r;e++)t+=String.fromCharCode(n[e]);return btoa(t)},Ve=class{constructor(e,t){t&&t.length===2&&t[1].startsWith(Fe)&&(this.authToken=atob(t[1].slice(Fe.length))),this.endPoint=null,this.token=null,this.skipHeartbeat=!0,this.reqs=new Set,this.awaitingBatchAck=!1,this.currentBatch=null,this.currentBatchTimer=null,this.batchBuffer=[],this.onopen=function(){},this.onerror=function(){},this.onmessage=function(){},this.onclose=function(){},this.pollEndpoint=this.normalizeEndpoint(e),this.readyState=S.connecting,setTimeout(()=>this.poll(),0)}normalizeEndpoint(e){return e.replace(`ws://`,`http://`).replace(`wss://`,`https://`).replace(RegExp(`(.*)/`+Ne.websocket),`$1/`+Ne.longpoll)}endpointURL(){return ze.appendParams(this.pollEndpoint,{token:this.token})}closeAndRetry(e,t,n){this.close(e,t,n),this.readyState=S.connecting}ontimeout(){this.onerror(`timeout`),this.closeAndRetry(1005,`timeout`,!1)}isActive(){return this.readyState===S.open||this.readyState===S.connecting}poll(){let e={Accept:`application/json`};this.authToken&&(e[`X-Phoenix-AuthToken`]=this.authToken),this.ajax(`GET`,e,null,()=>this.ontimeout(),e=>{if(e){var{status:t,token:n,messages:r}=e;if(t===410&&this.token!==null){this.onerror(410),this.closeAndRetry(3410,`session_gone`,!1);return}this.token=n}else t=0;switch(t){case 200:r.forEach(e=>{setTimeout(()=>this.onmessage({data:e}),0)}),this.poll();break;case 204:this.poll();break;case 410:this.readyState=S.open,this.onopen({}),this.poll();break;case 403:this.onerror(403),this.close(1008,`forbidden`,!1);break;case 0:case 500:this.onerror(500),this.closeAndRetry(1011,`internal server error`,500);break;default:throw Error(`unhandled poll status ${t}`)}})}send(e){typeof e!=`string`&&(e=Be(e)),this.currentBatch?this.currentBatch.push(e):this.awaitingBatchAck?this.batchBuffer.push(e):(this.currentBatch=[e],this.currentBatchTimer=setTimeout(()=>{this.batchSend(this.currentBatch),this.currentBatch=null},0))}batchSend(e,t=0){this.awaitingBatchAck=!0;let n=t+Me,r=e.slice(t,n);this.ajax(`POST`,{"Content-Type":`application/x-ndjson`},r.join(`
`),()=>this.onerror(`timeout`),t=>{!t||t.status!==200?(this.awaitingBatchAck=!1,this.onerror(t&&t.status),this.closeAndRetry(1011,`internal server error`,!1)):n<e.length?this.batchSend(e,n):this.batchBuffer.length>0?(this.batchSend(this.batchBuffer),this.batchBuffer=[]):this.awaitingBatchAck=!1})}close(e,t,n){for(let e of this.reqs)e.abort();this.readyState=S.closed;let r=Object.assign({code:1e3,reason:void 0,wasClean:!0},{code:e,reason:t,wasClean:n});this.batchBuffer=[],clearTimeout(this.currentBatchTimer),this.currentBatchTimer=null,typeof CloseEvent<`u`?this.onclose(new CloseEvent(`close`,r)):this.onclose(r)}ajax(e,t,n,r,i){let a;a=ze.request(e,this.endpointURL(),t,n,this.timeout,()=>{this.reqs.delete(a),r()},e=>{this.reqs.delete(a),this.isActive()&&i(e)}),this.reqs.add(a)}},He=class e{constructor(t,n={}){let r=n.events||{state:`presence_state`,diff:`presence_diff`};this.state=Object.create(null),this.pendingDiffs=[],this.channel=t,this.joinRef=null,this.caller={onJoin:function(){},onLeave:function(){},onSync:function(){}},this.channel.on(r.state,t=>{let{onJoin:n,onLeave:r,onSync:i}=this.caller;this.joinRef=this.channel.joinRef(),this.state=e.syncState(this.state,t,n,r),this.pendingDiffs.forEach(t=>{this.state=e.syncDiff(this.state,t,n,r)}),this.pendingDiffs=[],i()}),this.channel.on(r.diff,t=>{let{onJoin:n,onLeave:r,onSync:i}=this.caller;this.inPendingSyncState()?this.pendingDiffs.push(t):(this.state=e.syncDiff(this.state,t,n,r),i())})}onJoin(e){this.caller.onJoin=e}onLeave(e){this.caller.onLeave=e}onSync(e){this.caller.onSync=e}list(t){return e.list(this.state,t)}inPendingSyncState(){return!this.joinRef||this.joinRef!==this.channel.joinRef()}static syncState(e,t,n,r){let i=this.toNullProtoObj(this.clone(e));t=this.toNullProtoObj(t);let a=Object.create(null),o=Object.create(null);return this.map(i,(e,n)=>{t[e]||(o[e]=n)}),this.map(t,(e,t)=>{let n=i[e];if(n){let r=t.metas.map(e=>e.phx_ref),i=n.metas.map(e=>e.phx_ref),s=t.metas.filter(e=>i.indexOf(e.phx_ref)<0),c=n.metas.filter(e=>r.indexOf(e.phx_ref)<0);s.length>0&&(a[e]=t,a[e].metas=s),c.length>0&&(o[e]=this.clone(n),o[e].metas=c)}else a[e]=t}),this.syncDiff(i,{joins:a,leaves:o},n,r)}static syncDiff(e,t,n,r){e=this.toNullProtoObj(e);let{joins:i,leaves:a}=this.clone(t);return n||=function(){},r||=function(){},this.map(i,(t,r)=>{let i=e[t];if(e[t]=this.clone(r),i){let n=e[t].metas.map(e=>e.phx_ref),r=i.metas.filter(e=>n.indexOf(e.phx_ref)<0);e[t].metas.unshift(...r)}n(t,i,r)}),this.map(a,(t,n)=>{let i=e[t];if(!i)return;let a=n.metas.map(e=>e.phx_ref);i.metas=i.metas.filter(e=>a.indexOf(e.phx_ref)<0),r(t,i,n),i.metas.length===0&&delete e[t]}),e}static list(e,t){return t||=function(e,t){return t},this.map(e,(e,n)=>t(e,n))}static map(e,t){return Object.getOwnPropertyNames(e).map(n=>t(n,e[n]))}static toNullProtoObj(e){if(Object.getPrototypeOf(e)===null)return e;let t=Object.create(null);return Object.getOwnPropertyNames(e).forEach(n=>{t[n]=e[n]}),t}static clone(e){return JSON.parse(JSON.stringify(e))}},Ue={HEADER_LENGTH:1,META_LENGTH:4,KINDS:{push:0,reply:1,broadcast:2},encode(e,t){if(e.payload.constructor===ArrayBuffer)return t(this.binaryEncode(e));{let n=[e.join_ref,e.ref,e.topic,e.event,e.payload];return t(JSON.stringify(n))}},decode(e,t){if(e.constructor===ArrayBuffer)return t(this.binaryDecode(e));{let[n,r,i,a,o]=JSON.parse(e);return t({join_ref:n,ref:r,topic:i,event:a,payload:o})}},binaryEncode(e){let{join_ref:t,ref:n,event:r,topic:i,payload:a}=e,o=new TextEncoder,s=o.encode(t),c=o.encode(n),l=o.encode(i),u=o.encode(r);this.assertFieldSize(s.byteLength,`join_ref`),this.assertFieldSize(c.byteLength,`ref`),this.assertFieldSize(l.byteLength,`topic`),this.assertFieldSize(u.byteLength,`event`);let d=this.META_LENGTH+s.byteLength+c.byteLength+l.byteLength+u.byteLength,f=new ArrayBuffer(this.HEADER_LENGTH+d),p=new Uint8Array(f),m=new DataView(f),h=0;m.setUint8(h++,this.KINDS.push),m.setUint8(h++,s.byteLength),m.setUint8(h++,c.byteLength),m.setUint8(h++,l.byteLength),m.setUint8(h++,u.byteLength),p.set(s,h),h+=s.byteLength,p.set(c,h),h+=c.byteLength,p.set(l,h),h+=l.byteLength,p.set(u,h),h+=u.byteLength;var g=new Uint8Array(f.byteLength+a.byteLength);return g.set(p,0),g.set(new Uint8Array(a),f.byteLength),g.buffer},assertFieldSize(e,t){if(e>255)throw Error(`unable to convert ${t} to binary: must be less than or equal to 255 bytes, but is ${e} bytes`)},binaryDecode(e){let t=new DataView(e),n=t.getUint8(0),r=new TextDecoder;switch(n){case this.KINDS.push:return this.decodePush(e,t,r);case this.KINDS.reply:return this.decodeReply(e,t,r);case this.KINDS.broadcast:return this.decodeBroadcast(e,t,r)}},decodePush(e,t,n){let r=t.getUint8(1),i=t.getUint8(2),a=t.getUint8(3),o=this.HEADER_LENGTH+this.META_LENGTH-1,s=n.decode(e.slice(o,o+r));o+=r;let c=n.decode(e.slice(o,o+i));o+=i;let l=n.decode(e.slice(o,o+a));return o+=a,{join_ref:s,ref:null,topic:c,event:l,payload:e.slice(o,e.byteLength)}},decodeReply(e,t,n){let r=t.getUint8(1),i=t.getUint8(2),a=t.getUint8(3),o=t.getUint8(4),s=this.HEADER_LENGTH+this.META_LENGTH,c=n.decode(e.slice(s,s+r));s+=r;let l=n.decode(e.slice(s,s+i));s+=i;let u=n.decode(e.slice(s,s+a));s+=a;let d=n.decode(e.slice(s,s+o));s+=o;let f={status:d,response:e.slice(s,e.byteLength)};return{join_ref:c,ref:l,topic:u,event:w.reply,payload:f}},decodeBroadcast(e,t,n){let r=t.getUint8(1),i=t.getUint8(2),a=this.HEADER_LENGTH+2,o=n.decode(e.slice(a,a+r));a+=r;let s=n.decode(e.slice(a,a+i));return a+=i,{join_ref:null,ref:null,topic:o,event:s,payload:e.slice(a,e.byteLength)}}},We=class{constructor(e,t={}){this.stateChangeCallbacks={open:[],close:[],error:[],message:[]},this.channels=[],this.sendBuffer=[],this.ref=0,this.fallbackRef=null,this.timeout=t.timeout||Ae,this.transport=t.transport||x.WebSocket||Ve,this.conn=void 0,this.primaryPassedHealthCheck=!1,this.longPollFallbackMs=t.longPollFallbackMs,this.fallbackTimer=null;let n=null;try{n=x&&x.sessionStorage}catch{}this.sessionStore=t.sessionStorage||n,this.establishedConnections=0,this.defaultEncoder=Ue.encode.bind(Ue),this.defaultDecoder=Ue.decode.bind(Ue),this.closeWasClean=!0,this.disconnecting=!1,this.binaryType=t.binaryType||`arraybuffer`,this.connectClock=1,this.pageHidden=!1,this.encode=void 0,this.decode=void 0,this.transport===Ve?(this.encode=this.defaultEncoder,this.decode=this.defaultDecoder):(this.encode=t.encode||this.defaultEncoder,this.decode=t.decode||this.defaultDecoder);let r=null;Oe&&Oe.addEventListener&&(Oe.addEventListener(`pagehide`,e=>{this.conn&&(this.disconnect(),r=this.connectClock)}),Oe.addEventListener(`pageshow`,e=>{r===this.connectClock&&(r=null,this.connect())}),Oe.addEventListener(`visibilitychange`,()=>{document.visibilityState===`hidden`?this.pageHidden=!0:(this.pageHidden=!1,!this.isConnected()&&!this.closeWasClean&&this.teardown(()=>this.connect()))})),this.heartbeatIntervalMs=t.heartbeatIntervalMs||3e4,this.autoSendHeartbeat=t.autoSendHeartbeat??!0,this.heartbeatCallback=t.heartbeatCallback??(()=>{}),this.rejoinAfterMs=e=>t.rejoinAfterMs?t.rejoinAfterMs(e):[1e3,2e3,5e3][e-1]||1e4,this.reconnectAfterMs=e=>t.reconnectAfterMs?t.reconnectAfterMs(e):[10,50,100,150,200,250,500,1e3,2e3][e-1]||5e3,this.logger=t.logger||null,!this.logger&&t.debug&&(this.logger=(e,t,n)=>{console.log(`${e}: ${t}`,n)}),this.longpollerTimeout=t.longpollerTimeout||2e4,this.params=b(t.params||{}),this.endPoint=`${e}/${Ne.websocket}`,this.vsn=t.vsn||ke,this.heartbeatTimeoutTimer=null,this.heartbeatTimer=null,this.heartbeatSentAt=null,this.pendingHeartbeatRef=null,this.reconnectTimer=new Le(()=>{if(this.pageHidden){this.log(`Not reconnecting as page is hidden!`),this.teardown();return}this.teardown(async()=>{t.beforeReconnect&&await t.beforeReconnect(),this.connect()})},this.reconnectAfterMs),this.authToken=t.authToken&&b(t.authToken)}getLongPollTransport(){return Ve}replaceTransport(e){this.connectClock++,this.closeWasClean=!0,clearTimeout(this.fallbackTimer),this.reconnectTimer.reset(),this.conn&&=(this.conn.close(),null),this.transport=e}protocol(){return location.protocol.match(/^https/)?`wss`:`ws`}endPointURL(){let e=ze.appendParams(ze.appendParams(this.endPoint,this.params()),{vsn:this.vsn});return e.charAt(0)===`/`?e.charAt(1)===`/`?`${this.protocol()}:${e}`:`${this.protocol()}://${location.host}${e}`:e}disconnect(e,t,n){this.connectClock++,this.disconnecting=!0,this.closeWasClean=!0,clearTimeout(this.fallbackTimer),this.reconnectTimer.reset(),this.teardown(()=>{this.disconnecting=!1,e&&e()},t,n)}connect(e){e&&(console&&console.log(`passing params to connect is deprecated. Instead pass :params to the Socket constructor`),this.params=b(e)),!(this.conn&&!this.disconnecting)&&(this.longPollFallbackMs&&this.transport!==Ve?this.connectWithFallback(Ve,this.longPollFallbackMs):this.transportConnect())}log(e,t,n){this.logger&&this.logger(e,t,n)}hasLogger(){return this.logger!==null}onOpen(e){let t=this.makeRef();return this.stateChangeCallbacks.open.push([t,e]),t}onClose(e){let t=this.makeRef();return this.stateChangeCallbacks.close.push([t,e]),t}onError(e){let t=this.makeRef();return this.stateChangeCallbacks.error.push([t,e]),t}onMessage(e){let t=this.makeRef();return this.stateChangeCallbacks.message.push([t,e]),t}onHeartbeat(e){this.heartbeatCallback=e}ping(e){if(!this.isConnected())return!1;let t=this.makeRef(),n=Date.now();this.push({topic:`phoenix`,event:`heartbeat`,payload:{},ref:t});let r=this.onMessage(i=>{i.ref===t&&(this.off([r]),e(Date.now()-n))});return!0}transportName(e){switch(e){case Ve:return`LongPoll`;default:return e.name}}transportConnect(){this.connectClock++,this.closeWasClean=!1;let e;this.authToken&&(e=[`phoenix`,`${Fe}${btoa(this.authToken()).replace(/=/g,``)}`]),this.conn=new this.transport(this.endPointURL(),e),this.conn.binaryType=this.binaryType,this.conn.timeout=this.longpollerTimeout,this.conn.onopen=()=>this.onConnOpen(),this.conn.onerror=e=>this.onConnError(e),this.conn.onmessage=e=>this.onConnMessage(e),this.conn.onclose=e=>this.onConnClose(e)}getSession(e){return this.sessionStore&&this.sessionStore.getItem(e)}storeSession(e,t){this.sessionStore&&this.sessionStore.setItem(e,t)}connectWithFallback(e,t=2500){clearTimeout(this.fallbackTimer);let n=!1,r=!0,i,a=this.transportName(e),o=t=>{this.log(`transport`,`falling back to ${a}...`,t),this.off([void 0,i]),r=!1,this.replaceTransport(e),this.transportConnect()};if(this.getSession(`phx:fallback:${a}`))return o(`memorized`);this.fallbackTimer=setTimeout(o,t),i=this.onError(e=>{this.log(`transport`,`error`,e),r&&!n&&(clearTimeout(this.fallbackTimer),o(e))}),this.fallbackRef&&this.off([this.fallbackRef]),this.fallbackRef=this.onOpen(()=>{if(n=!0,!r){let t=this.transportName(e);return this.primaryPassedHealthCheck||this.storeSession(`phx:fallback:${t}`,`true`),this.log(`transport`,`established ${t} fallback`)}clearTimeout(this.fallbackTimer),this.fallbackTimer=setTimeout(o,t),this.ping(e=>{this.log(`transport`,`connected to primary after`,e),this.primaryPassedHealthCheck=!0,clearTimeout(this.fallbackTimer)})}),this.transportConnect()}clearHeartbeats(){clearTimeout(this.heartbeatTimer),clearTimeout(this.heartbeatTimeoutTimer)}onConnOpen(){this.hasLogger()&&this.log(`transport`,`connected to ${this.endPointURL()}`),this.closeWasClean=!1,this.disconnecting=!1,this.establishedConnections++,this.flushSendBuffer(),this.reconnectTimer.reset(),this.autoSendHeartbeat&&this.resetHeartbeat(),this.triggerStateCallbacks(`open`)}heartbeatTimeout(){if(this.pendingHeartbeatRef){this.pendingHeartbeatRef=null,this.heartbeatSentAt=null,this.hasLogger()&&this.log(`transport`,`heartbeat timeout. Attempting to re-establish connection`);try{this.heartbeatCallback(`timeout`)}catch(e){this.log(`error`,`error in heartbeat callback`,e)}this.triggerChanError(Error(`heartbeat timeout`)),this.closeWasClean=!1,this.teardown(()=>this.reconnectTimer.scheduleTimeout(),je,`heartbeat timeout`)}}resetHeartbeat(){this.conn&&this.conn.skipHeartbeat||(this.pendingHeartbeatRef=null,this.clearHeartbeats(),this.heartbeatTimer=setTimeout(()=>this.sendHeartbeat(),this.heartbeatIntervalMs))}teardown(e,t,n){if(!this.conn)return e&&e();let r=this.conn;this.waitForBufferDone(r,()=>{t?r.close(t,n||``):r.close(),this.waitForSocketClosed(r,()=>{this.conn===r&&(this.conn.onopen=function(){},this.conn.onerror=function(){},this.conn.onmessage=function(){},this.conn.onclose=function(){},this.conn=null),e&&e()})})}waitForBufferDone(e,t,n=1){if(n===5||!e.bufferedAmount){t();return}setTimeout(()=>{this.waitForBufferDone(e,t,n+1)},150*n)}waitForSocketClosed(e,t,n=1){if(n===5||e.readyState===S.closed){t();return}setTimeout(()=>{this.waitForSocketClosed(e,t,n+1)},150*n)}onConnClose(e){this.conn&&(this.conn.onclose=()=>{}),this.hasLogger()&&this.log(`transport`,`close`,e),this.triggerChanError(e),this.clearHeartbeats(),this.closeWasClean||this.reconnectTimer.scheduleTimeout(),this.triggerStateCallbacks(`close`,e)}onConnError(e){this.hasLogger()&&this.log(`transport`,`error`,e);let t=this.transport,n=this.establishedConnections;this.triggerStateCallbacks(`error`,e,t,n),(t===this.transport||n>0)&&this.triggerChanError(e)}triggerChanError(e){this.channels.forEach(t=>{t.isErrored()||t.isLeaving()||t.isClosed()||t.trigger(w.error,e)})}connectionState(){switch(this.conn&&this.conn.readyState){case S.connecting:return`connecting`;case S.open:return`open`;case S.closing:return`closing`;default:return`closed`}}isConnected(){return this.connectionState()===`open`}remove(e){this.off(e.stateChangeRefs),this.channels=this.channels.filter(t=>t!==e)}off(e){for(let t in this.stateChangeCallbacks)this.stateChangeCallbacks[t]=this.stateChangeCallbacks[t].filter(([t])=>e.indexOf(t)===-1)}channel(e,t={}){let n=new Re(e,t,this);return this.channels.push(n),n}push(e){if(this.hasLogger()){let{topic:t,event:n,payload:r,ref:i,join_ref:a}=e;this.log(`push`,`${t} ${n} (${a}, ${i})`,r)}this.isConnected()?this.encode(e,e=>this.conn.send(e)):this.sendBuffer.push(()=>this.encode(e,e=>this.conn.send(e)))}makeRef(){let e=this.ref+1;return e===this.ref?this.ref=0:this.ref=e,this.ref.toString()}sendHeartbeat(){if(!this.isConnected()){try{this.heartbeatCallback(`disconnected`)}catch(e){this.log(`error`,`error in heartbeat callback`,e)}return}if(this.pendingHeartbeatRef){this.heartbeatTimeout();return}this.pendingHeartbeatRef=this.makeRef(),this.heartbeatSentAt=Date.now(),this.push({topic:`phoenix`,event:`heartbeat`,payload:{},ref:this.pendingHeartbeatRef});try{this.heartbeatCallback(`sent`)}catch(e){this.log(`error`,`error in heartbeat callback`,e)}this.heartbeatTimeoutTimer=setTimeout(()=>this.heartbeatTimeout(),this.heartbeatIntervalMs)}flushSendBuffer(){this.isConnected()&&this.sendBuffer.length>0&&(this.sendBuffer.forEach(e=>e()),this.sendBuffer=[])}onConnMessage(e){this.decode(e.data,e=>{let{topic:t,event:n,payload:r,ref:i,join_ref:a}=e;if(i&&i===this.pendingHeartbeatRef){let e=this.heartbeatSentAt?Date.now()-this.heartbeatSentAt:void 0;this.clearHeartbeats();try{this.heartbeatCallback(r.status===`ok`?`ok`:`error`,e)}catch(e){this.log(`error`,`error in heartbeat callback`,e)}this.pendingHeartbeatRef=null,this.heartbeatSentAt=null,this.autoSendHeartbeat&&(this.heartbeatTimer=setTimeout(()=>this.sendHeartbeat(),this.heartbeatIntervalMs))}this.hasLogger()&&this.log(`receive`,`${r.status||``} ${t} ${n} ${i&&`(`+i+`)`||``}`.trim(),r);for(let e=0;e<this.channels.length;e++){let o=this.channels[e];o.isMember(t,n,r,a)&&o.trigger(n,r,i,a)}this.triggerStateCallbacks(`message`,e)})}triggerStateCallbacks(e,...t){try{this.stateChangeCallbacks[e].forEach(([n,r])=>{try{r(...t)}catch(t){this.log(`error`,`error in ${e} callback`,t)}})}catch(t){this.log(`error`,`error triggering ${e} callbacks`,t)}}leaveOpenTopic(e){let t=this.channels.find(t=>t.topic===e&&(t.isJoined()||t.isJoining()));t&&(this.hasLogger()&&this.log(`transport`,`leaving duplicate topic "${e}"`),t.leave())}},Ge=class e{constructor(t,n){let r=Je(n);this.presence=new He(t.getChannel(),r),this.presence.onJoin((n,r,i)=>{let a=e.onJoinPayload(n,r,i);t.getChannel().trigger(`presence`,a)}),this.presence.onLeave((n,r,i)=>{let a=e.onLeavePayload(n,r,i);t.getChannel().trigger(`presence`,a)}),this.presence.onSync(()=>{t.getChannel().trigger(`presence`,{event:`sync`})})}get state(){return e.transformState(this.presence.state)}static transformState(e){return e=qe(e),Object.getOwnPropertyNames(e).reduce((t,n)=>{let r=e[n];return t[n]=Ke(r),t},{})}static onJoinPayload(e,t,n){return{event:`join`,key:e,currentPresences:Ye(t),newPresences:Ke(n)}}static onLeavePayload(e,t,n){return{event:`leave`,key:e,currentPresences:Ye(t),leftPresences:Ke(n)}}};function Ke(e){return e.metas.map(e=>{let t=Object.getOwnPropertyDescriptors(e),n=Object.defineProperties({},t);return n.presence_ref=n.phx_ref,delete n.phx_ref,delete n.phx_ref_prev,n})}function qe(e){return JSON.parse(JSON.stringify(e))}function Je(e){return e?.events&&{events:e.events}}function Ye(e){return e?.metas?Ke(e):[]}var Xe;(function(e){e.SYNC=`sync`,e.JOIN=`join`,e.LEAVE=`leave`})(Xe||={});var Ze=class{get state(){return this.presenceAdapter.state}constructor(e,t){this.channel=e,this.presenceAdapter=new Ge(this.channel.channelAdapter,t)}};function Qe(e){if(e instanceof Error)return e;if(typeof e==`string`)return Error(e);if(e&&typeof e==`object`){let t=e;if(typeof t.code==`number`){let n=typeof t.reason==`string`&&t.reason?` (${t.reason})`:``;return Error(`socket closed: ${t.code}${n}`,{cause:e})}return Error(`channel error: transport failure`,{cause:e})}return Error(`channel error: connection lost`)}var $e=class{constructor(e,t,n){let r=et(n);this.channel=e.getSocket().channel(t,r),this.socket=e}get state(){return this.channel.state}set state(e){this.channel.state=e}get joinedOnce(){return this.channel.joinedOnce}get joinPush(){return this.channel.joinPush}get rejoinTimer(){return this.channel.rejoinTimer}on(e,t){return this.channel.on(e,t)}off(e,t){this.channel.off(e,t)}subscribe(e){return this.channel.join(e)}unsubscribe(e){return this.channel.leave(e)}teardown(){this.channel.teardown()}onClose(e){this.channel.onClose(e)}onError(e){return this.channel.onError(e)}push(e,t,n){let r;try{r=this.channel.push(e,t,n)}catch{throw Error(`tried to push '${e}' to '${this.channel.topic}' before joining. Use channel.subscribe() before pushing events`)}if(this.channel.pushBuffer.length>100){let e=this.channel.pushBuffer.shift();e.cancelTimeout(),this.socket.log(`channel`,`discarded push due to buffer overflow: ${e.event}`,e.payload())}return r}updateJoinPayload(e){let t=this.channel.joinPush.payload();this.channel.joinPush.payload=()=>Object.assign(Object.assign({},t),e)}canPush(){return this.socket.isConnected()&&this.state===v.joined}isJoined(){return this.state===v.joined}isJoining(){return this.state===v.joining}isClosed(){return this.state===v.closed}isLeaving(){return this.state===v.leaving}updateFilterBindings(e){this.channel.filterBindings=e}updatePayloadTransform(e){this.channel.onMessage=e}getChannel(){return this.channel}};function et(e){return{config:Object.assign({broadcast:{ack:!1,self:!1},presence:{key:``,enabled:!1},private:!1},e.config)}}let tt=/[,()"\\]/,nt=e=>tt.test(e)||e!==e.trim(),rt=e=>`"${e.replace(/\\/g,`\\\\`).replace(/"/g,`\\"`)}"`,it=e=>{let t=e===null?`null`:String(e);return nt(t)?rt(t):t},at=e=>e===null?`null`:String(e),ot=(e,t)=>{if(e===`in`){let e=Array.isArray(t)?t:[t];if(e.length===0)throw Error("Realtime `in` filter requires at least one value.");return`in.(${Array.from(new Set(e)).map(e=>it(e)).join(`,`)})`}return e===`is`?`is.${at(t)}`:`${e}.${it(t)}`};var st=class{constructor(){this.filters=[]}add(e,t,n,r=!1){let i=r?`not.`:``;return this.filters.push(`${e}=${i}${ot(t,n)}`),this}eq(e,t){return this.add(e,`eq`,t)}neq(e,t){return this.add(e,`neq`,t)}gt(e,t){return this.add(e,`gt`,t)}gte(e,t){return this.add(e,`gte`,t)}lt(e,t){return this.add(e,`lt`,t)}lte(e,t){return this.add(e,`lte`,t)}in(e,t){return this.add(e,`in`,t)}like(e,t){return this.add(e,`like`,t)}ilike(e,t){return this.add(e,`ilike`,t)}match(e,t){return this.add(e,`match`,t)}imatch(e,t){return this.add(e,`imatch`,t)}is(e,t){return this.add(e,`is`,t)}isDistinct(e,t){return this.add(e,`isdistinct`,t)}not(e,t,n){return this.add(e,t,n,!0)}build(){return this.filters.join(`,`)}toString(){return this.build()}};let ct=()=>new st;var lt;(function(e){e.ALL=`*`,e.INSERT=`INSERT`,e.UPDATE=`UPDATE`,e.DELETE=`DELETE`})(lt||={});var T;(function(e){e.BROADCAST=`broadcast`,e.PRESENCE=`presence`,e.POSTGRES_CHANGES=`postgres_changes`,e.SYSTEM=`system`})(T||={});var E;(function(e){e.SUBSCRIBED=`SUBSCRIBED`,e.TIMED_OUT=`TIMED_OUT`,e.CLOSED=`CLOSED`,e.CHANNEL_ERROR=`CHANNEL_ERROR`})(E||={});let ut=v;var dt=class e{get state(){return this.channelAdapter.state}set state(e){this.channelAdapter.state=e}get joinedOnce(){return this.channelAdapter.joinedOnce}get timeout(){return this.socket.timeout}get joinPush(){return this.channelAdapter.joinPush}get rejoinTimer(){return this.channelAdapter.rejoinTimer}constructor(e,t={config:{}},n){if(this.topic=e,this.params=t,this.socket=n,this.bindings={},this.subTopic=e.replace(/^realtime:/i,``),this.params.config=Object.assign({broadcast:{ack:!1,self:!1},presence:{key:``,enabled:!1},private:!1},t.config),this.channelAdapter=new $e(this.socket.socketAdapter,e,this.params),this.presence=new Ze(this),this._onClose(()=>{this.socket._remove(this)}),this._updateFilterTransform(),this.broadcastEndpointURL=Ee(this.socket.socketAdapter.endPointURL()),this.private=this.params.config.private||!1,!this.private&&this.params.config?.broadcast?.replay)throw Error(`tried to use replay on public channel '${this.topic}'. It must be a private channel.`)}subscribe(e,t=this.timeout){if(this.socket.isConnected()||this.socket.connect(),this.channelAdapter.isClosed()){let{config:{broadcast:n,presence:r,private:i,postgres_changes_options:a}}=this.params,o=this.bindings.postgres_changes?.map(e=>e.filter)??[],s=!!this.bindings[T.PRESENCE]&&this.bindings[T.PRESENCE].length>0||this.params.config.presence?.enabled===!0,c={},l=Object.assign({broadcast:n,presence:Object.assign(Object.assign({},r),{enabled:s}),postgres_changes:o,private:i},a?{postgres_changes_options:a}:{});this.socket.accessTokenValue&&(c.access_token=this.socket.accessTokenValue),this._onError(t=>{e?.(E.CHANNEL_ERROR,Qe(t))}),this._onClose(()=>e?.(E.CLOSED)),this.updateJoinPayload(Object.assign({config:l},c)),this._updateFilterMessage();let u=a?.wait&&o.length>0?Math.max(t,(a.timeout??15e3)+1e4):t;this.channelAdapter.subscribe(u).receive(`ok`,async({postgres_changes:t})=>{if(this.socket._isManualToken()||this.socket.setAuth(),t===void 0){e?.(E.SUBSCRIBED);return}this._updatePostgresBindings(t,e)}).receive(`error`,t=>{this.state=v.errored;let n=Object.values(t).join(`, `)||`error`;e?.(E.CHANNEL_ERROR,Error(n,{cause:t}))}).receive(`timeout`,()=>{e?.(E.TIMED_OUT)})}return this}_updatePostgresBindings(t,n){let r=this.bindings.postgres_changes,i=r?.length??0,a=[];for(let o=0;o<i;o++){let i=r[o],{filter:{event:s,schema:c,table:l,filter:u}}=i,d=t&&t[o];if(d&&d.event===s&&e.isFilterValueEqual(d.schema,c)&&e.isFilterValueEqual(d.table,l)&&e.isFilterValueEqual(d.filter,u))a.push(Object.assign(Object.assign({},i),{id:d.id}));else{this.unsubscribe(),this.state=v.errored,n?.(E.CHANNEL_ERROR,Error(`mismatch between server and client bindings for postgres changes`));return}}this.bindings.postgres_changes=a,this.state!=v.errored&&n&&n(E.SUBSCRIBED)}presenceState(){return this.presence.state}async track(e,t={}){return await this.send({type:`presence`,event:`track`,payload:e},t)}async untrack(e={}){return await this.send({type:`presence`,event:`untrack`},e)}on(e,t,n){let r=this.channelAdapter.isJoined()||this.channelAdapter.isJoining(),i=e===T.PRESENCE||e===T.POSTGRES_CHANGES;if(r&&i)throw this.socket.log(`channel`,`cannot add \`${e}\` callbacks for ${this.topic} after \`subscribe()\`.`),Error(`cannot add \`${e}\` callbacks for ${this.topic} after \`subscribe()\`.`);return this._on(e,t,n)}async httpSend(e,t,n={}){if(t==null)return Promise.reject(Error(`Payload is required for httpSend()`));let r=t instanceof ArrayBuffer||ArrayBuffer.isView(t),i={apikey:this.socket.apiKey?this.socket.apiKey:``,"Content-Type":r?`application/octet-stream`:`application/json`};this.socket.accessTokenValue&&(i.Authorization=`Bearer ${this.socket.accessTokenValue}`);let a=new URL(this.broadcastEndpointURL);a.pathname+=`/${encodeURIComponent(this.subTopic)}/events/${encodeURIComponent(e)}`,this.private&&a.searchParams.set(`private`,`true`);let o={method:`POST`,headers:i,body:r?t:JSON.stringify(t)},s=await this._fetchWithTimeout(a.toString(),o,n.timeout??this.timeout);if(s.status===202)return{success:!0};if(s.status===404)return Promise.reject(Error(`httpSend() requires Realtime server v2.97.0 or newer; the endpoint returned 404. Update your Supabase CLI to a recent version, or upgrade the Realtime server in your self-hosted setup. See https://github.com/supabase/supabase-js/blob/master/packages/core/realtime-js/migrations/httpsend-server-version.md`));let c=s.statusText;try{let e=await s.json();c=e.error||e.message||c}catch{}return Promise.reject(Error(c))}async send(e,t={}){if(!this.channelAdapter.canPush()&&e.type===`broadcast`){let n=`Realtime send() is automatically falling back to REST API. This behavior will be deprecated in the future. Please use httpSend() explicitly for REST delivery.`;this.socket.hasLogger()?this.socket.log(`channel`,n):console.warn(n);let{event:r,payload:i}=e,a={apikey:this.socket.apiKey?this.socket.apiKey:``,"Content-Type":`application/json`};this.socket.accessTokenValue&&(a.Authorization=`Bearer ${this.socket.accessTokenValue}`);let o={method:`POST`,headers:a,body:JSON.stringify({messages:[{topic:this.subTopic,event:r,payload:i,private:this.private}]})};try{let e=await this._fetchWithTimeout(this.broadcastEndpointURL,o,t.timeout??this.timeout);return await e.body?.cancel(),e.ok?`ok`:`error`}catch(e){return e instanceof Error&&e.name===`AbortError`?`timed out`:`error`}}else return new Promise(n=>{let r=this.channelAdapter.push(e.type,e,t.timeout||this.timeout);e.type===`broadcast`&&!this.params?.config?.broadcast?.ack&&n(`ok`),r.receive(`ok`,()=>n(`ok`)),r.receive(`error`,()=>n(`error`)),r.receive(`timeout`,()=>n(`timed out`))})}updateJoinPayload(e){this.channelAdapter.updateJoinPayload(e)}async unsubscribe(e=this.timeout){return new Promise(t=>{this.channelAdapter.unsubscribe(e).receive(`ok`,()=>t(`ok`)).receive(`timeout`,()=>t(`timed out`)).receive(`error`,()=>t(`error`))})}teardown(){this.channelAdapter.teardown()}async _fetchWithTimeout(e,t,n){let r=new AbortController,i=setTimeout(()=>r.abort(),n),a=await this.socket.fetch(e,Object.assign(Object.assign({},t),{signal:r.signal}));return clearTimeout(i),a}_on(t,n,r){let i=t.toLocaleLowerCase(),a=n?.filter;if((a instanceof st||typeof a==`object`&&a&&typeof a.build==`function`)&&(n=Object.assign(Object.assign({},n),{filter:a.build()})),i===T.POSTGRES_CHANGES&&this.bindings[i]?.find(t=>e.isSamePostgresFilter(t.filter,n)))return this.socket.log(`error`,`duplicate \`postgres_changes\` binding for ${this.topic} ignored`,n),this;let o=this.channelAdapter.on(t,r),s={type:i,filter:n,callback:r,ref:o};return this.bindings[i]?this.bindings[i].push(s):this.bindings[i]=[s],this._updateFilterMessage(),this}_onClose(e){this.channelAdapter.onClose(e)}_onError(e){this.channelAdapter.onError(e)}_updateFilterMessage(){this.channelAdapter.updateFilterBindings((e,t,n)=>{let r=e.event.toLocaleLowerCase();if(this._notThisChannelEvent(r,n))return!1;let i=this.bindings[r]?.find(t=>t.ref===e.ref);if(!i)return!0;if([`broadcast`,`presence`,`postgres_changes`].includes(r))if(`id`in i){let e=i.id,n=i.filter?.event;return e&&t.ids?.includes(e)&&(n===`*`||n?.toLocaleLowerCase()===t.data?.type.toLocaleLowerCase())}else{let e=(i?.filter?.event)?.toLocaleLowerCase();return e===`*`||e===(t?.event)?.toLocaleLowerCase()}else return i.type.toLocaleLowerCase()===r})}_notThisChannelEvent(e,t){let{close:n,error:r,leave:i,join:a}=me;return t&&[n,r,i,a].includes(e)&&t!==this.joinPush.ref}_updateFilterTransform(){this.channelAdapter.updatePayloadTransform((e,t,n)=>{if(typeof t==`object`&&`ids`in t){let e=t.data,{schema:n,table:r,commit_timestamp:i,type:a,errors:o}=e,s={schema:n,table:r,commit_timestamp:i,eventType:a,new:{},old:{},errors:o};return Object.assign(Object.assign({},s),this._getPayloadRecords(e))}return t})}copyBindings(e){if(this.joinedOnce)throw Error(`cannot copy bindings into joined channel`);for(let t in e.bindings)for(let n of e.bindings[t])this._on(n.type,n.filter,n.callback)}static isFilterValueEqual(e,t){return(e??void 0)===(t??void 0)}static isSamePostgresFilter(t,n){let r=(t?.select)?.join()??void 0,i=(n?.select)?.join()??void 0;return t?.event===n?.event&&e.isFilterValueEqual(t?.schema,n?.schema)&&e.isFilterValueEqual(t?.table,n?.table)&&e.isFilterValueEqual(t?.filter,n?.filter)&&r===i}_getPayloadRecords(e){let t={new:{},old:{}};return(e.type===`INSERT`||e.type===`UPDATE`)&&(t.new=_e(e.columns,e.record)),(e.type===`UPDATE`||e.type===`DELETE`)&&(t.old=_e(e.columns,e.old_record)),t}},ft=class{constructor(e,t){this.socket=new We(e,t)}get timeout(){return this.socket.timeout}get endPoint(){return this.socket.endPoint}get transport(){return this.socket.transport}get heartbeatIntervalMs(){return this.socket.heartbeatIntervalMs}get heartbeatCallback(){return this.socket.heartbeatCallback}set heartbeatCallback(e){this.socket.heartbeatCallback=e}get heartbeatTimer(){return this.socket.heartbeatTimer}get pendingHeartbeatRef(){return this.socket.pendingHeartbeatRef}get reconnectTimer(){return this.socket.reconnectTimer}get vsn(){return this.socket.vsn}get encode(){return this.socket.encode}get decode(){return this.socket.decode}get reconnectAfterMs(){return this.socket.reconnectAfterMs}get sendBuffer(){return this.socket.sendBuffer}get stateChangeCallbacks(){return this.socket.stateChangeCallbacks}connect(){this.socket.connect()}disconnect(e,t,n,r=1e4){return new Promise(i=>{setTimeout(()=>i(`timeout`),r),this.socket.disconnect(()=>{e(),i(`ok`)},t,n)})}push(e){this.socket.push(e)}log(e,t,n){this.socket.log(e,t,n)}hasLogger(){return this.socket.hasLogger()}makeRef(){return this.socket.makeRef()}onOpen(e){this.socket.onOpen(e)}onClose(e){this.socket.onClose(e)}onError(e){this.socket.onError(e)}onMessage(e){this.socket.onMessage(e)}isConnected(){return this.socket.isConnected()}isConnecting(){return this.socket.connectionState()==he.connecting}isDisconnecting(){return this.socket.connectionState()==he.closing}connectionState(){return this.socket.connectionState()}endPointURL(){return this.socket.endPointURL()}sendHeartbeat(){this.socket.sendHeartbeat()}getSocket(){return this.socket}};let pt={HEARTBEAT_INTERVAL:25e3,RECONNECT_DELAY:10,HEARTBEAT_TIMEOUT_FALLBACK:100},mt=[1e3,2e3,5e3,1e4];function ht(){let e=new Map;return{get length(){return e.size},clear(){e.clear()},getItem(t){return e.has(t)?e.get(t):null},key(t){return Array.from(e.keys())[t]??null},removeItem(t){e.delete(t)},setItem(t,n){e.set(t,String(n))}}}function gt(){try{if(typeof globalThis<`u`&&globalThis.sessionStorage)return globalThis.sessionStorage}catch{}return ht()}var _t=class{get endPoint(){return this.socketAdapter.endPoint}get timeout(){return this.socketAdapter.timeout}get transport(){return this.socketAdapter.transport}get heartbeatCallback(){return this.socketAdapter.heartbeatCallback}get heartbeatIntervalMs(){return this.socketAdapter.heartbeatIntervalMs}get heartbeatTimer(){return this.worker?this._workerHeartbeatTimer:this.socketAdapter.heartbeatTimer}get pendingHeartbeatRef(){return this.worker?this._pendingWorkerHeartbeatRef:this.socketAdapter.pendingHeartbeatRef}get reconnectTimer(){return this.socketAdapter.reconnectTimer}get vsn(){return this.socketAdapter.vsn}get encode(){return this.socketAdapter.encode}get decode(){return this.socketAdapter.decode}get reconnectAfterMs(){return this.socketAdapter.reconnectAfterMs}get sendBuffer(){return this.socketAdapter.sendBuffer}get stateChangeCallbacks(){return this.socketAdapter.stateChangeCallbacks}constructor(e,t){if(this.channels=[],this.accessTokenValue=null,this.accessToken=null,this.apiKey=null,this.httpEndpoint=``,this.headers={},this.params={},this.ref=0,this.serializer=new ge,this._manuallySetToken=!1,this._authPromise=null,this._authGeneration=0,this._workerHeartbeatTimer=void 0,this._pendingWorkerHeartbeatRef=null,this._pendingDisconnectTimer=null,this._disconnectOnEmptyChannelsAfterMs=0,this._resolveFetch=e=>e?(...t)=>e(...t):(...e)=>fetch(...e),!t?.params?.apikey)throw Error(`API key is required to connect to Realtime`);this.apiKey=t.params.apikey,this.socketAdapter=new ft(e,this._initializeOptions(t)),this.httpEndpoint=Ee(e),this.fetch=this._resolveFetch(t?.fetch)}connect(){if(!(this.isConnecting()||this.isDisconnecting()||this.isConnected())){this.accessToken&&!this._authPromise&&this._setAuthSafely(`connect`),this._setupConnectionHandlers();try{this.socketAdapter.connect()}catch(e){let t=e.message;throw Error(`WebSocket not available: ${t}`)}this._handleNodeJsRaceCondition()}}endpointURL(){return this.socketAdapter.endPointURL()}async disconnect(e,t){return this._cancelPendingDisconnect(),this.isDisconnecting()?`ok`:await this.socketAdapter.disconnect(()=>{clearInterval(this._workerHeartbeatTimer),this._terminateWorker()},e,t)}getChannels(){return this.channels}async removeChannel(e){let t=await e.unsubscribe();return t===`ok`&&e.teardown(),t}async removeAllChannels(){let e=this.channels.map(async e=>{let t=await e.unsubscribe();return e.teardown(),t}),t=await Promise.all(e);return await this.disconnect(),t}log(e,t,n){this.socketAdapter.log(e,t,n)}hasLogger(){return this.socketAdapter.hasLogger()}connectionState(){return this.socketAdapter.connectionState()||he.closed}isConnected(){return this.socketAdapter.isConnected()}isConnecting(){return this.socketAdapter.isConnecting()}isDisconnecting(){return this.socketAdapter.isDisconnecting()}channel(e,t={config:{}}){let n=`realtime:${e}`,r=this.getChannels().find(e=>e.topic===n);if(r)return r;{let n=new dt(`realtime:${e}`,t,this);return this._cancelPendingDisconnect(),this.channels.push(n),n}}push(e){this.socketAdapter.push(e)}async setAuth(e=null){let t=++this._authGeneration,n=this._performAuth(e,t);t===this._authGeneration&&(this._authPromise=n);try{await n}finally{this._authPromise===n&&(this._authPromise=null)}}_isManualToken(){return this._manuallySetToken}async sendHeartbeat(){this.socketAdapter.sendHeartbeat()}onHeartbeat(e){this.socketAdapter.heartbeatCallback=this._wrapHeartbeatCallback(e)}_makeRef(){return this.socketAdapter.makeRef()}_remove(e){this.channels=this.channels.filter(t=>t.topic!==e.topic),this.channels.length===0&&(this.log(`transport`,`no channels remaining, scheduling disconnect`),this._schedulePendingDisconnect())}_schedulePendingDisconnect(){if(this._cancelPendingDisconnect(),this._disconnectOnEmptyChannelsAfterMs===0){this.log(`transport`,`disconnecting immediately - no channels`),this.disconnect();return}this._pendingDisconnectTimer=setTimeout(()=>{this._pendingDisconnectTimer=null,this.channels.length===0&&(this.log(`transport`,`deferred disconnect fired - no channels, disconnecting`),this.disconnect())},this._disconnectOnEmptyChannelsAfterMs),this.log(`transport`,`deferred disconnect scheduled in ${this._disconnectOnEmptyChannelsAfterMs}ms`)}_cancelPendingDisconnect(){this._pendingDisconnectTimer!==null&&(this.log(`transport`,`pending disconnect cancelled - channel activity detected`),clearTimeout(this._pendingDisconnectTimer),this._pendingDisconnectTimer=null)}async _performAuth(e,t){let n,r=!1;if(e)n=e,r=!0;else if(this.accessToken)try{n=await this.accessToken()}catch(e){this.log(`error`,`Error fetching access token from callback`,e),n=this.accessTokenValue}else n=this.accessTokenValue;t===this._authGeneration&&(this.accessToken?this._manuallySetToken=!1:r&&(this._manuallySetToken=!0),this.accessTokenValue!=n&&(this.accessTokenValue=n,this.channels.forEach(e=>{let t={access_token:n,version:`realtime-js/2.118.0`};e.updateJoinPayload(t),e.joinedOnce&&e.channelAdapter.isJoined()&&e.channelAdapter.push(me.access_token,{access_token:n})})))}async _waitForAuthIfNeeded(){this._authPromise&&await this._authPromise}_setAuthSafely(e=`general`){this._isManualToken()||this.setAuth().catch(t=>{this.log(`error`,`Error setting auth in ${e}`,t)})}_setupConnectionHandlers(){this.socketAdapter.onOpen(()=>{(this._authPromise||(this.accessToken&&!this.accessTokenValue?this.setAuth():Promise.resolve())).catch(e=>{this.log(`error`,`error waiting for auth on connect`,e)}),this.worker&&!this.workerRef&&this._startWorkerHeartbeat()}),this.socketAdapter.onClose(()=>{this.worker&&this.workerRef&&this._terminateWorker()}),this.socketAdapter.onMessage(e=>{e.ref&&e.ref===this._pendingWorkerHeartbeatRef&&(this._pendingWorkerHeartbeatRef=null)})}_handleNodeJsRaceCondition(){this.socketAdapter.isConnected()&&this.socketAdapter.getSocket().onConnOpen()}_wrapHeartbeatCallback(e){return(t,n)=>{t!==`disconnected`&&(t==`sent`&&this._setAuthSafely(),e&&e(t,n))}}_startWorkerHeartbeat(){this.workerUrl?this.log(`worker`,`starting worker for from ${this.workerUrl}`):this.log(`worker`,`starting default worker`);let e=this._workerObjectUrl(this.workerUrl);this.workerRef=new Worker(e),this.workerRef.onerror=e=>{this.log(`worker`,`worker error`,e.message),this._terminateWorker(),this.disconnect()},this.workerRef.onmessage=e=>{e.data.event===`keepAlive`&&this.sendHeartbeat()},this.workerRef.postMessage({event:`start`,interval:this.heartbeatIntervalMs})}_terminateWorker(){this.workerRef&&=(this.log(`worker`,`terminating worker`),this.workerRef.terminate(),void 0)}_workerObjectUrl(e){let t;if(e)t=e;else{let e=new Blob([`
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`],{type:`application/javascript`});t=URL.createObjectURL(e)}return t}_initializeOptions(e){this.worker=e?.worker??!1,this.accessToken=e?.accessToken??null;let t={};t.timeout=e?.timeout??1e4,t.heartbeatIntervalMs=e?.heartbeatIntervalMs??pt.HEARTBEAT_INTERVAL,this._disconnectOnEmptyChannelsAfterMs=e?.disconnectOnEmptyChannelsAfterMs??2*(e?.heartbeatIntervalMs??pt.HEARTBEAT_INTERVAL),t.transport=e?.transport??pe.getWebSocketConstructor(),t.params=e?.params,t.logger=e?.logger,t.heartbeatCallback=this._wrapHeartbeatCallback(e?.heartbeatCallback),t.sessionStorage=e?.sessionStorage??gt(),t.reconnectAfterMs=e?.reconnectAfterMs??(e=>mt[e-1]||1e4);let n,r,i=e?.vsn??`2.0.0`;switch(i){case`1.0.0`:n=(e,t)=>t(JSON.stringify(e)),r=(e,t)=>t(JSON.parse(e));break;case`2.0.0`:n=this.serializer.encode.bind(this.serializer),r=this.serializer.decode.bind(this.serializer);break;default:throw Error(`Unsupported serializer version: ${t.vsn}`)}if(t.vsn=i,t.encode=e?.encode??n,t.decode=e?.decode??r,t.beforeReconnect=this._reconnectAuth.bind(this),(e?.logLevel||e?.log_level)&&(this.logLevel=e.logLevel||e.log_level,t.params=Object.assign(Object.assign({},t.params),{log_level:this.logLevel})),this.worker){if(typeof window<`u`&&!window.Worker)throw Error(`Web Worker is not supported`);this.workerUrl=e?.workerUrl,t.autoSendHeartbeat=!this.worker}return t}async _reconnectAuth(){await this._waitForAuthIfNeeded(),this.isConnected()||this.connect()}},vt=class extends Error{constructor(e,t){super(e),this.name=`IcebergError`,this.status=t.status,this.icebergType=t.icebergType,this.icebergCode=t.icebergCode,this.details=t.details,this.isCommitStateUnknown=t.icebergType===`CommitStateUnknownException`||[500,502,504].includes(t.status)&&t.icebergType?.includes(`CommitState`)===!0}isNotFound(){return this.status===404}isConflict(){return this.status===409}isAuthenticationTimeout(){return this.status===419}};function yt(e,t,n){let r=new URL(t,e);if(n)for(let[e,t]of Object.entries(n))t!==void 0&&r.searchParams.set(e,t);return r.toString()}async function bt(e){return!e||e.type===`none`?{}:e.type===`bearer`?{Authorization:`Bearer ${e.token}`}:e.type===`header`?{[e.name]:e.value}:e.type===`custom`?await e.getHeaders():{}}function xt(e){let t=e.fetchImpl??globalThis.fetch;return{async request({method:n,path:r,query:i,body:a,headers:o}){let s=yt(e.baseUrl,r,i),c=await bt(e.auth),l=await t(s,{method:n,headers:{...a?{"Content-Type":`application/json`}:{},...c,...o},body:a?JSON.stringify(a):void 0}),u=await l.text(),d=(l.headers.get(`content-type`)||``).includes(`application/json`),f=d&&u?JSON.parse(u):u;if(!l.ok){let e=d?f:void 0,t=e?.error;throw new vt(t?.message??`Request failed with status ${l.status}`,{status:l.status,icebergType:t?.type,icebergCode:t?.code,details:e})}return{status:l.status,headers:l.headers,data:f}}}}function St(e){return e.join(``)}var Ct=class{constructor(e,t=``){this.client=e,this.prefix=t}async listNamespaces(e){let t=e?{parent:St(e.namespace)}:void 0;return(await this.client.request({method:`GET`,path:`${this.prefix}/namespaces`,query:t})).data.namespaces.map(e=>({namespace:e}))}async createNamespace(e,t){let n={namespace:e.namespace,properties:t?.properties};return(await this.client.request({method:`POST`,path:`${this.prefix}/namespaces`,body:n})).data}async dropNamespace(e){await this.client.request({method:`DELETE`,path:`${this.prefix}/namespaces/${St(e.namespace)}`})}async loadNamespaceMetadata(e){return{properties:(await this.client.request({method:`GET`,path:`${this.prefix}/namespaces/${St(e.namespace)}`})).data.properties}}async namespaceExists(e){try{return await this.client.request({method:`HEAD`,path:`${this.prefix}/namespaces/${St(e.namespace)}`}),!0}catch(e){if(e instanceof vt&&e.status===404)return!1;throw e}}async createNamespaceIfNotExists(e,t){try{return await this.createNamespace(e,t)}catch(e){if(e instanceof vt&&e.status===409)return;throw e}}};function wt(e){return e.join(``)}var Tt=class{constructor(e,t=``,n){this.client=e,this.prefix=t,this.accessDelegation=n}async listTables(e){return(await this.client.request({method:`GET`,path:`${this.prefix}/namespaces/${wt(e.namespace)}/tables`})).data.identifiers}async createTable(e,t){let n={};return this.accessDelegation&&(n[`X-Iceberg-Access-Delegation`]=this.accessDelegation),(await this.client.request({method:`POST`,path:`${this.prefix}/namespaces/${wt(e.namespace)}/tables`,body:t,headers:n})).data.metadata}async updateTable(e,t){let n=await this.client.request({method:`POST`,path:`${this.prefix}/namespaces/${wt(e.namespace)}/tables/${e.name}`,body:t});return{"metadata-location":n.data[`metadata-location`],metadata:n.data.metadata}}async dropTable(e,t){await this.client.request({method:`DELETE`,path:`${this.prefix}/namespaces/${wt(e.namespace)}/tables/${e.name}`,query:{purgeRequested:String(t?.purge??!1)}})}async loadTable(e){let t={};return this.accessDelegation&&(t[`X-Iceberg-Access-Delegation`]=this.accessDelegation),(await this.client.request({method:`GET`,path:`${this.prefix}/namespaces/${wt(e.namespace)}/tables/${e.name}`,headers:t})).data.metadata}async tableExists(e){let t={};this.accessDelegation&&(t[`X-Iceberg-Access-Delegation`]=this.accessDelegation);try{return await this.client.request({method:`HEAD`,path:`${this.prefix}/namespaces/${wt(e.namespace)}/tables/${e.name}`,headers:t}),!0}catch(e){if(e instanceof vt&&e.status===404)return!1;throw e}}async createTableIfNotExists(e,t){try{return await this.createTable(e,t)}catch(n){if(n instanceof vt&&n.status===409)return await this.loadTable({namespace:e.namespace,name:t.name});throw n}}},Et=class{constructor(e){let t=`v1`;e.catalogName&&(t+=`/${e.catalogName}`),this.client=xt({baseUrl:e.baseUrl.endsWith(`/`)?e.baseUrl:`${e.baseUrl}/`,auth:e.auth,fetchImpl:e.fetch}),this.accessDelegation=e.accessDelegation?.join(`,`),this.namespaceOps=new Ct(this.client,t),this.tableOps=new Tt(this.client,t,this.accessDelegation)}async listNamespaces(e){return this.namespaceOps.listNamespaces(e)}async createNamespace(e,t){return this.namespaceOps.createNamespace(e,t)}async dropNamespace(e){await this.namespaceOps.dropNamespace(e)}async loadNamespaceMetadata(e){return this.namespaceOps.loadNamespaceMetadata(e)}async listTables(e){return this.tableOps.listTables(e)}async createTable(e,t){return this.tableOps.createTable(e,t)}async updateTable(e,t){return this.tableOps.updateTable(e,t)}async dropTable(e,t){await this.tableOps.dropTable(e,t)}async loadTable(e){return this.tableOps.loadTable(e)}async namespaceExists(e){return this.namespaceOps.namespaceExists(e)}async tableExists(e){return this.tableOps.tableExists(e)}async createNamespaceIfNotExists(e,t){return this.namespaceOps.createNamespaceIfNotExists(e,t)}async createTableIfNotExists(e,t){return this.tableOps.createTableIfNotExists(e,t)}};function Dt(e){"@babel/helpers - typeof";return Dt=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e},Dt(e)}function Ot(e,t){if(Dt(e)!=`object`||!e)return e;var n=e[Symbol.toPrimitive];if(n!==void 0){var r=n.call(e,t||`default`);if(Dt(r)!=`object`)return r;throw TypeError(`@@toPrimitive must return a primitive value.`)}return(t===`string`?String:Number)(e)}function kt(e){var t=Ot(e,`string`);return Dt(t)==`symbol`?t:t+``}function At(e,t,n){return(t=kt(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function jt(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}function D(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]==null?{}:arguments[t];t%2?jt(Object(n),!0).forEach(function(t){At(e,t,n[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):jt(Object(n)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))})}return e}var Mt=class extends Error{constructor(e,t=`storage`,n,r){super(e),this.__isStorageError=!0,this.namespace=t,this.name=t===`vectors`?`StorageVectorsError`:`StorageError`,this.status=n,this.statusCode=r}toJSON(){return{name:this.name,message:this.message,status:this.status,statusCode:this.statusCode}}};function Nt(e){return typeof e==`object`&&!!e&&`__isStorageError`in e}var Pt=class extends Mt{constructor(e,t,n,r=`storage`,i){super(e,r,t,n),this.name=r===`vectors`?`StorageVectorsApiError`:`StorageApiError`,this.status=t,this.statusCode=n,this.code=i}toJSON(){return D(D({},super.toJSON()),{},{code:this.code})}},Ft=class extends Mt{constructor(e,t,n=`storage`){super(e,n),this.name=n===`vectors`?`StorageVectorsUnknownError`:`StorageUnknownError`,this.originalError=t}};function It(e,t,n){let r=D({},e),i=t.toLowerCase();for(let e of Object.keys(r))e.toLowerCase()===i&&delete r[e];return r[i]=n,r}function Lt(e){let t={};for(let[n,r]of Object.entries(e))t[n.toLowerCase()]=r;return t}let Rt=e=>e?(...t)=>e(...t):(...e)=>fetch(...e),zt=e=>{if(typeof e!=`object`||!e)return!1;let t=Object.getPrototypeOf(e);return(t===null||t===Object.prototype||Object.getPrototypeOf(t)===null)&&!(Symbol.toStringTag in e)&&!(Symbol.iterator in e)},Bt=e=>{if(Array.isArray(e))return e.map(e=>Bt(e));if(typeof e==`function`||e!==Object(e))return e;let t={};return Object.entries(e).forEach(([e,n])=>{let r=e.replace(/([-_][a-z])/gi,e=>e.toUpperCase().replace(/[-_]/g,``));t[r]=Bt(n)}),t},Vt=e=>!e||typeof e!=`string`||e.length===0||e.length>100||e.trim()!==e||e.includes(`/`)||e.includes(`\\`)?!1:/^[\w!.\*'() &$@=;:+,?-]+$/.test(e),Ht=e=>e.split(`/`).map(encodeURIComponent).join(`/`),Ut=e=>{if(typeof e==`object`&&e){let t=e;if(typeof t.msg==`string`)return t.msg;if(typeof t.message==`string`)return t.message;if(typeof t.error_description==`string`)return t.error_description;if(typeof t.error==`string`)return t.error;if(typeof t.error==`object`&&t.error!==null){let e=t.error;if(typeof e.message==`string`)return e.message}}return JSON.stringify(e)},Wt=async(e,t,n,r)=>{if(typeof e==`object`&&e&&`json`in e&&typeof e.json==`function`){let n=e,i=parseInt(String(n.status),10);Number.isFinite(i)||(i=500),n.json().then(e=>{let n=e?.statusCode||e?.code||i+``;t(new Pt(Ut(e),i,n,r,e?.code))}).catch(()=>{let e=i+``;t(new Pt(n.statusText||`HTTP ${i} error`,i,e,r))})}else t(new Ft(Ut(e),e,r))},Gt=(e,t,n,r)=>{let i={method:e,headers:t?.headers||{}};if(e===`GET`||e===`HEAD`||!r)return D(D({},i),n);if(zt(r)){let e=t?.headers||{},n;for(let[t,r]of Object.entries(e))t.toLowerCase()===`content-type`&&(n=r);i.headers=It(e,`Content-Type`,n??`application/json`),i.body=JSON.stringify(r)}else i.body=r;return t?.duplex&&(i.duplex=t.duplex),D(D({},i),n)};async function Kt(e,t,n,r,i,a,o){return new Promise((s,c)=>{e(n,Gt(t,r,i,a)).then(e=>{if(!e.ok)throw e;if(r?.noResolveJson)return e;if(o===`vectors`){let t=e.headers.get(`content-type`);if(e.headers.get(`content-length`)===`0`||e.status===204||!t||!t.includes(`application/json`))return{}}return e.json()}).then(e=>s(e)).catch(e=>Wt(e,c,r,o))})}function qt(e=`storage`){return{get:async(t,n,r,i)=>Kt(t,`GET`,n,r,i,void 0,e),post:async(t,n,r,i,a)=>Kt(t,`POST`,n,i,a,r,e),put:async(t,n,r,i,a)=>Kt(t,`PUT`,n,i,a,r,e),head:async(t,n,r,i)=>Kt(t,`HEAD`,n,D(D({},r),{},{noResolveJson:!0}),i,void 0,e),remove:async(t,n,r,i,a)=>Kt(t,`DELETE`,n,i,a,r,e)}}let{get:O,post:k,put:Jt,head:Yt,remove:A}=qt(`storage`),j=qt(`vectors`);var Xt=class{constructor(e,t={},n,r=`storage`){this.shouldThrowOnError=!1,this.url=e,this.headers=Lt(t),this.fetch=Rt(n),this.namespace=r}throwOnError(){return this.shouldThrowOnError=!0,this}setHeader(e,t){return this.headers=It(this.headers,e,t),this}async handleOperation(e){var t=this;try{return{data:await e(),error:null}}catch(e){if(t.shouldThrowOnError)throw e;if(Nt(e))return{data:null,error:e};throw e}}};let Zt;Zt=Symbol.toStringTag;var Qt=class{constructor(e,t){this.downloadFn=e,this.shouldThrowOnError=t,this[Zt]=`StreamDownloadBuilder`,this.promise=null}then(e,t){return this.getPromise().then(e,t)}catch(e){return this.getPromise().catch(e)}finally(e){return this.getPromise().finally(e)}getPromise(){return this.promise||=this.execute(),this.promise}async execute(){var e=this;try{return{data:(await e.downloadFn()).body,error:null}}catch(t){if(e.shouldThrowOnError)throw t;if(Nt(t))return{data:null,error:t};throw t}}};let $t;$t=Symbol.toStringTag;var en=class{constructor(e,t){this.downloadFn=e,this.shouldThrowOnError=t,this[$t]=`BlobDownloadBuilder`,this.promise=null}asStream(){return new Qt(this.downloadFn,this.shouldThrowOnError)}then(e,t){return this.getPromise().then(e,t)}catch(e){return this.getPromise().catch(e)}finally(e){return this.getPromise().finally(e)}getPromise(){return this.promise||=this.execute(),this.promise}async execute(){var e=this;try{return{data:await(await e.downloadFn()).blob(),error:null}}catch(t){if(e.shouldThrowOnError)throw t;if(Nt(t))return{data:null,error:t};throw t}}};let tn={limit:100,offset:0,sortBy:{column:`name`,order:`asc`}},nn={cacheControl:`3600`,contentType:`text/plain;charset=UTF-8`,upsert:!1};var rn=class extends Xt{constructor(e,t={},n,r){super(e,t,r,`storage`),this.bucketId=n}async uploadOrUpdate(e,t,n,r){var i=this;return i.handleOperation(async()=>{let a,o=D(D({},nn),r),s=D(D({},i.headers),e===`POST`&&{"x-upsert":String(o.upsert)}),c=o.metadata;if(typeof Blob<`u`&&n instanceof Blob||typeof FormData<`u`&&n instanceof FormData?a=i.prepareUploadFormData(n,o):(a=n,s[`cache-control`]=`max-age=${o.cacheControl}`,s[`content-type`]=o.contentType,o.contentEncoding&&(s[`content-encoding`]=o.contentEncoding),c&&(s[`x-metadata`]=i.toBase64(i.encodeMetadata(c))),(typeof ReadableStream<`u`&&a instanceof ReadableStream||a&&typeof a==`object`&&`pipe`in a&&typeof a.pipe==`function`)&&!o.duplex&&(o.duplex=`half`)),r?.headers)for(let[e,t]of Object.entries(r.headers))s=It(s,e,t);let l=i._removeEmptyFolders(t),u=i._getFinalPath(l),d=await(e==`PUT`?Jt:k)(i.fetch,`${i.url}/object/${u}`,a,D({headers:s},o?.duplex?{duplex:o.duplex}:{}));return{path:l,id:d.Id,fullPath:d.Key}})}async upload(e,t,n){return this.uploadOrUpdate(`POST`,e,t,n)}async uploadToSignedUrl(e,t,n,r){var i=this;let a=i._removeEmptyFolders(e),o=i._getFinalPath(a),s=new URL(i.url+`/object/upload/sign/${o}`);return s.searchParams.set(`token`,t),i.handleOperation(async()=>{let e,t=D(D({},nn),r),o=D(D({},i.headers),{"x-upsert":String(t.upsert)}),c=t.metadata;if(typeof Blob<`u`&&n instanceof Blob||typeof FormData<`u`&&n instanceof FormData?e=i.prepareUploadFormData(n,t):(e=n,o[`cache-control`]=`max-age=${t.cacheControl}`,o[`content-type`]=t.contentType,t.contentEncoding&&(o[`content-encoding`]=t.contentEncoding),c&&(o[`x-metadata`]=i.toBase64(i.encodeMetadata(c))),(typeof ReadableStream<`u`&&e instanceof ReadableStream||e&&typeof e==`object`&&`pipe`in e&&typeof e.pipe==`function`)&&!t.duplex&&(t.duplex=`half`)),r?.headers)for(let[e,t]of Object.entries(r.headers))o=It(o,e,t);return{path:a,fullPath:(await Jt(i.fetch,s.toString(),e,D({headers:o},t?.duplex?{duplex:t.duplex}:{}))).Key}})}async createSignedUploadUrl(e,t){var n=this;return n.handleOperation(async()=>{let r=n._getFinalPath(e),i=D({},n.headers);t?.upsert&&(i[`x-upsert`]=`true`);let a=await k(n.fetch,`${n.url}/object/upload/sign/${r}`,{},{headers:i}),o=new URL(n.url+a.url),s=o.searchParams.get(`token`);if(!s)throw new Mt(`No token returned by API`);return{signedUrl:o.toString(),path:e,token:s}})}async update(e,t,n){return this.uploadOrUpdate(`PUT`,e,t,n)}async move(e,t,n){var r=this;return r.handleOperation(async()=>await k(r.fetch,`${r.url}/object/move`,{bucketId:r.bucketId,sourceKey:e,destinationKey:t,destinationBucket:n?.destinationBucket,sourceVersionId:n?.sourceVersionId},{headers:r.headers}))}async copy(e,t,n){var r=this;return r.handleOperation(async()=>{let i=n;return{path:(await k(r.fetch,`${r.url}/object/copy`,{bucketId:r.bucketId,sourceKey:e,destinationKey:t,destinationBucket:n?.destinationBucket,sourceVersionId:n?.sourceVersionId,copyMetadata:typeof i?.copyMetadata==`boolean`?i.copyMetadata:void 0,metadata:i?.copyMetadata===!1?i.metadata:void 0},{headers:r.headers})).Key}})}async createSignedUrl(e,t,n){var r=this;return r.handleOperation(async()=>{let i=r._getFinalPath(e),a=typeof n?.transform==`object`&&n.transform!==null&&Object.keys(n.transform).length>0,o=await k(r.fetch,`${r.url}/object/sign/${i}`,D(D({expiresIn:t},a?{transform:n.transform}:{}),n?.versionId==null?{}:{versionId:n.versionId}),{headers:r.headers}),s=new URLSearchParams;n?.download&&s.set(`download`,n.download===!0?``:n.download),n?.cacheNonce!=null&&s.set(`cacheNonce`,String(n.cacheNonce));let c=s.toString();return{signedUrl:encodeURI(`${r.url}${o.signedURL}${c?`&${c}`:``}`)}})}async createSignedUrls(e,t,n){var r=this;return r.handleOperation(async()=>{let i=await k(r.fetch,`${r.url}/object/sign/${r.bucketId}`,{expiresIn:t,paths:e},{headers:r.headers}),a=new URLSearchParams;n?.download&&a.set(`download`,n.download===!0?``:n.download),n?.cacheNonce!=null&&a.set(`cacheNonce`,String(n.cacheNonce));let o=a.toString();return i.map(e=>D(D({},e),{},{signedUrl:e.signedURL?encodeURI(`${r.url}${e.signedURL}${o?`&${o}`:``}`):null}))})}download(e,t,n){let r=typeof t?.transform==`object`&&t.transform!==null&&Object.keys(t.transform).length>0?`render/image/authenticated`:`object`,i=new URLSearchParams;t?.transform&&this.applyTransformOptsToQuery(i,t.transform),t?.cacheNonce!=null&&i.set(`cacheNonce`,String(t.cacheNonce)),t?.versionId!=null&&i.set(`versionId`,String(t.versionId));let a=i.toString(),o=this._getFinalPath(e);return new en(()=>O(this.fetch,`${this.url}/${r}/${o}${a?`?${a}`:``}`,{headers:this.headers,noResolveJson:!0},n),this.shouldThrowOnError)}async info(e,t){var n=this;let r=n._getFinalPath(e),i=new URLSearchParams;t?.versionId!=null&&i.set(`versionId`,String(t.versionId));let a=i.toString();return n.handleOperation(async()=>Bt(await O(n.fetch,`${n.url}/object/info/${r}${a?`?${a}`:``}`,{headers:n.headers})))}async exists(e){var t=this;let n=t._getFinalPath(e);try{return await Yt(t.fetch,`${t.url}/object/${n}`,{headers:t.headers}),{data:!0,error:null}}catch(e){if(t.shouldThrowOnError)throw e;if(Nt(e)){let t=e instanceof Pt?e.status:e instanceof Ft?e.originalError?.status:void 0;if(t!==void 0&&[400,404].includes(t))return{data:!1,error:e}}throw e}}getPublicUrl(e,t){let n=this._getFinalPath(e),r=new URLSearchParams;t?.download&&r.set(`download`,t.download===!0?``:t.download),t?.transform&&this.applyTransformOptsToQuery(r,t.transform),t?.cacheNonce!=null&&r.set(`cacheNonce`,String(t.cacheNonce)),t?.versionId!=null&&r.set(`versionId`,String(t.versionId));let i=r.toString(),a=typeof t?.transform==`object`&&t.transform!==null&&Object.keys(t.transform).length>0?`render/image`:`object`;return{data:{publicUrl:encodeURI(`${this.url}/${a}/public/${n}`)+(i?`?${i}`:``)}}}async remove(e){var t=this;return t.handleOperation(async()=>await A(t.fetch,`${t.url}/object/${t.bucketId}`,{prefixes:e},{headers:t.headers}))}async purgeCache(e,t,n){var r=this;return r.handleOperation(async()=>{let i=Ht(r._getFinalPath(e)),a=new URLSearchParams;t?.transformations&&a.set(`transformations`,`true`);let o=a.toString();return await A(r.fetch,`${r.url}/cdn/${i}${o?`?${o}`:``}`,{},{headers:r.headers},n)})}async list(e,t,n){var r=this;return r.handleOperation(async()=>{let i=t?.sortBy?D(D({},tn.sortBy),t.sortBy):tn.sortBy,a=D(D(D({},tn),t),{},{sortBy:i,prefix:e||``});return await k(r.fetch,`${r.url}/object/list/${r.bucketId}`,a,{headers:r.headers},n)})}async listV2(e,t){var n=this;return n.handleOperation(async()=>{let r=D({},e);return await k(n.fetch,`${n.url}/object/list-v2/${n.bucketId}`,r,{headers:n.headers},t)})}prepareUploadFormData(e,t){let n=new FormData,r=[];e instanceof FormData?e.forEach((e,t)=>{typeof e==`string`?n.append(t,e):r.push([t,e])}):r.push([``,e]),n.has(`cacheControl`)||n.append(`cacheControl`,t.cacheControl),t.metadata&&!n.has(`metadata`)&&n.append(`metadata`,this.encodeMetadata(t.metadata)),t.contentEncoding&&!n.has(`contentEncoding`)&&n.append(`contentEncoding`,t.contentEncoding);for(let[e,t]of r)n.append(e,t);return n}encodeMetadata(e){return JSON.stringify(e)}toBase64(e){return typeof Buffer<`u`?Buffer.from(e).toString(`base64`):btoa(e)}_getFinalPath(e){return`${this.bucketId}/${e.replace(/^\/+/,``)}`}_removeEmptyFolders(e){return e.replace(/^\/|\/$/g,``).replace(/\/+/g,`/`)}applyTransformOptsToQuery(e,t){return t.width&&e.set(`width`,t.width.toString()),t.height&&e.set(`height`,t.height.toString()),t.resize&&e.set(`resize`,t.resize),t.format&&e.set(`format`,t.format),t.quality&&e.set(`quality`,t.quality.toString()),e}};let an={"X-Client-Info":`storage-js/2.118.0`};var on=class extends Xt{constructor(e,t={},n,r){let i=new URL(e);r?.useNewHostname&&/supabase\.(co|in|red)$/.test(i.hostname)&&!i.hostname.includes(`storage.supabase.`)&&(i.hostname=i.hostname.replace(`supabase.`,`storage.supabase.`));let a=i.href.replace(/\/$/,``),o=D(D({},an),t);super(a,o,n,`storage`)}async listBuckets(e){var t=this;return t.handleOperation(async()=>{let n=t.listBucketOptionsToQueryString(e);return await O(t.fetch,`${t.url}/bucket${n}`,{headers:t.headers})})}async getBucket(e){var t=this;return t.handleOperation(async()=>await O(t.fetch,`${t.url}/bucket/${e}`,{headers:t.headers}))}async createBucket(e,t={public:!1}){var n=this;return n.handleOperation(async()=>await k(n.fetch,`${n.url}/bucket`,{id:e,name:e,type:t.type,public:t.public,file_size_limit:t.fileSizeLimit,allowed_mime_types:t.allowedMimeTypes,versioning_status:t.versioningStatus},{headers:n.headers}))}async updateBucket(e,t){var n=this;return n.handleOperation(async()=>await Jt(n.fetch,`${n.url}/bucket/${e}`,{id:e,name:e,public:t.public,file_size_limit:t.fileSizeLimit,allowed_mime_types:t.allowedMimeTypes,versioning_status:t.versioningStatus},{headers:n.headers}))}async emptyBucket(e){var t=this;return t.handleOperation(async()=>await k(t.fetch,`${t.url}/bucket/${e}/empty`,{},{headers:t.headers}))}async deleteBucket(e){var t=this;return t.handleOperation(async()=>await A(t.fetch,`${t.url}/bucket/${e}`,{},{headers:t.headers}))}async getBucketLifecycle(e){var t=this;return t.handleOperation(async()=>await O(t.fetch,t.bucketLifecycleUrl(e),{headers:t.headers}))}async updateBucketLifecycle(e,t){var n=this;return n.handleOperation(async()=>await Jt(n.fetch,n.bucketLifecycleUrl(e),t,{headers:n.headers}))}async deleteBucketLifecycle(e){var t=this;return t.handleOperation(async()=>await A(t.fetch,t.bucketLifecycleUrl(e),{},{headers:t.headers}))}async purgeBucketCache(e,t,n){var r=this;return r.handleOperation(async()=>{let i=new URLSearchParams;t?.transformations&&i.set(`transformations`,`true`);let a=i.toString();return await A(r.fetch,`${r.url}/cdn/${Ht(e)}${a?`?${a}`:``}`,{},{headers:r.headers},n)})}bucketLifecycleUrl(e){return`${this.url}/bucket/${Ht(e)}/lifecycle`}listBucketOptionsToQueryString(e){let t={};return e&&(`limit`in e&&(t.limit=String(e.limit)),`offset`in e&&(t.offset=String(e.offset)),e.search&&(t.search=e.search),e.sortColumn&&(t.sortColumn=e.sortColumn),e.sortOrder&&(t.sortOrder=e.sortOrder)),Object.keys(t).length>0?`?`+new URLSearchParams(t).toString():``}},sn=class extends Xt{constructor(e,t={},n){let r=e.replace(/\/$/,``),i=D(D({},an),t);super(r,i,n,`storage`)}async createBucket(e){var t=this;return t.handleOperation(async()=>await k(t.fetch,`${t.url}/bucket`,{name:e},{headers:t.headers}))}async listBuckets(e){var t=this;return t.handleOperation(async()=>{let n=new URLSearchParams;e?.limit!==void 0&&n.set(`limit`,e.limit.toString()),e?.offset!==void 0&&n.set(`offset`,e.offset.toString()),e?.sortColumn&&n.set(`sortColumn`,e.sortColumn),e?.sortOrder&&n.set(`sortOrder`,e.sortOrder),e?.search&&n.set(`search`,e.search);let r=n.toString(),i=r?`${t.url}/bucket?${r}`:`${t.url}/bucket`;return await O(t.fetch,i,{headers:t.headers})})}async deleteBucket(e){var t=this;return t.handleOperation(async()=>await A(t.fetch,`${t.url}/bucket/${e}`,{},{headers:t.headers}))}from(e){var t=this;if(!Vt(e))throw new Mt(`Invalid bucket name: File, folder, and bucket names must follow AWS object key naming guidelines and should avoid the use of any other characters.`);let n=new Et({baseUrl:this.url,catalogName:e,auth:{type:`custom`,getHeaders:async()=>t.headers},fetch:this.fetch}),r=this.shouldThrowOnError;return new Proxy(n,{get(e,t){let n=e[t];return typeof n==`function`?async(...t)=>{try{return{data:await n.apply(e,t),error:null}}catch(e){if(r)throw e;return{data:null,error:e}}}:n}})}},cn=class extends Xt{constructor(e,t={},n){let r=e.replace(/\/$/,``),i=D(D({},an),{},{"Content-Type":`application/json`},t);super(r,i,n,`vectors`)}async createIndex(e){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/CreateIndex`,e,{headers:t.headers})||{})}async getIndex(e,t){var n=this;return n.handleOperation(async()=>await j.post(n.fetch,`${n.url}/GetIndex`,{vectorBucketName:e,indexName:t},{headers:n.headers}))}async listIndexes(e){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/ListIndexes`,e,{headers:t.headers}))}async deleteIndex(e,t){var n=this;return n.handleOperation(async()=>await j.post(n.fetch,`${n.url}/DeleteIndex`,{vectorBucketName:e,indexName:t},{headers:n.headers})||{})}},ln=class extends Xt{constructor(e,t={},n){let r=e.replace(/\/$/,``),i=D(D({},an),{},{"Content-Type":`application/json`},t);super(r,i,n,`vectors`)}async putVectors(e){var t=this;if(e.vectors.length<1||e.vectors.length>500)throw Error(`Vector batch size must be between 1 and 500 items`);return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/PutVectors`,e,{headers:t.headers})||{})}async getVectors(e){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/GetVectors`,e,{headers:t.headers}))}async listVectors(e){var t=this;if(e.segmentCount!==void 0){if(e.segmentCount<1||e.segmentCount>16)throw Error(`segmentCount must be between 1 and 16`);if(e.segmentIndex!==void 0&&(e.segmentIndex<0||e.segmentIndex>=e.segmentCount))throw Error(`segmentIndex must be between 0 and ${e.segmentCount-1}`)}return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/ListVectors`,e,{headers:t.headers}))}async queryVectors(e){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/QueryVectors`,e,{headers:t.headers}))}async deleteVectors(e){var t=this;if(e.keys.length<1||e.keys.length>500)throw Error(`Keys batch size must be between 1 and 500 items`);return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/DeleteVectors`,e,{headers:t.headers})||{})}},un=class extends Xt{constructor(e,t={},n){let r=e.replace(/\/$/,``),i=D(D({},an),{},{"Content-Type":`application/json`},t);super(r,i,n,`vectors`)}async createBucket(e){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/CreateVectorBucket`,{vectorBucketName:e},{headers:t.headers})||{})}async getBucket(e){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/GetVectorBucket`,{vectorBucketName:e},{headers:t.headers}))}async listBuckets(e={}){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/ListVectorBuckets`,e,{headers:t.headers}))}async deleteBucket(e){var t=this;return t.handleOperation(async()=>await j.post(t.fetch,`${t.url}/DeleteVectorBucket`,{vectorBucketName:e},{headers:t.headers})||{})}},dn=class extends un{constructor(e,t={}){super(e,t.headers||{},t.fetch)}from(e){return new fn(this.url,this.headers,e,this.fetch)}async createBucket(e){var t=()=>super.createBucket,n=this;return t().call(n,e)}async getBucket(e){var t=()=>super.getBucket,n=this;return t().call(n,e)}async listBuckets(e={}){var t=()=>super.listBuckets,n=this;return t().call(n,e)}async deleteBucket(e){var t=()=>super.deleteBucket,n=this;return t().call(n,e)}},fn=class extends cn{constructor(e,t,n,r){super(e,t,r),this.vectorBucketName=n}async createIndex(e){var t=()=>super.createIndex,n=this;return t().call(n,D(D({},e),{},{vectorBucketName:n.vectorBucketName}))}async listIndexes(e={}){var t=()=>super.listIndexes,n=this;return t().call(n,D(D({},e),{},{vectorBucketName:n.vectorBucketName}))}async getIndex(e){var t=()=>super.getIndex,n=this;return t().call(n,n.vectorBucketName,e)}async deleteIndex(e){var t=()=>super.deleteIndex,n=this;return t().call(n,n.vectorBucketName,e)}index(e){return new pn(this.url,this.headers,this.vectorBucketName,e,this.fetch)}},pn=class extends ln{constructor(e,t,n,r,i){super(e,t,i),this.vectorBucketName=n,this.indexName=r}async putVectors(e){var t=()=>super.putVectors,n=this;return t().call(n,D(D({},e),{},{vectorBucketName:n.vectorBucketName,indexName:n.indexName}))}async getVectors(e){var t=()=>super.getVectors,n=this;return t().call(n,D(D({},e),{},{vectorBucketName:n.vectorBucketName,indexName:n.indexName}))}async listVectors(e={}){var t=()=>super.listVectors,n=this;return t().call(n,D(D({},e),{},{vectorBucketName:n.vectorBucketName,indexName:n.indexName}))}async queryVectors(e){var t=()=>super.queryVectors,n=this;return t().call(n,D(D({},e),{},{vectorBucketName:n.vectorBucketName,indexName:n.indexName}))}async deleteVectors(e){var t=()=>super.deleteVectors,n=this;return t().call(n,D(D({},e),{},{vectorBucketName:n.vectorBucketName,indexName:n.indexName}))}},mn=class extends on{constructor(e,t={},n,r){super(e,t,n,r)}from(e){return new rn(this.url,this.headers,e,this.fetch)}get vectors(){return new dn(this.url+`/vector`,{headers:this.headers,fetch:this.fetch})}get analytics(){return new sn(this.url+`/iceberg`,this.headers,this.fetch)}};let hn=``,gn;typeof Deno<`u`?(hn=`deno`,gn=Deno.version?.deno):typeof document<`u`?hn=`web`:typeof navigator<`u`&&navigator.product===`ReactNative`?hn=`react-native`:(hn=`node`,gn=globalThis.process?.version?.replace(/^v/,``));let _n=[`runtime=${hn}`];gn&&_n.push(`runtime-version=${gn}`);let vn={headers:{"X-Client-Info":`supabase-js/2.118.0; ${_n.join(`; `)}`}},yn={schema:`public`},bn={autoRefreshToken:!0,persistSession:!0,detectSessionInUrl:!0,flowType:`implicit`},xn={},Sn={enabled:!1,respectSamplingDecision:!0};function Cn(e){if(!e||typeof e!=`string`)return null;let t=e.split(`-`);if(t.length!==4)return null;let[n,r,i,a]=t;if(n.length!==2||r.length!==32||i.length!==16||a.length!==2)return null;let o=/^[0-9a-f]+$/i;return!o.test(n)||!o.test(r)||!o.test(i)||!o.test(a)||r===`00000000000000000000000000000000`||i===`0000000000000000`?null:{version:n,traceId:r,parentId:i,traceFlags:a,isSampled:(parseInt(a,16)&1)==1}}function wn(e,t){if(!e||!t||t.length===0)return!1;let n;if(e instanceof URL)n=e;else try{n=new URL(e)}catch{return!1}for(let e of t)try{if(typeof e==`string`){if(Tn(n.hostname,e))return!0}else if(e instanceof RegExp){if(e.test(n.hostname))return!0}else if(typeof e==`function`&&e(n))return!0}catch{continue}return!1}function Tn(e,t){if(t===e)return!0;if(t.startsWith(`*.`)){let n=t.slice(2);if(e.endsWith(n)&&(e===n||e.endsWith(`.`+n)))return!0}return!1}function En(e){let t=[];try{let n=new URL(e);t.push(n.hostname)}catch{}return t.push(`*.supabase.co`,`*.supabase.in`),t.push(`localhost`,`127.0.0.1`,`[::1]`),t}let Dn=Symbol.for(`@supabase/supabase-js.traceContextExtractor`);function On(){return globalThis[Dn]}let kn=e=>e?(...t)=>e(...t):(...e)=>fetch(...e),An=()=>Headers,jn=e=>e.startsWith(`sb_publishable_`)||e.startsWith(`sb_secret_`),Mn=new Set,Nn=e=>{if(!e.startsWith(`sb_`)||jn(e)||e.startsWith(`sb_temp_`))return;let t=e.match(/^sb_[a-zA-Z0-9]+_/)?.[0]??`unknown`;Mn.has(t)||(Mn.add(t),console.warn(`@supabase/supabase-js: Unrecognized Supabase API key format. The client will proceed and send this key as-is; if you see authentication errors you may need to upgrade @supabase/supabase-js to a version that recognizes this key type.`))},Pn=(e,t,n,r,i,a)=>{let o=kn(r),s=An(),c=i?.enabled===!0,l=i?.respectSamplingDecision!==!1,u=c?En(t):null,d=!(a?.omitApiKeyAsBearer&&jn(e));return async(t,r)=>{let i=await n(),a=new s(r?.headers);if(a.has(`apikey`)||a.set(`apikey`,e),!a.has(`Authorization`)){let t=i??(d?e:null);t&&a.set(`Authorization`,`Bearer ${t}`)}if(u){let e=Ln(t,u,l);e&&(e.traceparent&&!a.has(`traceparent`)&&a.set(`traceparent`,e.traceparent),e.tracestate&&!a.has(`tracestate`)&&a.set(`tracestate`,e.tracestate),e.baggage&&!a.has(`baggage`)&&a.set(`baggage`,e.baggage))}return o(t,{...r,headers:a})}},Fn=!1,In=!1;function Ln(e,t,n){let r=On();if(!r)return Fn||(Fn=!0,console.warn("@supabase/supabase-js: tracePropagation is enabled but the tracing runtime is not loaded, so trace headers will not be attached. Add `import '@supabase/supabase-js/tracing'` at your application entry point (requires the OpenTelemetry API package to be installed). The CDN/UMD build does not support trace propagation.")),null;if(!wn(typeof e==`string`||e instanceof URL?e:e.url,t))return null;let i=r();if(!i||!i.traceparent){if(i?.carrierKeys?.length&&!In){In=!0;let e=i.carrierKeys.includes(`sentry-trace`)?" Sentry detected: set `propagateTraceparent: true` in Sentry.init() to emit it.":` Configure your tracing SDK to emit W3C trace context on outgoing requests.`;console.warn(`@supabase/supabase-js: tracePropagation is enabled and a tracing SDK is active, but its propagator wrote [${i.carrierKeys.join(`, `)}] and no W3C traceparent header, so trace headers will not be attached.`+e)}return null}if(n){let e=Cn(i.traceparent);if(e&&!e.isSampled)return{traceparent:i.traceparent}}return i}function Rn(e){return typeof e==`boolean`?{enabled:e}:e}function zn(e){return e.endsWith(`/`)?e:e+`/`}let Bn=!1;function Vn(e){Bn||typeof e!=`object`||!e||!(`schema`in e)||e.schema===void 0||(Bn=!0,console.warn(`@supabase/supabase-js: The "schema" option must be nested under "db", e.g. createClient(url, key, { db: { schema: 'myschema' } }). A top-level "schema" is ignored and queries go to the default schema.`))}function Hn(e,t){let{db:n,auth:r,realtime:i,global:a}=e,{db:o,auth:s,realtime:c,global:l}=t,u=Rn(e.tracePropagation),d=Rn(t.tracePropagation),f={db:{...o,...n},auth:{...s,...r},realtime:{...c,...i},storage:{},global:{...l,...a,headers:{...l?.headers??{},...a?.headers??{}}},tracePropagation:{enabled:u?.enabled??d?.enabled??!1,respectSamplingDecision:u?.respectSamplingDecision??d?.respectSamplingDecision??!0},accessToken:async()=>``};return e.accessToken?f.accessToken=e.accessToken:delete f.accessToken,f}function Un(e){let t=e?.trim();if(!t)throw Error(`supabaseUrl is required.`);if(!t.match(/^https?:\/\//i))throw Error(`Invalid supabaseUrl: Must be a valid HTTP or HTTPS URL.`);try{return new URL(zn(t))}catch{throw Error(`Invalid supabaseUrl: Provided URL is malformed.`)}}let Wn=`2.118.0`,M=30*1e3,Gn=3*M;2*M;let Kn={"X-Client-Info":`gotrue-js/${Wn}`},qn=`X-Supabase-Api-Version`,Jn={"2024-01-01":{timestamp:Date.parse(`2024-01-01T00:00:00.0Z`),name:`2024-01-01`}},Yn=/^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}$|[a-z0-9_-]{2}$)$/i,N=`sb_flow_id`;var Xn=class extends Error{constructor(e,t,n){super(e),this.__isAuthError=!0,this.name=`AuthError`,this.status=t,this.code=n}toJSON(){return{name:this.name,message:this.message,status:this.status,code:this.code}}};function P(e){return typeof e==`object`&&!!e&&`__isAuthError`in e}var Zn=class extends Xn{constructor(e,t,n){super(e,t,n),this.name=`AuthApiError`,this.status=t,this.code=n}};function Qn(e){return P(e)&&e.name===`AuthApiError`}var F=class extends Xn{constructor(e,t){super(e),this.name=`AuthUnknownError`,this.originalError=t}},I=class extends Xn{constructor(e,t,n,r){super(e,n,r),this.name=t,this.status=n}},L=class extends I{constructor(){super(`Auth session missing!`,`AuthSessionMissingError`,400,void 0)}};function $n(e){return P(e)&&e.name===`AuthSessionMissingError`}var R=class extends I{constructor(){super(`Auth session or user missing`,`AuthInvalidTokenResponseError`,500,void 0)}},er=class extends I{constructor(e){super(e,`AuthInvalidCredentialsError`,400,void 0)}},tr=class extends I{constructor(e,t=null){super(e,`AuthImplicitGrantRedirectError`,500,void 0),this.details=null,this.details=t}toJSON(){return Object.assign(Object.assign({},super.toJSON()),{details:this.details})}};function nr(e){return P(e)&&e.name===`AuthImplicitGrantRedirectError`}var rr=class extends I{constructor(e,t=null){super(e,`AuthPKCEGrantCodeExchangeError`,500,void 0),this.details=null,this.details=t}toJSON(){return Object.assign(Object.assign({},super.toJSON()),{details:this.details})}},ir=class extends I{constructor(){super(`PKCE code verifier not found in storage. This can happen if the auth flow was initiated in a different browser or device, or if the storage was cleared. For SSR frameworks (Next.js, SvelteKit, etc.), use @supabase/ssr on both the server and client to store the code verifier in cookies.`,`AuthPKCECodeVerifierMissingError`,400,`pkce_code_verifier_not_found`)}};function ar(e){return P(e)&&e.name===`AuthPKCECodeVerifierMissingError`}var or=class extends I{constructor(e,t){super(e,`AuthRetryableFetchError`,t,void 0)}};function sr(e){return P(e)&&e.name===`AuthRetryableFetchError`}var cr=class extends I{constructor(e=`Refresh result discarded: session state changed mid-flight (e.g., concurrent signOut)`){super(e,`AuthRefreshDiscardedError`,409,void 0)}};function lr(e){return P(e)&&e.name===`AuthRefreshDiscardedError`}var ur=class extends I{constructor(e,t,n){super(e,`AuthWeakPasswordError`,t,`weak_password`),this.reasons=n}toJSON(){return Object.assign(Object.assign({},super.toJSON()),{reasons:this.reasons})}};function dr(e){return P(e)&&e.name===`AuthWeakPasswordError`}var fr=class extends I{constructor(e){super(e,`AuthInvalidJwtError`,400,`invalid_jwt`)}};let pr=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`.split(``),mr=` 	
\r=`.split(``),hr=(()=>{let e=Array(128);for(let t=0;t<e.length;t+=1)e[t]=-1;for(let t=0;t<mr.length;t+=1)e[mr[t].charCodeAt(0)]=-2;for(let t=0;t<pr.length;t+=1)e[pr[t].charCodeAt(0)]=t;return e})();function gr(e,t,n){if(e!==null)for(t.queue=t.queue<<8|e,t.queuedBits+=8;t.queuedBits>=6;)n(pr[t.queue>>t.queuedBits-6&63]),t.queuedBits-=6;else if(t.queuedBits>0)for(t.queue<<=6-t.queuedBits,t.queuedBits=6;t.queuedBits>=6;)n(pr[t.queue>>t.queuedBits-6&63]),t.queuedBits-=6}function _r(e,t,n){let r=hr[e];if(r>-1)for(t.queue=t.queue<<6|r,t.queuedBits+=6;t.queuedBits>=8;)n(t.queue>>t.queuedBits-8&255),t.queuedBits-=8;else if(r===-2)return;else throw Error(`Invalid Base64-URL character "${String.fromCharCode(e)}"`)}function vr(e){let t=[],n=e=>{t.push(String.fromCodePoint(e))},r={utf8seq:0,codepoint:0},i={queue:0,queuedBits:0},a=e=>{xr(e,r,n)};for(let t=0;t<e.length;t+=1)_r(e.charCodeAt(t),i,a);return t.join(``)}function yr(e,t){if(e<=127){t(e);return}else if(e<=2047){t(192|e>>6),t(128|e&63);return}else if(e<=65535){t(224|e>>12),t(128|e>>6&63),t(128|e&63);return}else if(e<=1114111){t(240|e>>18),t(128|e>>12&63),t(128|e>>6&63),t(128|e&63);return}throw Error(`Unrecognized Unicode codepoint: ${e.toString(16)}`)}function br(e,t){for(let n=0;n<e.length;n+=1){let r=e.charCodeAt(n);if(r>55295&&r<=56319){let t=(r-55296)*1024&65535;r=(e.charCodeAt(n+1)-56320&65535|t)+65536,n+=1}yr(r,t)}}function xr(e,t,n){if(t.utf8seq===0){if(e<=127){n(e);return}for(let n=1;n<6;n+=1)if(!(e>>7-n&1)){t.utf8seq=n;break}if(t.utf8seq===2)t.codepoint=e&31;else if(t.utf8seq===3)t.codepoint=e&15;else if(t.utf8seq===4)t.codepoint=e&7;else throw Error(`Invalid UTF-8 sequence`);--t.utf8seq}else if(t.utf8seq>0){if(e<=127)throw Error(`Invalid UTF-8 sequence`);t.codepoint=t.codepoint<<6|e&63,--t.utf8seq,t.utf8seq===0&&n(t.codepoint)}}function Sr(e){let t=[],n={queue:0,queuedBits:0},r=e=>{t.push(e)};for(let t=0;t<e.length;t+=1)_r(e.charCodeAt(t),n,r);return new Uint8Array(t)}function Cr(e){let t=[];return br(e,e=>t.push(e)),new Uint8Array(t)}function z(e){let t=[],n={queue:0,queuedBits:0},r=e=>{t.push(e)};return e.forEach(e=>gr(e,n,r)),gr(null,n,r),t.join(``)}function wr(e){return Math.round(Date.now()/1e3)+e}function Tr(){return Symbol(`auth-callback`)}let B=()=>typeof window<`u`&&typeof document<`u`,V={tested:!1,writable:!1},Er=()=>{if(!B())return!1;try{if(typeof globalThis.localStorage!=`object`)return!1}catch{return!1}if(V.tested)return V.writable;let e=`lswt-${Math.random()}${Math.random()}`;try{globalThis.localStorage.setItem(e,e),globalThis.localStorage.removeItem(e),V.tested=!0,V.writable=!0}catch{V.tested=!0,V.writable=!1}return V.writable};function Dr(e){let t={},n=new URL(e);if(n.hash&&n.hash[0]===`#`)try{new URLSearchParams(n.hash.substring(1)).forEach((e,n)=>{t[n]=e})}catch{}return n.searchParams.forEach((e,n)=>{t[n]=e}),t}let Or=e=>e?(...t)=>e(...t):(...e)=>fetch(...e),kr=e=>typeof e==`object`&&!!e&&`status`in e&&`ok`in e&&`json`in e&&typeof e.json==`function`,H=async(e,t,n)=>{await e.setItem(t,JSON.stringify(n))},U=async(e,t)=>{let n=await e.getItem(t);if(!n)return null;try{return JSON.parse(n)}catch{return null}},W=async(e,t)=>{await e.removeItem(t)};var Ar=class e{constructor(){this.promise=new e.promiseConstructor((e,t)=>{this.resolve=e,this.reject=t})}};Ar.promiseConstructor=Promise;function jr(e){let t=e.split(`.`);if(t.length!==3)throw new fr(`Invalid JWT structure`);for(let e=0;e<t.length;e++)if(!Yn.test(t[e]))throw new fr(`JWT not in base64url format`);return{header:JSON.parse(vr(t[0])),payload:JSON.parse(vr(t[1])),signature:Sr(t[2]),raw:{header:t[0],payload:t[1]}}}async function Mr(e){return await new Promise(t=>{setTimeout(()=>t(null),e)})}function Nr(e,t){return new Promise((n,r)=>{(async()=>{for(let i=0;i<1/0;i++)try{let r=await e(i);if(!t(i,null,r)){n(r);return}}catch(e){if(!t(i,e)){r(e);return}}})()})}function Pr(e){return(`0`+e.toString(16)).substr(-2)}function Fr(){let e=new Uint32Array(56);if(typeof crypto>`u`){let e=``;for(let t=0;t<56;t++)e+=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~`.charAt(Math.floor(Math.random()*66));return e}return crypto.getRandomValues(e),Array.from(e,Pr).join(``)}async function Ir(e){let t=new TextEncoder().encode(e),n=await crypto.subtle.digest(`SHA-256`,t),r=new Uint8Array(n);return Array.from(r).map(e=>String.fromCharCode(e)).join(``)}async function Lr(e){if(!(typeof crypto<`u`&&crypto.subtle!==void 0&&typeof TextEncoder<`u`))return console.warn(`WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256.`),e;let t=await Ir(e);return btoa(t).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}let Rr=/^[a-zA-Z0-9_-]{8,64}$/;function zr(e){return typeof e==`string`&&Rr.test(e)?e:null}function Br(){if(typeof crypto<`u`&&typeof crypto.getRandomValues==`function`){let e=new Uint8Array(16);return crypto.getRandomValues(e),Array.from(e,Pr).join(``)}let e=``;for(let t=0;t<32;t++)e+=Math.floor(Math.random()*16).toString(16);return e}let Vr=(e,t)=>`${e}-flow-${t}-code-verifier`,Hr=e=>`${e}-flows-code-verifier`;async function Ur(e,t){let n=await U(e,Hr(t));return Array.isArray(n)?n.filter(e=>zr(e)!==null):[]}async function Wr(e,t,n,r,i){await H(e,Vr(t,n),r);let a=(await Ur(e,t)).filter(e=>e!==n);for(a.push(n);a.length>5;){let n=a.shift();await W(e,Vr(t,n)),i?.(n)}await H(e,Hr(t),a),await H(e,`${t}-code-verifier`,r)}async function Gr(e,t,n){if(n){let r=await U(e,Vr(t,n));return{verifier:typeof r==`string`?r:null,flowId:n}}let r=await U(e,`${t}-code-verifier`);return{verifier:typeof r==`string`?r:null,flowId:null}}async function G(e,t,n){let r=`${t}-code-verifier`;if(!n){await W(e,r);return}let i=Vr(t,n),a=await U(e,i);await W(e,i);let o=await Ur(e,t),s=o.filter(e=>e!==n);s.length!==o.length&&(s.length>0?await H(e,Hr(t),s):await W(e,Hr(t))),a!=null&&a===await U(e,r)&&await W(e,r)}async function Kr(e,t){let n=await Ur(e,t);for(let r of n)await W(e,Vr(t,r));await W(e,Hr(t)),await W(e,`${t}-code-verifier`)}function qr(e,t){let n=e.indexOf(`#`),r=n===-1?e:e.slice(0,n),i=n===-1?``:e.slice(n),a=r.indexOf(`?`);if(a!==-1){let e=r.slice(0,a),t=r.slice(a+1).split(`&`).filter(e=>e!==``&&e!==N&&!e.startsWith(`${N}=`));r=t.length>0?`${e}?${t.join(`&`)}`:e}let o=r.includes(`?`)?`&`:`?`;return`${r}${o}${N}=${encodeURIComponent(t)}${i}`}async function Jr(e,t,n=!1,r){let i=Fr(),a=i;n&&(a+=`/recovery`);let o=Br();await Wr(e,t,o,a,r);let s=await Lr(i);return[s,i===s?`plain`:`s256`,o]}let Yr=/^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;function Xr(e){let t=e.headers.get(qn);if(!t||!t.match(Yr))return null;try{return new Date(`${t}T00:00:00.0Z`)}catch{return null}}function Zr(e){if(!e)throw Error(`Missing exp claim`);if(e<=Math.floor(Date.now()/1e3))throw Error(`JWT has expired`)}function Qr(e){switch(e){case`RS256`:return{name:`RSASSA-PKCS1-v1_5`,hash:{name:`SHA-256`}};case`ES256`:return{name:`ECDSA`,namedCurve:`P-256`,hash:{name:`SHA-256`}};default:throw Error(`Invalid alg claim`)}}let $r=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;function K(e){if(!$r.test(e))throw Error(`@supabase/auth-js: Expected parameter to be UUID but is not`)}function ei(e){if(!e.recoveryCodes)throw Error("@supabase/auth-js: the MFA recovery codes API is experimental and disabled by default. Enable it by passing `auth: { experimental: { recoveryCodes: true } }` to createClient (or to the GoTrueClient constructor).")}function ti(){return new Proxy({},{get:(e,t)=>{if(t===`__isUserNotAvailableProxy`)return!0;if(typeof t==`symbol`){let e=t.toString();if(e===`Symbol(Symbol.toPrimitive)`||e===`Symbol(Symbol.toStringTag)`||e===`Symbol(util.inspect.custom)`)return}throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Accessing the "${t}" property of the session object is not supported. Please use getUser() instead.`)},set:(e,t)=>{throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Setting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)},deleteProperty:(e,t)=>{throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Deleting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)}})}function ni(e,t){return new Proxy(e,{get:(e,n,r)=>{if(n===`__isInsecureUserWarningProxy`)return!0;if(typeof n==`symbol`){let t=n.toString();if(t===`Symbol(Symbol.toPrimitive)`||t===`Symbol(Symbol.toStringTag)`||t===`Symbol(util.inspect.custom)`||t===`Symbol(nodejs.util.inspect.custom)`)return Reflect.get(e,n,r)}return!t.value&&typeof n==`string`&&(console.warn(`Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server.`),t.value=!0),Reflect.get(e,n,r)}})}function ri(e){return JSON.parse(JSON.stringify(e))}let q=e=>{if(typeof e==`object`&&e){let t=e;if(typeof t.msg==`string`)return t.msg;if(typeof t.message==`string`)return t.message;if(typeof t.error_description==`string`)return t.error_description;if(typeof t.error==`string`)return t.error}return JSON.stringify(e)},ii=[500,501,502,503,504,520,521,522,523,524,525,526,527,528,529,530];async function ai(e){if(!kr(e))throw new or(q(e),0);let t;try{t=await e.json()}catch(t){throw ii.includes(e.status)?new or(e.statusText||`HTTP ${e.status}`,e.status):new F(q(t),t)}if(ii.includes(e.status))throw new or(q(t),e.status);let n,r=Xr(e);if(r&&r.getTime()>=Jn[`2024-01-01`].timestamp&&typeof t==`object`&&t&&typeof t.code==`string`?n=t.code:typeof t==`object`&&t&&typeof t.error_code==`string`&&(n=t.error_code),n){if(n===`weak_password`)throw new ur(q(t),e.status,t.weak_password?.reasons||[]);if(n===`session_not_found`)throw new L}else if(typeof t==`object`&&t&&typeof t.weak_password==`object`&&t.weak_password&&Array.isArray(t.weak_password.reasons)&&t.weak_password.reasons.length&&t.weak_password.reasons.reduce((e,t)=>e&&typeof t==`string`,!0))throw new ur(q(t),e.status,t.weak_password.reasons);throw new Zn(q(t),e.status||500,n)}let oi=(e,t,n,r)=>{let i={method:e,headers:t?.headers||{}};return e===`GET`?i:(i.headers=Object.assign({"Content-Type":`application/json;charset=UTF-8`},t?.headers),i.body=JSON.stringify(r),Object.assign(Object.assign({},i),n))};async function J(e,t,n,r){let i=Object.assign({},r?.headers);i[qn]||(i[qn]=Jn[`2024-01-01`].name),r?.jwt&&(i.Authorization=`Bearer ${r.jwt}`);let a=r?.query??{};r?.redirectTo&&(a.redirect_to=r.redirectTo);let o=await si(e,t,n+(Object.keys(a).length?`?`+new URLSearchParams(a).toString():``),{headers:i,noResolveJson:r?.noResolveJson},{},r?.body);return r?.xform?r?.xform(o):{data:Object.assign({},o),error:null}}async function si(e,t,n,r,i,a){let o=oi(t,r,i,a),s;try{s=await e(n,Object.assign({},o))}catch(e){throw new or(q(e),0)}if(s.ok||await ai(s),r?.noResolveJson)return s;try{return await s.json()}catch(e){await ai(e)}}function Y(e){let t=null;fi(e)&&(t=Object.assign({},e),e.expires_at||(t.expires_at=wr(e.expires_in)));let n=e.user??(typeof e?.id==`string`?e:null);return{data:{session:t,user:n},error:null}}function ci(e){let t=Y(e);return!t.error&&e.weak_password&&typeof e.weak_password==`object`&&Array.isArray(e.weak_password.reasons)&&e.weak_password.reasons.length&&e.weak_password.message&&typeof e.weak_password.message==`string`&&e.weak_password.reasons.reduce((e,t)=>e&&typeof t==`string`,!0)&&(t.data.weak_password=e.weak_password),t}function X(e){return{data:{user:e.user??e},error:null}}function li(e){return{data:e,error:null}}function ui(e){let{action_link:n,email_otp:r,hashed_token:i,redirect_to:a,verification_type:o}=e,s=t(e,[`action_link`,`email_otp`,`hashed_token`,`redirect_to`,`verification_type`]);return{data:{properties:{action_link:n,email_otp:r,hashed_token:i,redirect_to:a,verification_type:o},user:Object.assign({},s)},error:null}}function di(e){return e}function fi(e){return!!e.access_token&&!!e.refresh_token&&!!e.expires_in}let pi=[`global`,`local`,`others`];var mi=class{constructor({url:e=``,headers:t={},fetch:n,experimental:r}){this.url=e,this.headers=t,this.fetch=Or(n),this.experimental=r??{},this.mfa={listFactors:this._listFactors.bind(this),deleteFactor:this._deleteFactor.bind(this)},this.oauth={listClients:this._listOAuthClients.bind(this),createClient:this._createOAuthClient.bind(this),getClient:this._getOAuthClient.bind(this),updateClient:this._updateOAuthClient.bind(this),deleteClient:this._deleteOAuthClient.bind(this),regenerateClientSecret:this._regenerateOAuthClientSecret.bind(this)},this.customProviders={listProviders:this._listCustomProviders.bind(this),createProvider:this._createCustomProvider.bind(this),getProvider:this._getCustomProvider.bind(this),updateProvider:this._updateCustomProvider.bind(this),deleteProvider:this._deleteCustomProvider.bind(this)},this.passkey={listPasskeys:this._adminListPasskeys.bind(this),deletePasskey:this._adminDeletePasskey.bind(this)}}async signOut(e,t=pi[0]){if(pi.indexOf(t)<0)throw Error(`@supabase/auth-js: Parameter scope must be one of ${pi.join(`, `)}`);try{return await J(this.fetch,`POST`,`${this.url}/logout?scope=${t}`,{headers:this.headers,jwt:e,noResolveJson:!0}),{data:null,error:null}}catch(e){if(P(e))return{data:null,error:e};throw e}}async inviteUserByEmail(e,t={}){try{return await J(this.fetch,`POST`,`${this.url}/invite`,{body:{email:e,data:t.data},headers:this.headers,redirectTo:t.redirectTo,xform:X})}catch(e){if(P(e))return{data:{user:null},error:e};throw e}}async generateLink(e){try{let{options:n}=e,r=t(e,[`options`]),i=Object.assign(Object.assign({},r),n);return`newEmail`in r&&(i.new_email=r?.newEmail,delete i.newEmail),await J(this.fetch,`POST`,`${this.url}/admin/generate_link`,{body:i,headers:this.headers,xform:ui,redirectTo:n?.redirectTo})}catch(e){if(P(e))return{data:{properties:null,user:null},error:e};throw e}}async createUser(e){try{return await J(this.fetch,`POST`,`${this.url}/admin/users`,{body:e,headers:this.headers,xform:X})}catch(e){if(P(e))return{data:{user:null},error:e};throw e}}async listUsers(e){try{let t={nextPage:null,lastPage:0,total:0},n=await J(this.fetch,`GET`,`${this.url}/admin/users`,{headers:this.headers,noResolveJson:!0,query:{page:(e?.page)?.toString()??``,per_page:(e?.perPage)?.toString()??``},xform:di});if(n.error)throw n.error;let r=await n.json(),i=n.headers.get(`x-total-count`)??0,a=n.headers.get(`link`)?.split(`,`)??[];return a.length>0&&(a.forEach(e=>{let n=parseInt(e.split(`;`)[0].split(`=`)[1].substring(0,1)),r=JSON.parse(e.split(`;`)[1].split(`=`)[1]);t[`${r}Page`]=n}),t.total=parseInt(i)),{data:Object.assign(Object.assign({},r),t),error:null}}catch(e){if(P(e))return{data:{users:[]},error:e};throw e}}async getUserById(e){K(e);try{return await J(this.fetch,`GET`,`${this.url}/admin/users/${e}`,{headers:this.headers,xform:X})}catch(e){if(P(e))return{data:{user:null},error:e};throw e}}async updateUserById(e,t){K(e);try{return await J(this.fetch,`PUT`,`${this.url}/admin/users/${e}`,{body:t,headers:this.headers,xform:X})}catch(e){if(P(e))return{data:{user:null},error:e};throw e}}async deleteUser(e,t=!1){K(e);try{return await J(this.fetch,`DELETE`,`${this.url}/admin/users/${e}`,{headers:this.headers,body:{should_soft_delete:t},xform:X})}catch(e){if(P(e))return{data:{user:null},error:e};throw e}}async _listFactors(e){K(e.userId);try{let{data:t,error:n}=await J(this.fetch,`GET`,`${this.url}/admin/users/${e.userId}/factors`,{headers:this.headers,xform:e=>({data:{factors:e},error:null})});return{data:t,error:n}}catch(e){if(P(e))return{data:null,error:e};throw e}}async _deleteFactor(e){K(e.userId),K(e.id);try{return{data:await J(this.fetch,`DELETE`,`${this.url}/admin/users/${e.userId}/factors/${e.id}`,{headers:this.headers}),error:null}}catch(e){if(P(e))return{data:null,error:e};throw e}}async _listOAuthClients(e){try{let t={nextPage:null,lastPage:0,total:0},n=await J(this.fetch,`GET`,`${this.url}/admin/oauth/clients`,{headers:this.headers,noResolveJson:!0,query:{page:(e?.page)?.toString()??``,per_page:(e?.perPage)?.toString()??``},xform:di});if(n.error)throw n.error;let r=await n.json(),i=n.headers.get(`x-total-count`)??0,a=n.headers.get(`link`)?.split(`,`)??[];return a.length>0&&(a.forEach(e=>{let n=parseInt(e.split(`;`)[0].split(`=`)[1].substring(0,1)),r=JSON.parse(e.split(`;`)[1].split(`=`)[1]);t[`${r}Page`]=n}),t.total=parseInt(i)),{data:Object.assign(Object.assign({},r),t),error:null}}catch(e){if(P(e))return{data:{clients:[]},error:e};throw e}}async _createOAuthClient(e){try{return await J(this.fetch,`POST`,`${this.url}/admin/oauth/clients`,{body:e,headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _getOAuthClient(e){try{return await J(this.fetch,`GET`,`${this.url}/admin/oauth/clients/${e}`,{headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _updateOAuthClient(e,t){try{return await J(this.fetch,`PUT`,`${this.url}/admin/oauth/clients/${e}`,{body:t,headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _deleteOAuthClient(e){try{return await J(this.fetch,`DELETE`,`${this.url}/admin/oauth/clients/${e}`,{headers:this.headers,noResolveJson:!0}),{data:null,error:null}}catch(e){if(P(e))return{data:null,error:e};throw e}}async _regenerateOAuthClientSecret(e){try{return await J(this.fetch,`POST`,`${this.url}/admin/oauth/clients/${e}/regenerate_secret`,{headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _listCustomProviders(e){try{let t={};return e?.type&&(t.type=e.type),await J(this.fetch,`GET`,`${this.url}/admin/custom-providers`,{headers:this.headers,query:t,xform:e=>({data:{providers:e?.providers??[]},error:null})})}catch(e){if(P(e))return{data:{providers:[]},error:e};throw e}}async _createCustomProvider(e){try{return await J(this.fetch,`POST`,`${this.url}/admin/custom-providers`,{body:e,headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _getCustomProvider(e){try{return await J(this.fetch,`GET`,`${this.url}/admin/custom-providers/${e}`,{headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _updateCustomProvider(e,t){try{return await J(this.fetch,`PUT`,`${this.url}/admin/custom-providers/${e}`,{body:t,headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _deleteCustomProvider(e){try{return await J(this.fetch,`DELETE`,`${this.url}/admin/custom-providers/${e}`,{headers:this.headers,noResolveJson:!0}),{data:null,error:null}}catch(e){if(P(e))return{data:null,error:e};throw e}}async _adminListPasskeys(e){K(e.userId);try{return await J(this.fetch,`GET`,`${this.url}/admin/users/${e.userId}/passkeys`,{headers:this.headers,xform:e=>({data:e,error:null})})}catch(e){if(P(e))return{data:null,error:e};throw e}}async _adminDeletePasskey(e){K(e.userId),K(e.passkeyId);try{return await J(this.fetch,`DELETE`,`${this.url}/admin/users/${e.userId}/passkeys/${e.passkeyId}`,{headers:this.headers,noResolveJson:!0}),{data:null,error:null}}catch(e){if(P(e))return{data:null,error:e};throw e}}};function hi(e={}){return{getItem:t=>e[t]||null,setItem:(t,n)=>{e[t]=n},removeItem:t=>{delete e[t]}}}let Z={debug:!!(globalThis&&Er()&&globalThis.localStorage&&globalThis.localStorage.getItem(`supabase.gotrue-js.locks.debug`)===`true`)};var gi=class extends Error{constructor(e){super(e),this.isAcquireTimeout=!0}},_i=class extends gi{},vi=class extends gi{};async function yi(e,t,n){Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: acquire lock`,e,t);let r=new globalThis.AbortController,i;t>0&&(i=setTimeout(()=>{r.abort(),Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock acquire timed out`,e)},t)),await Promise.resolve();try{return await globalThis.navigator.locks.request(e,t===0?{mode:`exclusive`,ifAvailable:!0}:{mode:`exclusive`,signal:r.signal},async r=>{if(r){clearTimeout(i),Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: acquired`,e,r.name);try{return await n()}finally{Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: released`,e,r.name)}}else if(t===0)throw Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: not immediately available`,e),new _i(`Acquiring an exclusive Navigator LockManager lock "${e}" immediately failed`);else{if(Z.debug)try{let e=await globalThis.navigator.locks.query();console.log(`@supabase/gotrue-js: Navigator LockManager state`,JSON.stringify(e,null,`  `))}catch(e){console.warn(`@supabase/gotrue-js: Error when querying Navigator LockManager state`,e)}return console.warn(`@supabase/gotrue-js: Navigator LockManager returned a null lock when using #request without ifAvailable set to true, it appears this browser is not following the LockManager spec https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request`),clearTimeout(i),await n()}})}catch(a){if(clearTimeout(i),typeof a==`object`&&a&&`name`in a&&a.name===`AbortError`){if(r.signal.aborted)return Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: acquire timeout, recovering by stealing lock`,e),console.warn(`@supabase/gotrue-js: Lock "${e}" was not released within ${t}ms. This may indicate an orphaned lock from a component unmount (e.g., React Strict Mode). Forcefully acquiring the lock to recover.`),await Promise.resolve().then(()=>globalThis.navigator.locks.request(e,{mode:`exclusive`,steal:!0},async t=>{if(t){Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: recovered (stolen)`,e,t.name);try{return await n()}finally{Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: released (stolen)`,e,t.name)}}else return console.warn(`@supabase/gotrue-js: Navigator LockManager returned null lock even with steal: true`),await n()}));throw Z.debug&&console.log(`@supabase/gotrue-js: navigatorLock: lock was stolen by another request`,e),new _i(`Lock "${e}" was released because another request stole it`)}throw a}}let bi={};async function xi(e,t,n){let r=bi[e]??Promise.resolve(),i=(async()=>{try{return await r,null}catch{return null}})(),a=(async()=>{let r=null;try{let n=t>=0?new Promise((n,i)=>{r=setTimeout(()=>{console.warn(`@supabase/gotrue-js: Lock "${e}" acquisition timed out after ${t}ms. This may be caused by another operation holding the lock. Consider increasing lockAcquireTimeout or checking for stuck operations.`),i(new vi(`Acquiring process lock with name "${e}" timed out`))},t)}):null;await Promise.race([i,n].filter(e=>e)),r!==null&&clearTimeout(r)}catch(e){if(r!==null&&clearTimeout(r),e instanceof gi)throw e}return await n()})();return bi[e]=(async()=>{try{return await a}catch(e){if(e instanceof gi){try{await r}catch{}return null}throw e}})(),await a}function Si(){if(typeof globalThis!=`object`)try{Object.defineProperty(Object.prototype,`__magic__`,{get:function(){return this},configurable:!0}),__magic__.globalThis=__magic__,delete Object.prototype.__magic__}catch{typeof self<`u`&&(self.globalThis=self)}}function Ci(e){if(!/^0x[a-fA-F0-9]{40}$/.test(e))throw Error(`@supabase/auth-js: Address "${e}" is invalid.`);return e.toLowerCase()}function wi(e){return parseInt(e,16)}function Ti(e){let t=new TextEncoder().encode(e);return`0x`+Array.from(t,e=>e.toString(16).padStart(2,`0`)).join(``)}function Ei(e){let{chainId:t,domain:n,expirationTime:r,issuedAt:i=new Date,nonce:a,notBefore:o,requestId:s,resources:c,scheme:l,uri:u,version:d}=e;if(!Number.isInteger(t))throw Error(`@supabase/auth-js: Invalid SIWE message field "chainId". Chain ID must be a EIP-155 chain ID. Provided value: ${t}`);if(!n)throw Error(`@supabase/auth-js: Invalid SIWE message field "domain". Domain must be provided.`);if(a&&a.length<8)throw Error(`@supabase/auth-js: Invalid SIWE message field "nonce". Nonce must be at least 8 characters. Provided value: ${a}`);if(!u)throw Error(`@supabase/auth-js: Invalid SIWE message field "uri". URI must be provided.`);if(d!==`1`)throw Error(`@supabase/auth-js: Invalid SIWE message field "version". Version must be '1'. Provided value: ${d}`);if(e.statement?.includes(`
`))throw Error(`@supabase/auth-js: Invalid SIWE message field "statement". Statement must not include '\\n'. Provided value: ${e.statement}`);let f=Ci(e.address),p=`${l?`${l}://${n}`:n} wants you to sign in with your Ethereum account:\n${f}\n\n${e.statement?`${e.statement}\n`:``}`,m=`URI: ${u}\nVersion: ${d}\nChain ID: ${t}${a?`\nNonce: ${a}`:``}\nIssued At: ${i.toISOString()}`;if(r&&(m+=`\nExpiration Time: ${r.toISOString()}`),o&&(m+=`\nNot Before: ${o.toISOString()}`),s&&(m+=`\nRequest ID: ${s}`),c){let e=`
Resources:`;for(let t of c){if(!t||typeof t!=`string`)throw Error(`@supabase/auth-js: Invalid SIWE message field "resources". Every resource must be a valid string. Provided value: ${t}`);e+=`\n- ${t}`}m+=e}return`${p}\n${m}`}var Q=class extends Error{constructor({message:e,code:t,cause:n,name:r}){super(e,{cause:n}),this.__isWebAuthnError=!0,this.name=r??(n instanceof Error?n.name:void 0)??`Unknown Error`,this.code=t}toJSON(){return{name:this.name,message:this.message,code:this.code}}},Di=class extends Q{constructor(e,t){super({code:`ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,cause:t,message:e}),this.name=`WebAuthnUnknownError`,this.originalError=t}};function Oi({error:e,options:t}){let{publicKey:n}=t;if(!n)throw Error(`options was missing required publicKey property`);if(e.name===`AbortError`){if(t.signal instanceof AbortSignal)return new Q({message:`Registration ceremony was sent an abort signal`,code:`ERROR_CEREMONY_ABORTED`,cause:e})}else if(e.name===`ConstraintError`){if(n.authenticatorSelection?.requireResidentKey===!0)return new Q({message:`Discoverable credentials were required but no available authenticator supported it`,code:`ERROR_AUTHENTICATOR_MISSING_DISCOVERABLE_CREDENTIAL_SUPPORT`,cause:e});if(t.mediation===`conditional`&&n.authenticatorSelection?.userVerification===`required`)return new Q({message:`User verification was required during automatic registration but it could not be performed`,code:`ERROR_AUTO_REGISTER_USER_VERIFICATION_FAILURE`,cause:e});if(n.authenticatorSelection?.userVerification===`required`)return new Q({message:`User verification was required but no available authenticator supported it`,code:`ERROR_AUTHENTICATOR_MISSING_USER_VERIFICATION_SUPPORT`,cause:e})}else if(e.name===`InvalidStateError`)return new Q({message:`The authenticator was previously registered`,code:`ERROR_AUTHENTICATOR_PREVIOUSLY_REGISTERED`,cause:e});else if(e.name===`NotAllowedError`)return new Q({message:e.message,code:`ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,cause:e});else if(e.name===`NotSupportedError`)return n.pubKeyCredParams.filter(e=>e.type===`public-key`).length===0?new Q({message:`No entry in pubKeyCredParams was of type "public-key"`,code:`ERROR_MALFORMED_PUBKEYCREDPARAMS`,cause:e}):new Q({message:`No available authenticator supported any of the specified pubKeyCredParams algorithms`,code:`ERROR_AUTHENTICATOR_NO_SUPPORTED_PUBKEYCREDPARAMS_ALG`,cause:e});else if(e.name===`SecurityError`){let t=window.location.hostname;if(Fi(t)){if(n.rp.id!==t)return new Q({message:`The RP ID "${n.rp.id}" is invalid for this domain`,code:`ERROR_INVALID_RP_ID`,cause:e})}else return new Q({message:`${window.location.hostname} is an invalid domain`,code:`ERROR_INVALID_DOMAIN`,cause:e})}else if(e.name===`TypeError`){if(n.user.id.byteLength<1||n.user.id.byteLength>64)return new Q({message:`User ID was not between 1 and 64 characters`,code:`ERROR_INVALID_USER_ID_LENGTH`,cause:e})}else if(e.name===`UnknownError`)return new Q({message:`The authenticator was unable to process the specified options, or could not create a new credential`,code:`ERROR_AUTHENTICATOR_GENERAL_ERROR`,cause:e});return new Q({message:`a Non-Webauthn related error has occurred`,code:`ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,cause:e})}function ki({error:e,options:t}){let{publicKey:n}=t;if(!n)throw Error(`options was missing required publicKey property`);if(e.name===`AbortError`){if(t.signal instanceof AbortSignal)return new Q({message:`Authentication ceremony was sent an abort signal`,code:`ERROR_CEREMONY_ABORTED`,cause:e})}else if(e.name===`NotAllowedError`)return new Q({message:e.message,code:`ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,cause:e});else if(e.name===`SecurityError`){let t=window.location.hostname;if(Fi(t)){if(n.rpId!==t)return new Q({message:`The RP ID "${n.rpId}" is invalid for this domain`,code:`ERROR_INVALID_RP_ID`,cause:e})}else return new Q({message:`${window.location.hostname} is an invalid domain`,code:`ERROR_INVALID_DOMAIN`,cause:e})}else if(e.name===`UnknownError`)return new Q({message:`The authenticator was unable to process the specified options, or could not create a new assertion signature`,code:`ERROR_AUTHENTICATOR_GENERAL_ERROR`,cause:e});return new Q({message:`a Non-Webauthn related error has occurred`,code:`ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,cause:e})}let Ai=new class{createNewAbortSignal(){if(this.controller){let e=Error(`Cancelling existing WebAuthn API call for new one`);e.name=`AbortError`,this.controller.abort(e)}let e=new AbortController;return this.controller=e,e.signal}cancelCeremony(){if(this.controller){let e=Error(`Manually cancelling existing WebAuthn API call`);e.name=`AbortError`,this.controller.abort(e),this.controller=void 0}}};function ji(e){if(!e)throw Error(`Credential creation options are required`);if(typeof PublicKeyCredential<`u`&&`parseCreationOptionsFromJSON`in PublicKeyCredential&&typeof PublicKeyCredential.parseCreationOptionsFromJSON==`function`)return PublicKeyCredential.parseCreationOptionsFromJSON(e);let{challenge:n,user:r,excludeCredentials:i}=e,a=t(e,[`challenge`,`user`,`excludeCredentials`]),o=Sr(n).buffer,s=Object.assign(Object.assign({},r),{id:Sr(r.id).buffer}),c=Object.assign(Object.assign({},a),{challenge:o,user:s});if(i&&i.length>0){c.excludeCredentials=Array(i.length);for(let e=0;e<i.length;e++){let t=i[e];c.excludeCredentials[e]=Object.assign(Object.assign({},t),{id:Sr(t.id).buffer,type:t.type||`public-key`,transports:t.transports})}}return c}function Mi(e){if(!e)throw Error(`Credential request options are required`);if(typeof PublicKeyCredential<`u`&&`parseRequestOptionsFromJSON`in PublicKeyCredential&&typeof PublicKeyCredential.parseRequestOptionsFromJSON==`function`)return PublicKeyCredential.parseRequestOptionsFromJSON(e);let{challenge:n,allowCredentials:r}=e,i=t(e,[`challenge`,`allowCredentials`]),a=Sr(n).buffer,o=Object.assign(Object.assign({},i),{challenge:a});if(r&&r.length>0){o.allowCredentials=Array(r.length);for(let e=0;e<r.length;e++){let t=r[e];o.allowCredentials[e]=Object.assign(Object.assign({},t),{id:Sr(t.id).buffer,type:t.type||`public-key`,transports:t.transports})}}return o}function Ni(e){if(`toJSON`in e&&typeof e.toJSON==`function`)return e.toJSON();let t=e;return{id:e.id,rawId:e.id,response:{attestationObject:z(new Uint8Array(e.response.attestationObject)),clientDataJSON:z(new Uint8Array(e.response.clientDataJSON))},type:`public-key`,clientExtensionResults:e.getClientExtensionResults(),authenticatorAttachment:t.authenticatorAttachment??void 0}}function Pi(e){if(`toJSON`in e&&typeof e.toJSON==`function`)return e.toJSON();let t=e,n=e.getClientExtensionResults(),r=e.response;return{id:e.id,rawId:e.id,response:{authenticatorData:z(new Uint8Array(r.authenticatorData)),clientDataJSON:z(new Uint8Array(r.clientDataJSON)),signature:z(new Uint8Array(r.signature)),userHandle:r.userHandle?z(new Uint8Array(r.userHandle)):void 0},type:`public-key`,clientExtensionResults:n,authenticatorAttachment:t.authenticatorAttachment??void 0}}function Fi(e){return e===`localhost`||/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(e)}function Ii(){return!!(B()&&`PublicKeyCredential`in window&&window.PublicKeyCredential&&`credentials`in navigator&&typeof(navigator==null?void 0:navigator.credentials)?.create==`function`&&typeof(navigator==null?void 0:navigator.credentials)?.get==`function`)}async function Li(e){try{let t=await navigator.credentials.create(e);return t?t instanceof PublicKeyCredential?{data:t,error:null}:{data:null,error:new Di(`Browser returned unexpected credential type`,t)}:{data:null,error:new Di(`Empty credential response`,t)}}catch(t){return{data:null,error:Oi({error:t,options:e})}}}async function Ri(e){try{let t=await navigator.credentials.get(e);return t?t instanceof PublicKeyCredential?{data:t,error:null}:{data:null,error:new Di(`Browser returned unexpected credential type`,t)}:{data:null,error:new Di(`Empty credential response`,t)}}catch(t){return{data:null,error:ki({error:t,options:e})}}}let zi={hints:[`security-key`],authenticatorSelection:{authenticatorAttachment:`cross-platform`,requireResidentKey:!1,userVerification:`preferred`,residentKey:`discouraged`},attestation:`direct`},Bi={userVerification:`preferred`,hints:[`security-key`],attestation:`direct`};function Vi(...e){let t=e=>typeof e==`object`&&!!e&&!Array.isArray(e),n=e=>e instanceof ArrayBuffer||ArrayBuffer.isView(e),r={};for(let i of e)if(i)for(let e in i){let a=i[e];if(a!==void 0)if(Array.isArray(a))r[e]=a;else if(n(a))r[e]=a;else if(t(a)){let n=r[e];t(n)?r[e]=Vi(n,a):r[e]=Vi(a)}else r[e]=a}return r}function Hi(e,t){return Vi(zi,e,t||{})}function Ui(e,t){return Vi(Bi,e,t||{})}var Wi=class{constructor(e){this.client=e,this.enroll=this._enroll.bind(this),this.challenge=this._challenge.bind(this),this.verify=this._verify.bind(this),this.authenticate=this._authenticate.bind(this),this.register=this._register.bind(this)}async _enroll(e){return this.client.mfa.enroll(Object.assign(Object.assign({},e),{factorType:`webauthn`}))}async _challenge({factorId:e,webauthn:t,friendlyName:n,signal:r},i){try{let{data:a,error:o}=await this.client.mfa.challenge({factorId:e,webauthn:t});if(!a)return{data:null,error:o};let s=r??Ai.createNewAbortSignal();if(a.webauthn.type===`create`){let{user:e}=a.webauthn.credential_options.publicKey;if(!e.name){let t=n;if(t)e.name=`${e.id}:${t}`;else{let t=(await this.client.getUser()).data.user,n=t?.user_metadata?.name||t?.email||t?.id||`User`;e.name=`${e.id}:${n}`}}e.displayName||=e.name}switch(a.webauthn.type){case`create`:{let{data:t,error:n}=await Li({publicKey:Hi(a.webauthn.credential_options.publicKey,i?.create),signal:s});return t?{data:{factorId:e,challengeId:a.id,webauthn:{type:a.webauthn.type,credential_response:t}},error:null}:{data:null,error:n}}case`request`:{let t=Ui(a.webauthn.credential_options.publicKey,i?.request),{data:n,error:r}=await Ri(Object.assign(Object.assign({},a.webauthn.credential_options),{publicKey:t,signal:s}));return n?{data:{factorId:e,challengeId:a.id,webauthn:{type:a.webauthn.type,credential_response:n}},error:null}:{data:null,error:r}}}}catch(e){return P(e)?{data:null,error:e}:{data:null,error:new F(`Unexpected error in challenge`,e)}}}async _verify({challengeId:e,factorId:t,webauthn:n}){return this.client.mfa.verify({factorId:t,challengeId:e,webauthn:n})}async _authenticate({factorId:e,webauthn:{rpId:t=typeof window<`u`?window.location.hostname:void 0,rpOrigins:n=typeof window<`u`?[window.location.origin]:void 0,signal:r}={}},i){if(!t)return{data:null,error:new Xn(`rpId is required for WebAuthn authentication`)};try{if(!Ii())return{data:null,error:new F(`Browser does not support WebAuthn`,null)};let{data:a,error:o}=await this.challenge({factorId:e,webauthn:{rpId:t,rpOrigins:n},signal:r},{request:i});if(!a)return{data:null,error:o};let{webauthn:s}=a;return this._verify({factorId:e,challengeId:a.challengeId,webauthn:{type:s.type,rpId:t,rpOrigins:n,credential_response:s.credential_response}})}catch(e){return P(e)?{data:null,error:e}:{data:null,error:new F(`Unexpected error in authenticate`,e)}}}async _register({friendlyName:e,webauthn:{rpId:t=typeof window<`u`?window.location.hostname:void 0,rpOrigins:n=typeof window<`u`?[window.location.origin]:void 0,signal:r}={}},i){if(!t)return{data:null,error:new Xn(`rpId is required for WebAuthn registration`)};try{if(!Ii())return{data:null,error:new F(`Browser does not support WebAuthn`,null)};let{data:a,error:o}=await this._enroll({friendlyName:e});if(!a)return await this.client.mfa.listFactors().then(t=>t.data?.all.find(t=>t.factor_type===`webauthn`&&t.friendly_name===e&&t.status===`unverified`)).then(e=>e?this.client.mfa.unenroll({factorId:e?.id}):void 0),{data:null,error:o};let{data:s,error:c}=await this._challenge({factorId:a.id,friendlyName:a.friendly_name,webauthn:{rpId:t,rpOrigins:n},signal:r},{create:i});return s?this._verify({factorId:a.id,challengeId:s.challengeId,webauthn:{rpId:t,rpOrigins:n,type:s.webauthn.type,credential_response:s.webauthn.credential_response}}):{data:null,error:c}}catch(e){return P(e)?{data:null,error:e}:{data:null,error:new F(`Unexpected error in register`,e)}}}};Si();let Gi={url:`http://localhost:9999`,storageKey:`supabase.auth.token`,autoRefreshToken:!0,persistSession:!0,detectSessionInUrl:!0,headers:Kn,flowType:`implicit`,debug:!1,hasCustomAuthorizationHeader:!1,throwOnError:!1,lockAcquireTimeout:5e3,skipAutoInitialize:!1,experimental:{}},$={},Ki=!1;var qi=class e{get jwks(){return $[this.storageKey]?.jwks??{keys:[]}}set jwks(e){$[this.storageKey]=Object.assign(Object.assign({},$[this.storageKey]),{jwks:e})}get jwks_cached_at(){return $[this.storageKey]?.cachedAt??-(2**53-1)}set jwks_cached_at(e){$[this.storageKey]=Object.assign(Object.assign({},$[this.storageKey]),{cachedAt:e})}constructor(t){var n;this.userStorage=null,this.memoryStorage=null,this.stateChangeEmitters=new Map,this.autoRefreshTicker=null,this.autoRefreshTickTimeout=null,this.visibilityChangedCallback=null,this.refreshingDeferred=null,this.lastRefreshFailure=null,this._sessionRemovalEpoch=0,this.initializePromise=null,this._pendingInitNotifications=null,this.detectSessionInUrl=!0,this.hasCustomAuthorizationHeader=!1,this.suppressGetSessionWarning=!1,this.lock=null,this.lockAcquired=!1,this.pendingInLock=[],this.broadcastChannel=null,this.logger=console.log;let r=Object.assign(Object.assign({},Gi),t);if(this.storageKey=r.storageKey,this.instanceID=e.nextInstanceID[this.storageKey]??0,e.nextInstanceID[this.storageKey]=this.instanceID+1,this.logDebugMessages=!!r.debug,typeof r.debug==`function`&&(this.logger=r.debug),this.instanceID>0&&B()){let e=`${this._logPrefix()} Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.`;console.warn(e),this.logDebugMessages&&console.trace(e)}if(this.persistSession=r.persistSession,this.autoRefreshToken=r.autoRefreshToken,this.experimental=r.experimental??{},this.admin=new mi({url:r.url,headers:r.headers,fetch:r.fetch,experimental:this.experimental}),this.url=r.url,this.headers=r.headers,this.fetch=Or(r.fetch),this.detectSessionInUrl=r.detectSessionInUrl,this.flowType=r.flowType,this.hasCustomAuthorizationHeader=r.hasCustomAuthorizationHeader,this.throwOnError=r.throwOnError,this.lockAcquireTimeout=r.lockAcquireTimeout,r.lock!=null&&(this.lock=r.lock,Ki||(Ki=!0,console.warn(`${this._logPrefix()} The "lock" option is deprecated and will be removed in v3. The client now coordinates session refreshes without a lock, so most apps can drop the option. See https://github.com/supabase/supabase-js/blob/master/packages/core/auth-js/migrations/lockless-coordination.md`))),this.jwks||(this.jwks={keys:[]},this.jwks_cached_at=-(2**53-1)),this.mfa={verify:this._verify.bind(this),enroll:this._enroll.bind(this),unenroll:this._unenroll.bind(this),challenge:this._challenge.bind(this),listFactors:this._listFactors.bind(this),challengeAndVerify:this._challengeAndVerify.bind(this),getAuthenticatorAssuranceLevel:this._getAuthenticatorAssuranceLevel.bind(this),webauthn:new Wi(this),recoveryCodes:{getStatus:this._getRecoveryCodesStatus.bind(this),generate:this._generateRecoveryCodes.bind(this),verify:this._verifyRecoveryCode.bind(this),regenerate:this._regenerateRecoveryCodes.bind(this),unenroll:this._unenrollRecoveryCodes.bind(this)}},this.oauth={getAuthorizationDetails:this._getAuthorizationDetails.bind(this),approveAuthorization:this._approveAuthorization.bind(this),denyAuthorization:this._denyAuthorization.bind(this),listGrants:this._listOAuthGrants.bind(this),revokeGrant:this._revokeOAuthGrant.bind(this)},this.passkey={startRegistration:this._startPasskeyRegistration.bind(this),verifyRegistration:this._verifyPasskeyRegistration.bind(this),startAuthentication:this._startPasskeyAuthentication.bind(this),verifyAuthentication:this._verifyPasskeyAuthentication.bind(this),list:this._listPasskeys.bind(this),update:this._updatePasskey.bind(this),delete:this._deletePasskey.bind(this)},this.persistSession?(r.storage?this.storage=r.storage:Er()?this.storage=globalThis.localStorage:(this.memoryStorage={},this.storage=hi(this.memoryStorage)),r.userStorage&&(this.userStorage=r.userStorage)):(this.memoryStorage={},this.storage=hi(this.memoryStorage)),B()&&globalThis.BroadcastChannel&&this.persistSession&&this.storageKey){try{this.broadcastChannel=new globalThis.BroadcastChannel(this.storageKey)}catch(e){console.error(`Failed to create a new BroadcastChannel, multi-tab state changes will not be available`,e)}(n=this.broadcastChannel)==null||n.addEventListener(`message`,async e=>{this._debug(`received broadcast notification from other tab or client`,e),(e.data.event===`TOKEN_REFRESHED`||e.data.event===`SIGNED_IN`)&&(this.lastRefreshFailure=null);try{await this._notifyAllSubscribers(e.data.event,e.data.session,!1)}catch(e){this._debug(`#broadcastChannel`,`error`,e)}})}r.skipAutoInitialize||this.initialize().catch(e=>{this._debug(`#initialize()`,`error`,e)})}isThrowOnErrorEnabled(){return this.throwOnError}_returnResult(e){if(this.throwOnError&&e&&e.error)throw e.error;return e}_logPrefix(){return`GoTrueClient@${this.storageKey}:${this.instanceID} (${Wn}) ${new Date().toISOString()}`}_debug(...e){return this.logDebugMessages&&this.logger(this._logPrefix(),...e),this}async initialize(){if(this.initializePromise)return await this.initializePromise;this._pendingInitNotifications=[],this.initializePromise=(async()=>this.lock==null?await this._initialize():await this._acquireLock(this.lockAcquireTimeout,async()=>await this._initialize()))();let e=await this.initializePromise,t=this._pendingInitNotifications??[];this._pendingInitNotifications=null;for(let e of t)await this._notifyAllSubscribers(e.event,e.session,e.broadcast);return e}async _initialize(){try{let e={},t=`none`;if(B()&&(e=Dr(window.location.href),this._isImplicitGrantCallback(e)?t=`implicit`:await this._isPKCECallback(e)&&(t=`pkce`)),B()&&this.detectSessionInUrl&&t!==`none`){let{data:n,error:r}=await this._getSessionFromURL(e,t);if(r){if(this._debug(`#_initialize()`,`error detecting session from URL`,r),nr(r)){let e=r.details?.code;if(e===`identity_already_exists`||e===`identity_not_found`||e===`single_identity_not_deletable`)return{error:r}}return{error:r}}let{session:i,redirectType:a}=n;return this._debug(`#_initialize()`,`detected session in URL`,i,`redirect type`,a),await this._saveSession(i),setTimeout(async()=>{a===`recovery`?await this._notifyAllSubscribers(`PASSWORD_RECOVERY`,i):await this._notifyAllSubscribers(`SIGNED_IN`,i)},0),{error:null}}return await this._recoverAndRefresh(),{error:null}}catch(e){return P(e)?this._returnResult({error:e}):this._returnResult({error:new F(`Unexpected error during initialization`,e)})}finally{await this._handleVisibilityChange(),this._debug(`#_initialize()`,`end`)}}async signInAnonymously(e){try{let{data:t,error:n}=await J(this.fetch,`POST`,`${this.url}/signup`,{headers:this.headers,body:{data:e?.options?.data??{},gotrue_meta_security:{captcha_token:e?.options?.captchaToken}},xform:Y});if(n||!t)return this._returnResult({data:{user:null,session:null},error:n});let r=t.session,i=t.user;return t.session&&(await this._saveSession(t.session),await this._notifyAllSubscribers(`SIGNED_IN`,r)),this._returnResult({data:{user:i,session:r},error:null})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async signUp(e){let t=null;try{let n;if(`email`in e){let{email:r,password:i,options:a}=e,o=null,s=null;this.flowType===`pkce`&&([o,s,t]=await this._getCodeChallengeAndMethod()),n=await J(this.fetch,`POST`,`${this.url}/signup`,{headers:this.headers,redirectTo:this._maybeAppendFlowIdToRedirect(a?.emailRedirectTo,t),body:{email:r,password:i,data:a?.data??{},gotrue_meta_security:{captcha_token:a?.captchaToken},code_challenge:o,code_challenge_method:s},xform:Y})}else if(`phone`in e){let{phone:t,password:r,options:i}=e;n=await J(this.fetch,`POST`,`${this.url}/signup`,{headers:this.headers,body:{phone:t,password:r,data:i?.data??{},channel:i?.channel??`sms`,gotrue_meta_security:{captcha_token:i?.captchaToken}},xform:Y})}else throw new er(`You must provide either an email or phone number and a password`);let{data:r,error:i}=n;if(i||!r)return await G(this.storage,this.storageKey,t),this._returnResult({data:{user:null,session:null},error:i});let a=r.session,o=r.user;return r.session&&(await this._saveSession(r.session),await this._notifyAllSubscribers(`SIGNED_IN`,a)),this._returnResult({data:{user:o,session:a},error:null})}catch(e){if(await G(this.storage,this.storageKey,t),P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async signInWithPassword(e){try{let t;if(`email`in e){let{email:n,password:r,options:i}=e;t=await J(this.fetch,`POST`,`${this.url}/token?grant_type=password`,{headers:this.headers,body:{email:n,password:r,gotrue_meta_security:{captcha_token:i?.captchaToken}},xform:ci})}else if(`phone`in e){let{phone:n,password:r,options:i}=e;t=await J(this.fetch,`POST`,`${this.url}/token?grant_type=password`,{headers:this.headers,body:{phone:n,password:r,gotrue_meta_security:{captcha_token:i?.captchaToken}},xform:ci})}else throw new er(`You must provide either an email or phone number and a password`);let{data:n,error:r}=t;if(r)return this._returnResult({data:{user:null,session:null},error:r});if(!n||!n.session||!n.user){let e=new R;return this._returnResult({data:{user:null,session:null},error:e})}return n.session&&(await this._saveSession(n.session),await this._notifyAllSubscribers(`SIGNED_IN`,n.session)),this._returnResult({data:Object.assign({user:n.user,session:n.session},n.weak_password?{weakPassword:n.weak_password}:null),error:r})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async signInWithOAuth(e){return await this._handleProviderSignIn(e.provider,{redirectTo:e.options?.redirectTo,scopes:e.options?.scopes,queryParams:e.options?.queryParams,skipBrowserRedirect:e.options?.skipBrowserRedirect})}async exchangeCodeForSession(e,t){return await this.initializePromise,this.lock==null?this._exchangeCodeForSession(e,t):this._acquireLock(this.lockAcquireTimeout,async()=>this._exchangeCodeForSession(e,t))}async signInWithWeb3(e){let{chain:t}=e;switch(t){case`ethereum`:return await this.signInWithEthereum(e);case`solana`:return await this.signInWithSolana(e);default:throw Error(`@supabase/auth-js: Unsupported chain "${t}"`)}}async signInWithEthereum(e){let t,n;if(`message`in e)t=e.message,n=e.signature;else{let{chain:r,wallet:i,statement:a,options:o}=e,s;if(B())if(typeof i==`object`)s=i;else{let e=window;if(`ethereum`in e&&typeof e.ethereum==`object`&&`request`in e.ethereum&&typeof e.ethereum.request==`function`)s=e.ethereum;else throw Error(`@supabase/auth-js: No compatible Ethereum wallet interface on the window object (window.ethereum) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'ethereum', wallet: resolvedUserWallet }) instead.`)}else{if(typeof i!=`object`||!o?.url)throw Error(`@supabase/auth-js: Both wallet and url must be specified in non-browser environments.`);s=i}let c=new URL(o?.url??window.location.href),l=await s.request({method:`eth_requestAccounts`}).then(e=>e).catch(()=>{throw Error(`@supabase/auth-js: Wallet method eth_requestAccounts is missing or invalid`)});if(!l||l.length===0)throw Error(`@supabase/auth-js: No accounts available. Please ensure the wallet is connected.`);let u=Ci(l[0]),d=o?.signInWithEthereum?.chainId;d||=wi(await s.request({method:`eth_chainId`})),t=Ei({domain:c.host,address:u,statement:a,uri:c.href,version:`1`,chainId:d,nonce:o?.signInWithEthereum?.nonce,issuedAt:o?.signInWithEthereum?.issuedAt??new Date,expirationTime:o?.signInWithEthereum?.expirationTime,notBefore:o?.signInWithEthereum?.notBefore,requestId:o?.signInWithEthereum?.requestId,resources:o?.signInWithEthereum?.resources}),n=await s.request({method:`personal_sign`,params:[Ti(t),u]})}try{let{data:r,error:i}=await J(this.fetch,`POST`,`${this.url}/token?grant_type=web3`,{headers:this.headers,body:Object.assign({chain:`ethereum`,message:t,signature:n},e.options?.captchaToken?{gotrue_meta_security:{captcha_token:e.options?.captchaToken}}:null),xform:Y});if(i)throw i;if(!r||!r.session||!r.user){let e=new R;return this._returnResult({data:{user:null,session:null},error:e})}return r.session&&(await this._saveSession(r.session),await this._notifyAllSubscribers(`SIGNED_IN`,r.session)),this._returnResult({data:Object.assign({},r),error:i})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async signInWithSolana(e){let t,n;if(`message`in e)t=e.message,n=e.signature;else{let{chain:r,wallet:i,statement:a,options:o}=e,s;if(B())if(typeof i==`object`)s=i;else{let e=window;if(`solana`in e&&typeof e.solana==`object`&&(`signIn`in e.solana&&typeof e.solana.signIn==`function`||`signMessage`in e.solana&&typeof e.solana.signMessage==`function`))s=e.solana;else throw Error(`@supabase/auth-js: No compatible Solana wallet interface on the window object (window.solana) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'solana', wallet: resolvedUserWallet }) instead.`)}else{if(typeof i!=`object`||!o?.url)throw Error(`@supabase/auth-js: Both wallet and url must be specified in non-browser environments.`);s=i}let c=new URL(o?.url??window.location.href);if(`signIn`in s&&s.signIn){let e=await s.signIn(Object.assign(Object.assign(Object.assign({issuedAt:new Date().toISOString()},o?.signInWithSolana),{version:`1`,domain:c.host,uri:c.href}),a?{statement:a}:null)),r;if(Array.isArray(e)&&e[0]&&typeof e[0]==`object`)r=e[0];else if(e&&typeof e==`object`&&`signedMessage`in e&&`signature`in e)r=e;else throw Error(`@supabase/auth-js: Wallet method signIn() returned unrecognized value`);if(`signedMessage`in r&&`signature`in r&&(typeof r.signedMessage==`string`||r.signedMessage instanceof Uint8Array)&&r.signature instanceof Uint8Array)t=typeof r.signedMessage==`string`?r.signedMessage:new TextDecoder().decode(r.signedMessage),n=r.signature;else throw Error(`@supabase/auth-js: Wallet method signIn() API returned object without signedMessage and signature fields`)}else{if(!(`signMessage`in s)||typeof s.signMessage!=`function`||!(`publicKey`in s)||typeof s!=`object`||!s.publicKey||!(`toBase58`in s.publicKey)||typeof s.publicKey.toBase58!=`function`)throw Error(`@supabase/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API`);t=[`${c.host} wants you to sign in with your Solana account:`,s.publicKey.toBase58(),...a?[``,a,``]:[``],`Version: 1`,`URI: ${c.href}`,`Issued At: ${o?.signInWithSolana?.issuedAt??new Date().toISOString()}`,...o?.signInWithSolana?.notBefore?[`Not Before: ${o.signInWithSolana.notBefore}`]:[],...o?.signInWithSolana?.expirationTime?[`Expiration Time: ${o.signInWithSolana.expirationTime}`]:[],...o?.signInWithSolana?.chainId?[`Chain ID: ${o.signInWithSolana.chainId}`]:[],...o?.signInWithSolana?.nonce?[`Nonce: ${o.signInWithSolana.nonce}`]:[],...o?.signInWithSolana?.requestId?[`Request ID: ${o.signInWithSolana.requestId}`]:[],...o?.signInWithSolana?.resources?.length?[`Resources`,...o.signInWithSolana.resources.map(e=>`- ${e}`)]:[]].join(`
`);let e=await s.signMessage(new TextEncoder().encode(t),`utf8`);if(!e||!(e instanceof Uint8Array))throw Error(`@supabase/auth-js: Wallet signMessage() API returned an recognized value`);n=e}}try{let{data:r,error:i}=await J(this.fetch,`POST`,`${this.url}/token?grant_type=web3`,{headers:this.headers,body:Object.assign({chain:`solana`,message:t,signature:z(n)},e.options?.captchaToken?{gotrue_meta_security:{captcha_token:e.options?.captchaToken}}:null),xform:Y});if(i)throw i;if(!r||!r.session||!r.user){let e=new R;return this._returnResult({data:{user:null,session:null},error:e})}return r.session&&(await this._saveSession(r.session),await this._notifyAllSubscribers(`SIGNED_IN`,r.session)),this._returnResult({data:Object.assign({},r),error:i})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async _exchangeCodeForSession(e,t){let n=t?.flowId!=null,r=n?zr(t?.flowId):B()?zr(Dr(window.location.href)[N]):null;n&&!r&&this._debug(`#_exchangeCodeForSession()`,`provided flowId is not a valid flow id`,t?.flowId);let{verifier:i,flowId:a}=n&&!r?{verifier:null,flowId:null}:await Gr(this.storage,this.storageKey,r),[o,s]=(i??``).split(`/`);try{if(!o&&this.flowType===`pkce`)throw new ir;let{data:t,error:n}=await J(this.fetch,`POST`,`${this.url}/token?grant_type=pkce`,{headers:this.headers,body:{auth_code:e,code_verifier:o},xform:Y});if(await G(this.storage,this.storageKey,a),n)throw n;if(!t||!t.session||!t.user){let e=new R;return this._returnResult({data:{user:null,session:null,redirectType:null},error:e})}return t.session&&(await this._saveSession(t.session),await this._notifyAllSubscribers(s===`recovery`?`PASSWORD_RECOVERY`:`SIGNED_IN`,t.session)),this._returnResult({data:Object.assign(Object.assign({},t),{redirectType:s??null}),error:n})}catch(e){if(await G(this.storage,this.storageKey,a),P(e))return this._returnResult({data:{user:null,session:null,redirectType:null},error:e});throw e}}async signInWithIdToken(e){try{let{options:t,provider:n,token:r,access_token:i,nonce:a}=e,{data:o,error:s}=await J(this.fetch,`POST`,`${this.url}/token?grant_type=id_token`,{headers:this.headers,body:{provider:n,id_token:r,access_token:i,nonce:a,gotrue_meta_security:{captcha_token:t?.captchaToken}},xform:Y});if(s)return this._returnResult({data:{user:null,session:null},error:s});if(!o||!o.session||!o.user){let e=new R;return this._returnResult({data:{user:null,session:null},error:e})}return o.session&&(await this._saveSession(o.session),await this._notifyAllSubscribers(`SIGNED_IN`,o.session)),this._returnResult({data:o,error:s})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async signInWithOtp(e){let t=null;try{if(`email`in e){let{email:n,options:r}=e,i=null,a=null;this.flowType===`pkce`&&([i,a,t]=await this._getCodeChallengeAndMethod());let{error:o}=await J(this.fetch,`POST`,`${this.url}/otp`,{headers:this.headers,body:{email:n,data:r?.data??{},create_user:r?.shouldCreateUser??!0,gotrue_meta_security:{captcha_token:r?.captchaToken},code_challenge:i,code_challenge_method:a},redirectTo:this._maybeAppendFlowIdToRedirect(r?.emailRedirectTo,t)});return this._returnResult({data:{user:null,session:null},error:o})}if(`phone`in e){let{phone:t,options:n}=e,{data:r,error:i}=await J(this.fetch,`POST`,`${this.url}/otp`,{headers:this.headers,body:{phone:t,data:n?.data??{},create_user:n?.shouldCreateUser??!0,gotrue_meta_security:{captcha_token:n?.captchaToken},channel:n?.channel??`sms`}});return this._returnResult({data:{user:null,session:null,messageId:r?.message_id},error:i})}throw new er(`You must provide either an email or phone number.`)}catch(e){if(await G(this.storage,this.storageKey,t),P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async verifyOtp(e){try{let t,n;`options`in e&&(t=e.options?.redirectTo,n=e.options?.captchaToken);let{data:r,error:i}=await J(this.fetch,`POST`,`${this.url}/verify`,{headers:this.headers,body:Object.assign(Object.assign({},e),{gotrue_meta_security:{captcha_token:n}}),redirectTo:t,xform:Y});if(i)throw i;if(!r)throw Error(`An error occurred on token verification.`);let a=r.session,o=r.user;return a?.access_token&&(await this._saveSession(a),await this._notifyAllSubscribers(e.type==`recovery`?`PASSWORD_RECOVERY`:`SIGNED_IN`,a)),this._returnResult({data:{user:o,session:a},error:null})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async signInWithSSO(e){let t=null;try{let n=null,r=null;this.flowType===`pkce`&&([n,r,t]=await this._getCodeChallengeAndMethod());let i=await J(this.fetch,`POST`,`${this.url}/sso`,{body:Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({},`providerId`in e?{provider_id:e.providerId}:null),`domain`in e?{domain:e.domain}:null),{redirect_to:this._maybeAppendFlowIdToRedirect(e.options?.redirectTo,t)}),e?.options?.captchaToken?{gotrue_meta_security:{captcha_token:e.options.captchaToken}}:null),{skip_http_redirect:!0,code_challenge:n,code_challenge_method:r}),headers:this.headers,xform:li});return i.data?.url&&B()&&!e.options?.skipBrowserRedirect&&window.location.assign(i.data.url),this._returnResult(i)}catch(e){if(await G(this.storage,this.storageKey,t),P(e))return this._returnResult({data:null,error:e});throw e}}async reauthenticate(){return await this.initializePromise,this.lock==null?await this._reauthenticate():await this._acquireLock(this.lockAcquireTimeout,async()=>await this._reauthenticate())}async _reauthenticate(){try{return await this._useSession(async e=>{let{data:{session:t},error:n}=e;if(n)throw n;if(!t)throw new L;let{error:r}=await J(this.fetch,`GET`,`${this.url}/reauthenticate`,{headers:this.headers,jwt:t.access_token});return this._returnResult({data:{user:null,session:null},error:r})})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async resend(e){let t=null;try{let n=`${this.url}/resend`;if(`email`in e){let{email:r,type:i,options:a}=e,o=null,s=null;this.flowType===`pkce`&&([o,s,t]=await this._getCodeChallengeAndMethod());let{error:c}=await J(this.fetch,`POST`,n,{headers:this.headers,body:{email:r,type:i,gotrue_meta_security:{captcha_token:a?.captchaToken},code_challenge:o,code_challenge_method:s},redirectTo:this._maybeAppendFlowIdToRedirect(a?.emailRedirectTo,t)});return c&&await G(this.storage,this.storageKey,t),this._returnResult({data:{user:null,session:null},error:c})}else if(`phone`in e){let{phone:t,type:r,options:i}=e,{data:a,error:o}=await J(this.fetch,`POST`,n,{headers:this.headers,body:{phone:t,type:r,gotrue_meta_security:{captcha_token:i?.captchaToken}}});return this._returnResult({data:{user:null,session:null,messageId:a?.message_id},error:o})}throw new er(`You must provide either an email or phone number and a type`)}catch(e){if(await G(this.storage,this.storageKey,t),P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async getSession(){return await this.initializePromise,this.lock==null?await this._useSession(async e=>e):await this._acquireLock(this.lockAcquireTimeout,async()=>this._useSession(async e=>e))}async _acquireLock(e,t){this._debug(`#_acquireLock`,`begin`,e);try{if(this.lockAcquired){let e=this.pendingInLock.length?this.pendingInLock[this.pendingInLock.length-1]:Promise.resolve(),n=(async()=>(await e,await t()))();return this.pendingInLock.push((async()=>{try{await n}catch{}})()),n}return await this.lock(`lock:${this.storageKey}`,e,async()=>{this._debug(`#_acquireLock`,`lock acquired for storage key`,this.storageKey);try{this.lockAcquired=!0;let e=t();for(this.pendingInLock.push((async()=>{try{await e}catch{}})()),await e;this.pendingInLock.length;){let e=[...this.pendingInLock];await Promise.all(e),this.pendingInLock.splice(0,e.length)}return await e}finally{this._debug(`#_acquireLock`,`lock released for storage key`,this.storageKey),this.lockAcquired=!1}})}finally{this._debug(`#_acquireLock`,`end`)}}async _useSession(e){this._debug(`#_useSession`,`begin`);try{return await e(await this.__loadSession())}finally{this._debug(`#_useSession`,`end`)}}async __loadSession(){this._debug(`#__loadSession()`,`begin`),this.lock!=null&&!this.lockAcquired&&this._debug(`#__loadSession()`,`used outside of an acquired lock!`,Error().stack);try{let e=null,t=await U(this.storage,this.storageKey);if(this._debug(`#getSession()`,`session from storage`,t),t!==null&&(this._isValidSession(t)?e=t:(this._debug(`#getSession()`,`session from storage is not valid`),await this._removeSession())),!e)return{data:{session:null},error:null};let n=e.expires_at?e.expires_at*1e3-Date.now()<Gn:!1;if(this._debug(`#__loadSession()`,`session has${n?``:` not`} expired`,`expires_at`,e.expires_at),!n)return{data:{session:await this._hydrateSessionUser(e)},error:null};let{data:r,error:i}=await this._callRefreshToken(e.refresh_token);if(i){let e=await U(this.storage,this.storageKey);return e&&this._isValidSession(e)&&e.expires_at&&e.expires_at*1e3>Date.now()?this._returnResult({data:{session:await this._hydrateSessionUser(e)},error:null}):this._returnResult({data:{session:null},error:i})}return this._returnResult({data:{session:r},error:null})}finally{this._debug(`#__loadSession()`,`end`)}}async _hydrateSessionUser(e){if(this.userStorage){let t=await U(this.userStorage,this.storageKey+`-user`);e.user=t?.user?t.user:ti()}if(this.storage.isServer&&e.user&&!e.user.__isUserNotAvailableProxy){let t={value:this.suppressGetSessionWarning};e.user=ni(e.user,t),t.value&&(this.suppressGetSessionWarning=!0)}return e}async getUser(e){if(e)return await this._getUser(e);await this.initializePromise;let t;return t=this.lock==null?await this._getUser():await this._acquireLock(this.lockAcquireTimeout,async()=>await this._getUser()),t.data.user&&(this.suppressGetSessionWarning=!0),t}async _getUser(e){try{return e?await J(this.fetch,`GET`,`${this.url}/user`,{headers:this.headers,jwt:e,xform:X}):await this._useSession(async e=>{let{data:t,error:n}=e;if(n)throw n;return!t.session?.access_token&&!this.hasCustomAuthorizationHeader?{data:{user:null},error:new L}:await J(this.fetch,`GET`,`${this.url}/user`,{headers:this.headers,jwt:t.session?.access_token??void 0,xform:X})})}catch(e){if(P(e))return $n(e)&&await this._removeSession(),this._returnResult({data:{user:null},error:e});throw e}}async updateUser(e,t={}){return await this.initializePromise,this.lock==null?await this._updateUser(e,t):await this._acquireLock(this.lockAcquireTimeout,async()=>await this._updateUser(e,t))}async _updateUser(e,t={}){let n=null;try{return await this._useSession(async r=>{let{data:i,error:a}=r;if(a)throw a;if(!i.session)throw new L;let o=i.session,s=null,c=null;this.flowType===`pkce`&&e.email!=null&&([s,c,n]=await this._getCodeChallengeAndMethod());let{data:l,error:u}=await J(this.fetch,`PUT`,`${this.url}/user`,{headers:this.headers,redirectTo:this._maybeAppendFlowIdToRedirect(t?.emailRedirectTo,n),body:Object.assign(Object.assign({},e),{code_challenge:s,code_challenge_method:c}),jwt:o.access_token,xform:X});if(u)throw u;return o.user=l.user,await this._saveSession(o),await this._notifyAllSubscribers(`USER_UPDATED`,o),this._returnResult({data:{user:o.user},error:null})})}catch(e){if(await G(this.storage,this.storageKey,n),P(e))return this._returnResult({data:{user:null},error:e});throw e}}async setSession(e){return await this.initializePromise,this.lock==null?await this._setSession(e):await this._acquireLock(this.lockAcquireTimeout,async()=>await this._setSession(e))}async _setSession(e){try{if(!e.access_token||!e.refresh_token)throw new L;let t=Date.now()/1e3,n=t,r=!0,i=null,{payload:a}=jr(e.access_token);if(a.exp&&(n=a.exp,r=n<=t),r){let{data:t,error:n}=await this._callRefreshToken(e.refresh_token);if(n)return this._returnResult({data:{user:null,session:null},error:n});if(!t)return{data:{user:null,session:null},error:null};i=t}else{let{data:r,error:a}=await this._getUser(e.access_token);if(a)return this._returnResult({data:{user:null,session:null},error:a});i={access_token:e.access_token,refresh_token:e.refresh_token,user:r.user,token_type:`bearer`,expires_in:n-t,expires_at:n},await this._saveSession(i),await this._notifyAllSubscribers(`SIGNED_IN`,i)}return this._returnResult({data:{user:i.user,session:i},error:null})}catch(e){if(P(e))return this._returnResult({data:{session:null,user:null},error:e});throw e}}async refreshSession(e){return await this.initializePromise,this.lock==null?await this._refreshSession(e):await this._acquireLock(this.lockAcquireTimeout,async()=>await this._refreshSession(e))}async _refreshSession(e){try{return await this._useSession(async t=>{if(!e){let{data:n,error:r}=t;if(r)throw r;e=n.session??void 0}if(!e?.refresh_token)throw new L;let{data:n,error:r}=await this._callRefreshToken(e.refresh_token);return r?this._returnResult({data:{user:null,session:null},error:r}):n?this._returnResult({data:{user:n.user,session:n},error:null}):this._returnResult({data:{user:null,session:null},error:null})})}catch(e){if(P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}}async _getSessionFromURL(e,t){try{if(!B())throw new tr(`No browser detected.`);if(e.error||e.error_description||e.error_code)throw new tr(e.error_description||`Error in URL with unspecified error_description`,{error:e.error||`unspecified_error`,code:e.error_code||`unspecified_code`});switch(t){case`implicit`:if(this.flowType===`pkce`)throw new rr(`Not a valid PKCE flow url.`);break;case`pkce`:if(this.flowType===`implicit`)throw new tr(`Not a valid implicit grant flow url.`);break;default:}if(t===`pkce`){if(this._debug(`#_initialize()`,`begin`,`is PKCE flow`,!0),!e.code)throw new rr(`No code detected.`);let{data:t,error:n}=await this._exchangeCodeForSession(e.code,{flowId:e[N]});if(n)throw n;let r=new URL(window.location.href);return r.searchParams.delete(`code`),r.searchParams.delete(N),window.history.replaceState(window.history.state,``,r.toString()),{data:{session:t.session,redirectType:t.redirectType??null},error:null}}let{provider_token:n,provider_refresh_token:r,access_token:i,refresh_token:a,expires_in:o,expires_at:s,token_type:c}=e;if(!i||!o||!a||!c)throw new tr(`No session defined in URL`);let l=Math.round(Date.now()/1e3),u=parseInt(o),d=l+u;s&&(d=parseInt(s));let f=d-l;f*1e3<=M&&console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${f}s, should have been closer to ${u}s`);let p=d-u;l-p>=120?console.warn(`@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale`,p,d,l):l-p<0&&console.warn(`@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew`,p,d,l);let{data:m,error:h}=await this._getUser(i);if(h)throw h;let g={provider_token:n,provider_refresh_token:r,access_token:i,expires_in:u,expires_at:d,refresh_token:a,token_type:c,user:m.user};return window.location.hash=``,this._debug(`#_getSessionFromURL()`,`clearing window.location.hash`),this._returnResult({data:{session:g,redirectType:e.type},error:null})}catch(e){if(P(e))return this._returnResult({data:{session:null,redirectType:null},error:e});throw e}}_isImplicitGrantCallback(e){return typeof this.detectSessionInUrl==`function`?this.detectSessionInUrl(new URL(window.location.href),e):!!(e.access_token||e.error||e.error_description||e.error_code)}async _isPKCECallback(e){if(!e.code)return!1;let t=zr(e[N]);return t&&await U(this.storage,Vr(this.storageKey,t))?!0:!!await U(this.storage,`${this.storageKey}-code-verifier`)}async signOut(e={scope:`global`}){return await this.initializePromise,this.lock==null?await this._signOut(e):await this._acquireLock(this.lockAcquireTimeout,async()=>await this._signOut(e))}async _signOut({scope:e}={scope:`global`}){return await this._useSession(async t=>{let n=async()=>{await this._removeSession()},{data:r,error:i}=t;if(i&&!$n(i))return this._returnResult({error:i});let a=r.session?.access_token;if(a){let{error:t}=await this.admin.signOut(a,e);if(t&&!(Qn(t)&&(t.status===404||t.status===401||t.status===403)||$n(t)))return e!==`others`&&await n(),this._returnResult({error:t})}return e!==`others`&&await n(),this._returnResult({error:null})})}onAuthStateChange(e){let t=Tr(),n={id:t,callback:e,unsubscribe:()=>{this._debug(`#unsubscribe()`,`state change callback with id removed`,t),this.stateChangeEmitters.delete(t)}};return this._debug(`#onAuthStateChange()`,`registered callback with id`,t),this.stateChangeEmitters.set(t,n),(async()=>{await this.initializePromise,this.lock==null?await this._emitInitialSession(t):await this._acquireLock(this.lockAcquireTimeout,async()=>{this._emitInitialSession(t)})})(),{data:{subscription:n}}}async _emitInitialSession(e){return await this._useSession(async t=>{try{let{data:{session:n},error:r}=t;if(r)throw r;await this.stateChangeEmitters.get(e)?.callback(`INITIAL_SESSION`,n),this._debug(`INITIAL_SESSION`,`callback id`,e,`session`,n)}catch(t){if(await this.stateChangeEmitters.get(e)?.callback(`INITIAL_SESSION`,null),this._debug(`INITIAL_SESSION`,`callback id`,e,`error`,t),lr(t))return;$n(t)||sr(t)||Qn(t)&&(t.code===`refresh_token_not_found`||t.code===`refresh_token_already_used`||t.code===`session_expired`)?console.warn(t):console.error(t)}})}async resetPasswordForEmail(e,t={}){let n=null,r=null,i=null;this.flowType===`pkce`&&([n,r,i]=await this._getCodeChallengeAndMethod(!0));try{return await J(this.fetch,`POST`,`${this.url}/recover`,{body:{email:e,code_challenge:n,code_challenge_method:r,gotrue_meta_security:{captcha_token:t.captchaToken}},headers:this.headers,redirectTo:this._maybeAppendFlowIdToRedirect(t.redirectTo,i)})}catch(e){if(await G(this.storage,this.storageKey,i),P(e))return this._returnResult({data:null,error:e});throw e}}async getUserIdentities(){try{let{data:e,error:t}=await this.getUser();if(t)throw t;return this._returnResult({data:{identities:e.user.identities??[]},error:null})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async linkIdentity(e){return`token`in e?this.linkIdentityIdToken(e):this.linkIdentityOAuth(e)}async linkIdentityOAuth(e){let t=null;try{let{data:n,error:r}=await this._useSession(async n=>{let{data:r,error:i}=n;if(i)throw i;let{url:a,flowId:o}=await this._getUrlForProvider(`${this.url}/user/identities/authorize`,e.provider,{redirectTo:e.options?.redirectTo,scopes:e.options?.scopes,queryParams:e.options?.queryParams,skipBrowserRedirect:!0});return t=o,await J(this.fetch,`GET`,a,{headers:this.headers,jwt:r.session?.access_token??void 0})});if(r)throw r;return B()&&!e.options?.skipBrowserRedirect&&window.location.assign(n?.url),this._returnResult({data:{provider:e.provider,url:n?.url,flowId:t},error:null})}catch(n){if(P(n))return this._returnResult({data:{provider:e.provider,url:null,flowId:t},error:n});throw n}}async linkIdentityIdToken(e){return await this._useSession(async t=>{try{let{error:n,data:{session:r}}=t;if(n)throw n;let{options:i,provider:a,token:o,access_token:s,nonce:c}=e,{data:l,error:u}=await J(this.fetch,`POST`,`${this.url}/token?grant_type=id_token`,{headers:this.headers,jwt:r?.access_token??void 0,body:{provider:a,id_token:o,access_token:s,nonce:c,link_identity:!0,gotrue_meta_security:{captcha_token:i?.captchaToken}},xform:Y});return u?this._returnResult({data:{user:null,session:null},error:u}):!l||!l.session||!l.user?this._returnResult({data:{user:null,session:null},error:new R}):(l.session&&(await this._saveSession(l.session),await this._notifyAllSubscribers(`USER_UPDATED`,l.session)),this._returnResult({data:l,error:u}))}catch(e){if(await G(this.storage,this.storageKey,null),P(e))return this._returnResult({data:{user:null,session:null},error:e});throw e}})}async unlinkIdentity(e){try{return await this._useSession(async t=>{let{data:n,error:r}=t;if(r)throw r;return await J(this.fetch,`DELETE`,`${this.url}/user/identities/${e.identity_id}`,{headers:this.headers,jwt:n.session?.access_token??void 0})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _refreshAccessToken(e){let t=`#_refreshAccessToken()`;this._debug(t,`begin`);try{let n=Date.now();return await Nr(async n=>(n>0&&await Mr(200*2**(n-1)),this._debug(t,`refreshing attempt`,n),await J(this.fetch,`POST`,`${this.url}/token?grant_type=refresh_token`,{body:{refresh_token:e},headers:this.headers,xform:Y})),(e,t)=>{let r=200*2**e;return t&&sr(t)&&Date.now()+r-n<M})}catch(e){if(this._debug(t,`error`,e),P(e))return this._returnResult({data:{session:null,user:null},error:e});throw e}finally{this._debug(t,`end`)}}_isValidSession(e){return typeof e==`object`&&!!e&&`access_token`in e&&`refresh_token`in e&&`expires_at`in e}async _handleProviderSignIn(e,t){let{url:n,flowId:r}=await this._getUrlForProvider(`${this.url}/authorize`,e,{redirectTo:t.redirectTo,scopes:t.scopes,queryParams:t.queryParams});return this._debug(`#_handleProviderSignIn()`,`provider`,e,`options`,t,`url`,n),B()&&!t.skipBrowserRedirect&&window.location.assign(n),{data:{provider:e,url:n,flowId:r},error:null}}async _recoverAndRefresh(){let e=`#_recoverAndRefresh()`;this._debug(e,`begin`);try{let t=await U(this.storage,this.storageKey);if(t&&this.userStorage){let e=await U(this.userStorage,this.storageKey+`-user`);!this.storage.isServer&&Object.is(this.storage,this.userStorage)&&!e&&(e={user:t.user},await H(this.userStorage,this.storageKey+`-user`,e)),t.user=e?.user??ti()}else if(t&&!t.user&&!t.user){let e=await U(this.storage,this.storageKey+`-user`);e&&e?.user?(t.user=e.user,await W(this.storage,this.storageKey+`-user`),await H(this.storage,this.storageKey,t)):t.user=ti()}if(this._debug(e,`session from storage`,t),!this._isValidSession(t)){this._debug(e,`session is not valid`),t!==null&&await this._removeSession();return}let n=(t.expires_at??1/0)*1e3-Date.now()<Gn;if(this._debug(e,`session has${n?``:` not`} expired with margin of ${Gn}s`),n){if(this.autoRefreshToken&&t.refresh_token){let{error:n}=await this._callRefreshToken(t.refresh_token);n&&(lr(n)?this._debug(e,`refresh discarded by commit guard`,n):this._debug(e,`refresh failed`,n))}}else if(t.user&&t.user.__isUserNotAvailableProxy===!0)try{let{data:n,error:r}=await this._getUser(t.access_token);!r&&n?.user?(t.user=n.user,await this._saveSession(t),await this._notifyAllSubscribers(`SIGNED_IN`,t)):this._debug(e,`could not get user data, skipping SIGNED_IN notification`)}catch(t){console.error(`Error getting user data:`,t),this._debug(e,`error getting user data, skipping SIGNED_IN notification`,t)}else await this._notifyAllSubscribers(`SIGNED_IN`,t)}catch(t){this._debug(e,`error`,t),sr(t)?console.warn(t):console.error(t);return}finally{this._debug(e,`end`)}}async _callRefreshToken(e){var t,n;if(!e)throw new L;if(this.refreshingDeferred)return this.refreshingDeferred.promise;if(this.lastRefreshFailure&&this.lastRefreshFailure.refreshToken===e&&Date.now()<this.lastRefreshFailure.expiresAt)return this._debug(`#_callRefreshToken()`,`returning cached failure (cooldown active)`),this.lastRefreshFailure.result;let r=`#_callRefreshToken()`;this._debug(r,`begin`);try{this.refreshingDeferred=new Ar,this.refreshingDeferred.promise.then(void 0,()=>{});let t=await U(this.storage,this.storageKey),{data:n,error:i}=await this._refreshAccessToken(e);if(i)throw i;if(!n.session)throw new L;let a=await U(this.storage,this.storageKey);if(t!==null&&(a===null||a.refresh_token!==t.refresh_token)){this._debug(r,`commit guard: storage changed since refresh started, discarding rotated tokens`,{startedWith:`present`,nowHolds:a?`replaced`:`cleared`});let e={data:null,error:new cr};return this.refreshingDeferred.resolve(e),e}let o=this._sessionRemovalEpoch;if(await this._saveSession(n.session),this._sessionRemovalEpoch!==o){this._debug(r,`commit guard (post-save): _removeSession ran during _saveSession, undoing write`),await W(this.storage,this.storageKey),this.userStorage&&await W(this.userStorage,this.storageKey+`-user`);let e={data:null,error:new cr};return this.refreshingDeferred.resolve(e),e}await this._notifyAllSubscribers(`TOKEN_REFRESHED`,n.session);let s={data:n.session,error:null};return this.lastRefreshFailure=null,this.refreshingDeferred.resolve(s),s}catch(i){if(this._debug(r,`error`,i),P(i)){let n={data:null,error:i};if(!sr(i)){let e=await U(this.storage,this.storageKey);e?.expires_at&&e.expires_at*1e3>Date.now()?this._debug(r,`proactive refresh failed, access token still valid — preserving session`):await this._removeSession()}return this.lastRefreshFailure={refreshToken:e,result:n,expiresAt:Date.now()+6e4},(t=this.refreshingDeferred)==null||t.resolve(n),n}throw(n=this.refreshingDeferred)==null||n.reject(i),i}finally{this.refreshingDeferred=null,this._debug(r,`end`)}}async _notifyAllSubscribers(e,t,n=!0){if(this._pendingInitNotifications!==null&&n){this._pendingInitNotifications.push({event:e,session:t,broadcast:n});return}let r=`#_notifyAllSubscribers(${e})`;this._debug(r,`begin`,t,`broadcast = ${n}`);try{this.broadcastChannel&&n&&this.broadcastChannel.postMessage({event:e,session:t});let r=[],i=Array.from(this.stateChangeEmitters.values()).map(async n=>{try{await n.callback(e,t)}catch(e){r.push(e)}});if(await Promise.all(i),r.length>0){for(let e=0;e<r.length;e+=1)console.error(r[e]);throw r[0]}}finally{this._debug(r,`end`)}}async _saveSession(e){this._debug(`#_saveSession()`,e),this.suppressGetSessionWarning=!0;let t=Object.assign({},e),n=t.user&&t.user.__isUserNotAvailableProxy===!0;if(this.userStorage){!n&&t.user&&await H(this.userStorage,this.storageKey+`-user`,{user:t.user});let e=Object.assign({},t);delete e.user;let r=ri(e);await H(this.storage,this.storageKey,r)}else{let e=ri(t);await H(this.storage,this.storageKey,e)}}async _removeSession(){this._sessionRemovalEpoch+=1,this._debug(`#_removeSession()`),this.lastRefreshFailure=null,this.suppressGetSessionWarning=!1,await W(this.storage,this.storageKey),await Kr(this.storage,this.storageKey),await W(this.storage,this.storageKey+`-user`),this.userStorage&&await W(this.userStorage,this.storageKey+`-user`),await this._notifyAllSubscribers(`SIGNED_OUT`,null)}_removeVisibilityChangedCallback(){this._debug(`#_removeVisibilityChangedCallback()`);let e=this.visibilityChangedCallback;this.visibilityChangedCallback=null;try{e&&B()&&window!=null&&window.removeEventListener&&window.removeEventListener(`visibilitychange`,e)}catch(e){console.error(`removing visibilitychange callback failed`,e)}}async _startAutoRefresh(){await this._stopAutoRefresh(),this._debug(`#_startAutoRefresh()`);let e=setInterval(()=>this._autoRefreshTokenTick(),M);this.autoRefreshTicker=e,e&&typeof e==`object`&&typeof e.unref==`function`?e.unref():typeof Deno<`u`&&typeof Deno.unrefTimer==`function`&&Deno.unrefTimer(e);let t=setTimeout(async()=>{await this.initializePromise,await this._autoRefreshTokenTick()},0);this.autoRefreshTickTimeout=t,t&&typeof t==`object`&&typeof t.unref==`function`?t.unref():typeof Deno<`u`&&typeof Deno.unrefTimer==`function`&&Deno.unrefTimer(t)}async _stopAutoRefresh(){this._debug(`#_stopAutoRefresh()`);let e=this.autoRefreshTicker;this.autoRefreshTicker=null,e&&clearInterval(e);let t=this.autoRefreshTickTimeout;this.autoRefreshTickTimeout=null,t&&clearTimeout(t)}async startAutoRefresh(){this._removeVisibilityChangedCallback(),await this._startAutoRefresh()}async stopAutoRefresh(){this._removeVisibilityChangedCallback(),await this._stopAutoRefresh()}async dispose(){var e;this._removeVisibilityChangedCallback(),await this._stopAutoRefresh(),(e=this.broadcastChannel)==null||e.close(),this.broadcastChannel=null,this.stateChangeEmitters.clear()}async _autoRefreshTokenTick(){if(this._debug(`#_autoRefreshTokenTick()`,`begin`),this.lock!=null){try{await this._acquireLock(0,async()=>{try{let e=Date.now();try{return await this._useSession(async t=>{let{data:{session:n}}=t;if(!n||!n.refresh_token||!n.expires_at){this._debug(`#_autoRefreshTokenTick()`,`no session`);return}let r=Math.floor((n.expires_at*1e3-e)/M);this._debug(`#_autoRefreshTokenTick()`,`access token expires in ${r} ticks, a tick lasts ${M}ms, refresh threshold is 3 ticks`),r<=3&&await this._callRefreshToken(n.refresh_token)})}catch(e){console.error(`Auto refresh tick failed with error. This is likely a transient error.`,e)}}finally{this._debug(`#_autoRefreshTokenTick()`,`end`)}})}catch(e){if(e instanceof gi)this._debug(`auto refresh token tick lock not available`);else throw e}return}if(this.refreshingDeferred!==null){this._debug(`#_autoRefreshTokenTick()`,`refresh already in flight, skipping`);return}try{let e=Date.now();try{await this._useSession(async t=>{let{data:{session:n}}=t;if(!n||!n.refresh_token||!n.expires_at){this._debug(`#_autoRefreshTokenTick()`,`no session`);return}let r=Math.floor((n.expires_at*1e3-e)/M);this._debug(`#_autoRefreshTokenTick()`,`access token expires in ${r} ticks, a tick lasts ${M}ms, refresh threshold is 3 ticks`),r<=3&&await this._callRefreshToken(n.refresh_token)})}catch(e){console.error(`Auto refresh tick failed with error. This is likely a transient error.`,e)}}finally{this._debug(`#_autoRefreshTokenTick()`,`end`)}}async _handleVisibilityChange(){if(this._debug(`#_handleVisibilityChange()`),!B()||!(window!=null&&window.addEventListener))return this.autoRefreshToken&&this.startAutoRefresh(),!1;try{this.visibilityChangedCallback=async()=>{try{await this._onVisibilityChanged(!1)}catch(e){this._debug(`#visibilityChangedCallback`,`error`,e)}},window==null||window.addEventListener(`visibilitychange`,this.visibilityChangedCallback),await this._onVisibilityChanged(!0)}catch(e){console.error(`_handleVisibilityChange`,e)}}async _onVisibilityChanged(e){let t=`#_onVisibilityChanged(${e})`;if(this._debug(t,`visibilityState`,document.visibilityState),document.visibilityState===`visible`){if(this.autoRefreshToken&&this._startAutoRefresh(),!e)if(await this.initializePromise,this.lock!=null)await this._acquireLock(this.lockAcquireTimeout,async()=>{if(document.visibilityState!==`visible`){this._debug(t,`acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting`);return}await this._recoverAndRefresh()});else{if(document.visibilityState!==`visible`){this._debug(t,`visibilityState is no longer visible, skipping recovery`);return}await this._recoverAndRefresh()}}else document.visibilityState===`hidden`&&this.autoRefreshToken&&this._stopAutoRefresh()}async _getUrlForProvider(e,t,n){let r=n?.redirectTo,i=null,a=null,o=null;this.flowType===`pkce`&&([i,a,o]=await this._getCodeChallengeAndMethod(),r=this._maybeAppendFlowIdToRedirect(r,o));let s=[`provider=${encodeURIComponent(t)}`];if(r&&s.push(`redirect_to=${encodeURIComponent(r)}`),n?.scopes&&s.push(`scopes=${encodeURIComponent(n.scopes)}`),i!=null&&a!=null){let e=new URLSearchParams({code_challenge:`${encodeURIComponent(i)}`,code_challenge_method:`${encodeURIComponent(a)}`});s.push(e.toString())}if(n?.queryParams){let e=new URLSearchParams(n.queryParams);s.push(e.toString())}return n?.skipBrowserRedirect&&s.push(`skip_http_redirect=${n.skipBrowserRedirect}`),{url:`${e}?${s.join(`&`)}`,flowId:o}}_maybeAppendFlowIdToRedirect(e,t){return!e||!t||!this.experimental.appendPkceFlowIdToRedirects?e??void 0:qr(e,t)}async _getCodeChallengeAndMethod(e=!1){return Jr(this.storage,this.storageKey,e,e=>this._debug(`#_getCodeChallengeAndMethod()`,`evicted oldest pending PKCE verifier slot`,e))}async _unenroll(e){try{return await this._useSession(async t=>{let{data:n,error:r}=t;return r?this._returnResult({data:null,error:r}):await J(this.fetch,`DELETE`,`${this.url}/factors/${e.factorId}`,{headers:this.headers,jwt:n?.session?.access_token})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _enroll(e){try{return await this._useSession(async t=>{let{data:n,error:r}=t;if(r)return this._returnResult({data:null,error:r});let i=Object.assign({friendly_name:e.friendlyName,factor_type:e.factorType},e.factorType===`phone`?{phone:e.phone}:e.factorType===`totp`?{issuer:e.issuer}:{}),{data:a,error:o}=await J(this.fetch,`POST`,`${this.url}/factors`,{body:i,headers:this.headers,jwt:n?.session?.access_token});return o?this._returnResult({data:null,error:o}):(e.factorType===`totp`&&a.type===`totp`&&a?.totp?.qr_code&&(a.totp.qr_code=`data:image/svg+xml;utf-8,${a.totp.qr_code}`),this._returnResult({data:a,error:null}))})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _verify(e){let t=async()=>{try{return await this._useSession(async t=>{let{data:n,error:r}=t;if(r)return this._returnResult({data:null,error:r});let i=Object.assign({challenge_id:e.challengeId},`webauthn`in e?{webauthn:Object.assign(Object.assign({},e.webauthn),{credential_response:e.webauthn.type===`create`?Ni(e.webauthn.credential_response):Pi(e.webauthn.credential_response)})}:{code:e.code}),{data:a,error:o}=await J(this.fetch,`POST`,`${this.url}/factors/${e.factorId}/verify`,{body:i,headers:this.headers,jwt:n?.session?.access_token});return o?this._returnResult({data:null,error:o}):(await this._saveSession(Object.assign({expires_at:Math.round(Date.now()/1e3)+a.expires_in},a)),await this._notifyAllSubscribers(`MFA_CHALLENGE_VERIFIED`,a),this._returnResult({data:a,error:o}))})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}};return this.lock==null?t():this._acquireLock(this.lockAcquireTimeout,t)}async _challenge(e){let t=async()=>{try{return await this._useSession(async t=>{let{data:n,error:r}=t;if(r)return this._returnResult({data:null,error:r});let i=await J(this.fetch,`POST`,`${this.url}/factors/${e.factorId}/challenge`,{body:e,headers:this.headers,jwt:n?.session?.access_token});if(i.error)return i;let{data:a}=i;if(a.type!==`webauthn`)return{data:a,error:null};switch(a.webauthn.type){case`create`:return{data:Object.assign(Object.assign({},a),{webauthn:Object.assign(Object.assign({},a.webauthn),{credential_options:Object.assign(Object.assign({},a.webauthn.credential_options),{publicKey:ji(a.webauthn.credential_options.publicKey)})})}),error:null};case`request`:return{data:Object.assign(Object.assign({},a),{webauthn:Object.assign(Object.assign({},a.webauthn),{credential_options:Object.assign(Object.assign({},a.webauthn.credential_options),{publicKey:Mi(a.webauthn.credential_options.publicKey)})})}),error:null}}})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}};return this.lock==null?t():this._acquireLock(this.lockAcquireTimeout,t)}async _challengeAndVerify(e){let{data:t,error:n}=await this._challenge({factorId:e.factorId});return n?this._returnResult({data:null,error:n}):await this._verify({factorId:e.factorId,challengeId:t.id,code:e.code})}async _listFactors(){let{data:{user:e},error:t}=await this.getUser();if(t)return{data:null,error:t};let n={all:[],phone:[],totp:[],webauthn:[],recovery_code:[]};for(let t of e?.factors??[])n.all.push(t),t.status===`verified`&&t.factor_type in n&&Array.isArray(n[t.factor_type])&&n[t.factor_type].push(t);return{data:n,error:null}}async _getAuthenticatorAssuranceLevel(e){if(e)try{let{payload:t}=jr(e),n=null;t.aal&&(n=t.aal);let r=n,{data:{user:i},error:a}=await this.getUser(e);if(a)return this._returnResult({data:null,error:a});((i?.factors)?.filter(e=>e.status===`verified`)??[]).length>0&&(r=`aal2`);let o=t.amr||[];return{data:{currentLevel:n,nextLevel:r,currentAuthenticationMethods:o},error:null}}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}let{data:{session:t},error:n}=await this.getSession();if(n)return this._returnResult({data:null,error:n});if(!t)return{data:{currentLevel:null,nextLevel:null,currentAuthenticationMethods:[]},error:null};let{payload:r}=jr(t.access_token),i=null;r.aal&&(i=r.aal);let a=i;(t.user.factors?.filter(e=>e.status===`verified`)??[]).length>0&&(a=`aal2`);let o=r.amr||[];return{data:{currentLevel:i,nextLevel:a,currentAuthenticationMethods:o},error:null}}async _getRecoveryCodesStatus(){ei(this.experimental);try{return await this._useSession(async e=>{let{data:t,error:n}=e;if(n)return this._returnResult({data:null,error:n});let{data:r,error:i}=await J(this.fetch,`GET`,`${this.url}/factors/recovery-codes`,{headers:this.headers,jwt:t?.session?.access_token});return i?this._returnResult({data:null,error:i}):this._returnResult({data:r,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _generateRecoveryCodes(e){ei(this.experimental);try{return await this._useSession(async t=>{let{data:n,error:r}=t;if(r)return this._returnResult({data:null,error:r});let{data:i,error:a}=await J(this.fetch,`POST`,`${this.url}/factors/recovery-codes`,{body:e?.friendlyName?{friendly_name:e.friendlyName}:void 0,headers:this.headers,jwt:n?.session?.access_token});return a?this._returnResult({data:null,error:a}):this._returnResult({data:i,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _verifyRecoveryCode(e){ei(this.experimental);let t=async()=>{try{return await this._useSession(async t=>{let{data:n,error:r}=t;if(r)return this._returnResult({data:null,error:r});let{data:i,error:a}=await J(this.fetch,`POST`,`${this.url}/factors/recovery-codes/verify`,{body:{code:e.code},headers:this.headers,jwt:n?.session?.access_token});if(a)return this._returnResult({data:null,error:a});let o=Object.assign({expires_at:wr(i.expires_in)},i);return await this._saveSession(o),await this._notifyAllSubscribers(`MFA_CHALLENGE_VERIFIED`,o),this._returnResult({data:i,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}};return this.lock==null?t():this._acquireLock(this.lockAcquireTimeout,t)}async _regenerateRecoveryCodes(){ei(this.experimental);try{return await this._useSession(async e=>{let{data:t,error:n}=e;if(n)return this._returnResult({data:null,error:n});let{data:r,error:i}=await J(this.fetch,`POST`,`${this.url}/factors/recovery-codes/regenerate`,{headers:this.headers,jwt:t?.session?.access_token});return i?this._returnResult({data:null,error:i}):this._returnResult({data:r,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _unenrollRecoveryCodes(){ei(this.experimental);try{return await this._useSession(async e=>{let{data:t,error:n}=e;if(n)return this._returnResult({data:null,error:n});let{data:r,error:i}=await J(this.fetch,`DELETE`,`${this.url}/factors/recovery-codes`,{headers:this.headers,jwt:t?.session?.access_token});return i?this._returnResult({data:null,error:i}):this._returnResult({data:r,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _getAuthorizationDetails(e){try{return await this._useSession(async t=>{let{data:{session:n},error:r}=t;return r?this._returnResult({data:null,error:r}):n?await J(this.fetch,`GET`,`${this.url}/oauth/authorizations/${e}`,{headers:this.headers,jwt:n.access_token,xform:e=>({data:e,error:null})}):this._returnResult({data:null,error:new L})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _approveAuthorization(e,t){try{return await this._useSession(async n=>{let{data:{session:r},error:i}=n;if(i)return this._returnResult({data:null,error:i});if(!r)return this._returnResult({data:null,error:new L});let a=await J(this.fetch,`POST`,`${this.url}/oauth/authorizations/${e}/consent`,{headers:this.headers,jwt:r.access_token,body:{action:`approve`},xform:e=>({data:e,error:null})});return a.data&&a.data.redirect_url&&B()&&!t?.skipBrowserRedirect&&window.location.assign(a.data.redirect_url),a})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _denyAuthorization(e,t){try{return await this._useSession(async n=>{let{data:{session:r},error:i}=n;if(i)return this._returnResult({data:null,error:i});if(!r)return this._returnResult({data:null,error:new L});let a=await J(this.fetch,`POST`,`${this.url}/oauth/authorizations/${e}/consent`,{headers:this.headers,jwt:r.access_token,body:{action:`deny`},xform:e=>({data:e,error:null})});return a.data&&a.data.redirect_url&&B()&&!t?.skipBrowserRedirect&&window.location.assign(a.data.redirect_url),a})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _listOAuthGrants(){try{return await this._useSession(async e=>{let{data:{session:t},error:n}=e;return n?this._returnResult({data:null,error:n}):t?await J(this.fetch,`GET`,`${this.url}/user/oauth/grants`,{headers:this.headers,jwt:t.access_token,xform:e=>({data:e,error:null})}):this._returnResult({data:null,error:new L})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _revokeOAuthGrant(e){try{return await this._useSession(async t=>{let{data:{session:n},error:r}=t;return r?this._returnResult({data:null,error:r}):n?(await J(this.fetch,`DELETE`,`${this.url}/user/oauth/grants`,{headers:this.headers,jwt:n.access_token,query:{client_id:e.clientId},noResolveJson:!0}),{data:{},error:null}):this._returnResult({data:null,error:new L})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async fetchJwk(e,t={keys:[]}){let n=t.keys.find(t=>t.kid===e);if(n)return n;let r=Date.now();if(n=this.jwks.keys.find(t=>t.kid===e),n&&this.jwks_cached_at+6e5>r)return n;let{data:i,error:a}=await J(this.fetch,`GET`,`${this.url}/.well-known/jwks.json`,{headers:this.headers});if(a)throw a;return!i.keys||i.keys.length===0||(this.jwks=i,this.jwks_cached_at=r,n=i.keys.find(t=>t.kid===e),!n)?null:n}async getClaims(e,t={}){try{let n=e;if(!n){let{data:e,error:t}=await this.getSession();if(t||!e.session)return this._returnResult({data:null,error:t});n=e.session.access_token}let{header:r,payload:i,signature:a,raw:{header:o,payload:s}}=jr(n);if(!t?.allowExpired)try{Zr(i.exp)}catch(e){throw new fr(e instanceof Error?e.message:`JWT validation failed`)}let c=!r.alg||r.alg.startsWith(`HS`)||!r.kid||!(`crypto`in globalThis&&`subtle`in globalThis.crypto)?null:await this.fetchJwk(r.kid,t?.keys?{keys:t.keys}:t?.jwks);if(!c){let{error:e}=await this.getUser(n);if(e)throw e;return{data:{claims:i,header:r,signature:a},error:null}}let l=Qr(r.alg),u=await crypto.subtle.importKey(`jwk`,c,l,!0,[`verify`]);if(!await crypto.subtle.verify(l,u,a,Cr(`${o}.${s}`)))throw new fr(`Invalid JWT signature`);return{data:{claims:i,header:r,signature:a},error:null}}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async signInWithPasskey(e){try{if(!Ii())return this._returnResult({data:null,error:new F(`Browser does not support WebAuthn`,null)});let{data:t,error:n}=await this._startPasskeyAuthentication({options:{captchaToken:e?.options?.captchaToken}});if(n||!t)return this._returnResult({data:null,error:n});let{data:r,error:i}=await Ri({publicKey:Mi(t.options),signal:e?.options?.signal??Ai.createNewAbortSignal(),mediation:e?.options?.mediation});if(i||!r)return this._returnResult({data:null,error:i??new F(`WebAuthn ceremony failed`,null)});let a=Pi(r);return this._verifyPasskeyAuthentication({challengeId:t.challenge_id,credential:a})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async registerPasskey(e){try{if(!Ii())return this._returnResult({data:null,error:new F(`Browser does not support WebAuthn`,null)});let{data:t,error:n}=await this._startPasskeyRegistration();if(n||!t)return this._returnResult({data:null,error:n});let{data:r,error:i}=await Li({publicKey:ji(t.options),signal:e?.options?.signal??Ai.createNewAbortSignal()});if(i||!r)return this._returnResult({data:null,error:i??new F(`WebAuthn ceremony failed`,null)});let a=Ni(r);return this._verifyPasskeyRegistration({challengeId:t.challenge_id,credential:a})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _startPasskeyRegistration(){try{return await this._useSession(async e=>{let{data:{session:t},error:n}=e;if(n)return this._returnResult({data:null,error:n});if(!t)return this._returnResult({data:null,error:new L});let{data:r,error:i}=await J(this.fetch,`POST`,`${this.url}/passkeys/registration/options`,{headers:this.headers,jwt:t.access_token,body:{}});return i?this._returnResult({data:null,error:i}):this._returnResult({data:r,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _verifyPasskeyRegistration(e){try{return await this._useSession(async t=>{let{data:{session:n},error:r}=t;if(r)return this._returnResult({data:null,error:r});if(!n)return this._returnResult({data:null,error:new L});let{data:i,error:a}=await J(this.fetch,`POST`,`${this.url}/passkeys/registration/verify`,{headers:this.headers,jwt:n.access_token,body:{challenge_id:e.challengeId,credential:e.credential}});return a?this._returnResult({data:null,error:a}):this._returnResult({data:i,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _startPasskeyAuthentication(e){try{let{data:t,error:n}=await J(this.fetch,`POST`,`${this.url}/passkeys/authentication/options`,{headers:this.headers,body:{gotrue_meta_security:{captcha_token:e?.options?.captchaToken}}});return n?this._returnResult({data:null,error:n}):this._returnResult({data:t,error:null})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _verifyPasskeyAuthentication(e){try{let{data:t,error:n}=await J(this.fetch,`POST`,`${this.url}/passkeys/authentication/verify`,{headers:this.headers,body:{challenge_id:e.challengeId,credential:e.credential},xform:Y});return n?this._returnResult({data:null,error:n}):(t.session&&(await this._saveSession(t.session),await this._notifyAllSubscribers(`SIGNED_IN`,t.session)),this._returnResult({data:t,error:null}))}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _listPasskeys(){try{return await this._useSession(async e=>{let{data:{session:t},error:n}=e;if(n)return this._returnResult({data:null,error:n});if(!t)return this._returnResult({data:null,error:new L});let{data:r,error:i}=await J(this.fetch,`GET`,`${this.url}/passkeys`,{headers:this.headers,jwt:t.access_token,xform:e=>({data:e,error:null})});return i?this._returnResult({data:null,error:i}):this._returnResult({data:r,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _updatePasskey(e){try{return await this._useSession(async t=>{let{data:{session:n},error:r}=t;if(r)return this._returnResult({data:null,error:r});if(!n)return this._returnResult({data:null,error:new L});let{data:i,error:a}=await J(this.fetch,`PATCH`,`${this.url}/passkeys/${e.passkeyId}`,{headers:this.headers,jwt:n.access_token,body:{friendly_name:e.friendlyName}});return a?this._returnResult({data:null,error:a}):this._returnResult({data:i,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}async _deletePasskey(e){try{return await this._useSession(async t=>{let{data:{session:n},error:r}=t;if(r)return this._returnResult({data:null,error:r});if(!n)return this._returnResult({data:null,error:new L});let{error:i}=await J(this.fetch,`DELETE`,`${this.url}/passkeys/${e.passkeyId}`,{headers:this.headers,jwt:n.access_token,noResolveJson:!0});return i?this._returnResult({data:null,error:i}):this._returnResult({data:null,error:null})})}catch(e){if(P(e))return this._returnResult({data:null,error:e});throw e}}};qi.nextInstanceID={};var Ji=qi,Yi=mi,Xi=Ji,Zi=class extends Xi{constructor(e){super(e)}},Qi=class{constructor(e,t,n){this.supabaseUrl=e,this.supabaseKey=t;let r=Un(e);if(!t)throw Error(`supabaseKey is required.`);Nn(t),Vn(n),this.realtimeUrl=new URL(`realtime/v1`,r),this.realtimeUrl.protocol=this.realtimeUrl.protocol.replace(`http`,`ws`),this.authUrl=new URL(`auth/v1`,r),this.storageUrl=new URL(`storage/v1`,r),this.functionsUrl=new URL(`functions/v1`,r);let i=`sb-${r.hostname.split(`.`)[0]}-auth-token`,a={db:yn,realtime:xn,auth:{...bn,storageKey:i},global:vn,tracePropagation:Sn},o=Hn(n??{},a);this.settings=o,this.storageKey=o.auth.storageKey??``,this.headers=o.global.headers??{},o.accessToken?(this.accessToken=o.accessToken,this.auth=new Proxy({},{get:(e,t)=>{throw Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(t)} is not possible`)}})):this.auth=this._initSupabaseAuthClient(o.auth??{},this.headers,o.global.fetch),this.fetch=Pn(t,e,this._getSessionToken.bind(this),o.global.fetch,o.tracePropagation),this.functionsFetch=Pn(t,e,this._getSessionToken.bind(this),o.global.fetch,o.tracePropagation,{omitApiKeyAsBearer:!0}),this.realtime=this._initRealtimeClient({headers:this.headers,accessToken:this._getAccessToken.bind(this),fetch:this.fetch,...o.realtime}),this.accessToken&&Promise.resolve(this.accessToken()).then(e=>this.realtime.setAuth(e)).catch(e=>console.warn(`Failed to set initial Realtime auth token:`,e)),this.rest=new fe(new URL(`rest/v1`,r).href,{headers:this.headers,schema:o.db.schema,fetch:this.fetch,timeout:o.db.timeout,urlLengthLimit:o.db.urlLengthLimit,retry:o.db.retry}),this.storage=new mn(this.storageUrl.href,this.headers,this.fetch,n?.storage),o.accessToken||this._listenForAuthEvents()}get functions(){return new l(this.functionsUrl.href,{headers:this.headers,customFetch:this.functionsFetch})}from(e){return this.rest.from(e)}schema(e){return this.rest.schema(e)}getOpenApiSpec(){return this.rest.getOpenApiSpec()}rpc(e,t={},n={head:!1,get:!1,count:void 0}){return this.rest.rpc(e,t,n)}channel(e,t={config:{}}){return this.realtime.channel(e,t)}getChannels(){return this.realtime.getChannels()}removeChannel(e){return this.realtime.removeChannel(e)}removeAllChannels(){return this.realtime.removeAllChannels()}async _getSessionToken(){if(this.accessToken)return await this.accessToken();let{data:e}=await this.auth.getSession();return e.session?.access_token??null}async _getAccessToken(){return await this._getSessionToken()??this.supabaseKey}_initSupabaseAuthClient({autoRefreshToken:e,persistSession:t,detectSessionInUrl:n,storage:r,userStorage:i,storageKey:a,flowType:o,lock:s,debug:c,throwOnError:l,experimental:u,lockAcquireTimeout:d,skipAutoInitialize:f},p,m){let h={Authorization:`Bearer ${this.supabaseKey}`,apikey:`${this.supabaseKey}`};return new Zi({url:this.authUrl.href,headers:{...h,...p},storageKey:a,autoRefreshToken:e,persistSession:t,detectSessionInUrl:n,storage:r,userStorage:i,flowType:o,lock:s,debug:c,throwOnError:l,experimental:u,fetch:m,lockAcquireTimeout:d,skipAutoInitialize:f,hasCustomAuthorizationHeader:Object.keys(this.headers).some(e=>e.toLowerCase()===`authorization`)})}_initRealtimeClient(e){return new _t(this.realtimeUrl.href,{...e,params:{apikey:this.supabaseKey,...e?.params}})}_listenForAuthEvents(){return this.auth.onAuthStateChange((e,t)=>{this._handleTokenChanged(e,`CLIENT`,t?.access_token)})}_handleTokenChanged(e,t,n){(e===`TOKEN_REFRESHED`||e===`SIGNED_IN`||e===`INITIAL_SESSION`)&&this.changedAccessToken!==n?(this.changedAccessToken=n,this.realtime.setAuth(n)):e===`SIGNED_OUT`&&(this.realtime.setAuth(),t==`STORAGE`&&this.auth.signOut(),this.changedAccessToken=void 0)}};let $i=(e,t,n)=>new Qi(e,t,n);function ea(){if(typeof window<`u`||globalThis.Deno!==void 0)return!1;let e=globalThis.process;if(!e)return!1;let t=e.version;if(t==null)return!1;let n=t.match(/^v(\d+)\./);return n?parseInt(n[1],10)<=20:!1}return ea()&&console.warn(`⚠️  Node.js 20 and below are deprecated and will no longer be supported in future versions of @supabase/supabase-js. Please upgrade to Node.js 22 or later. For more information, visit: https://github.com/orgs/supabase/discussions/45715`),e.AuthAdminApi=Yi,e.AuthApiError=Zn,e.AuthClient=Xi,e.AuthError=Xn,e.AuthImplicitGrantRedirectError=tr,e.AuthInvalidCredentialsError=er,e.AuthInvalidJwtError=fr,e.AuthInvalidTokenResponseError=R,e.AuthPKCECodeVerifierMissingError=ir,e.AuthPKCEGrantCodeExchangeError=rr,e.AuthRefreshDiscardedError=cr,e.AuthRetryableFetchError=or,e.AuthSessionMissingError=L,e.AuthUnknownError=F,e.AuthWeakPasswordError=ur,e.CustomAuthError=I,Object.defineProperty(e,`FunctionRegion`,{enumerable:!0,get:function(){return c}}),e.FunctionsError=i,e.FunctionsFetchError=a,e.FunctionsHttpError=s,e.FunctionsRelayError=o,e.GoTrueAdminApi=mi,e.GoTrueClient=Ji,e.NavigatorLockAcquireTimeoutError=_i,e.PostgrestError=u,e.REALTIME_CHANNEL_STATES=ut,Object.defineProperty(e,`REALTIME_LISTEN_TYPES`,{enumerable:!0,get:function(){return T}}),Object.defineProperty(e,`REALTIME_POSTGRES_CHANGES_LISTEN_EVENT`,{enumerable:!0,get:function(){return lt}}),Object.defineProperty(e,`REALTIME_PRESENCE_LISTEN_EVENTS`,{enumerable:!0,get:function(){return Xe}}),Object.defineProperty(e,`REALTIME_SUBSCRIBE_STATES`,{enumerable:!0,get:function(){return E}}),e.RealtimeChannel=dt,e.RealtimeClient=_t,e.RealtimePostgresFilterBuilder=st,e.RealtimePresence=Ze,e.SIGN_OUT_SCOPES=pi,e.StorageApiError=Pt,e.SupabaseClient=Qi,e.WebSocketFactory=pe,e.createClient=$i,e.isAuthApiError=Qn,e.isAuthError=P,e.isAuthImplicitGrantRedirectError=nr,e.isAuthPKCECodeVerifierMissingError=ar,e.isAuthRefreshDiscardedError=lr,e.isAuthRetryableFetchError=sr,e.isAuthSessionMissingError=$n,e.isAuthWeakPasswordError=dr,e.lockInternals=Z,e.navigatorLock=yi,e.postgresChangesFilter=ct,e.processLock=xi,e})({});
;


/* =========================================================
   CONFIG
========================================================= */
const SUPABASE_URL='https://urlkkwxmalhyvycowwxz.supabase.co';
const DELIVERY_REVERSE_GEOCODING_READY=false; // Enable only after GEOAPIFY_API_KEY is set as a Supabase secret.
const SUPABASE_KEY='sb_publishable_VT8O9ta4dafI1nCsQaCcGQ_3qdu8RAP'; // publishable key: safe in the browser; protection comes from RLS
const sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
const AI_FUNCTION_NAME='ai-chat';
// Supabase Edge Function name (see /supabase/functions/ai-chat)

/* =========================================================
   GLOBAL STATE
========================================================= */
const S={
  page:'home',data:null,history:[],
  dark: localStorage.getItem('dl_dark')!==null ? localStorage.getItem('dl_dark')==='1' : true,
  settings:null,categories:[],products:[],
  session:null,profile:null,isAdmin:false,
  deliveryLocation:null,
  cart:JSON.parse(localStorage.getItem('dl_cart')||'[]'),
  wishlist:[],           // product ids
  cat:'all',search:'',offersOnly:false,sort:'def',forceGrid:false,
  dqty:1,buyMode:'normal',selectedColor:'',
  currentOrder:null,
  adminSection:'overview',
  aiPublic:null,          // {enabled, assistant_name, welcome_message}
};

/* =========================================================
   ROUTING TABLE — maps internal page names <-> real URLs
   and sets the browser tab title per page.
========================================================= */
const ROUTES=[
  {page:'home',        pattern:/^\/$/,                         toPath:()=>'/'},
  {page:'home',        pattern:/^\/category\/([^/]+)$/,         toPath:d=>`/category/${d}`, dataFrom:m=>({offers:false,catSlug:m[1]})},
  {page:'cart',        pattern:/^\/cart$/,                      toPath:()=>'/cart'},
  {page:'checkout',    pattern:/^\/checkout$/,                  toPath:()=>'/checkout'},
  {page:'success',     pattern:/^\/order-success$/,             toPath:()=>'/order-success'},
  {page:'wishlist',    pattern:/^\/favorites$/,                 toPath:()=>'/favorites'},
  {page:'orders',      pattern:/^\/orders$/,                    toPath:()=>'/orders'},
  {page:'order-detail',pattern:/^\/order\/([^/]+)$/,            toPath:d=>`/order/${d}`, dataFrom:m=>m[1]},
  {page:'points',      pattern:/^\/points$/,                    toPath:()=>'/points'},
  {page:'account',     pattern:/^\/account$/,                   toPath:()=>'/account'},
  {page:'account',     pattern:/^\/login$/,                     toPath:()=>'/login'},
  {page:'contact',     pattern:/^\/contact$/,                   toPath:()=>'/contact'},
  {page:'product',     pattern:/^\/product\/([^/]+)$/,          toPath:d=>`/product/${d}`, dataFrom:m=>m[1]},
  {page:'admin-login', pattern:/^\/admin\/login\/?$/,              toPath:()=>'/admin/login'},
  {page:'admin',       pattern:/^\/admin\/?([a-z-]*)$/,         toPath:d=>'/admin'+(d&&d!=='overview'?'/'+d:''), dataFrom:m=>m[1]||'overview'},
  {page:'home',        pattern:/^\/products$/,                  toPath:()=>'/products', dataFrom:()=>({forceGrid:true})},
];
function pageTitle(){
  const st=S.settings||{};const brand=st.store_name||'Dash Lebanon';
  switch(S.page){
    case'home':return S.forceGrid||S.cat!=='all'||S.offersOnly?`${catLabel(S.cat)} | ${brand}`:`${brand} | ${st.hero_title||'Home'}`;
    case'product':{const p=S.products.find(x=>x.id===S.data);return p?`${p.name} | ${brand}`:brand;}
    case'cart':return`Shopping Cart | ${brand}`;
    case'checkout':return`Checkout | ${brand}`;
    case'success':return`Order Confirmed | ${brand}`;
    case'wishlist':return`Favorites | ${brand}`;
    case'orders':return`My Orders | ${brand}`;
    case'order-detail':return`Order Details | ${brand}`;
    case'points':return`My Points | ${brand}`;
    case'account':return`${S.session?'My Account':'Sign In'} | ${brand}`;
    case'contact':return`Contact Us | ${brand}`;
    case'admin-login':return`Admin Login | ${brand}`;
    case'admin':return`Admin · ${adminSectionLabel(S.adminSection)} | ${brand}`;
    default:return brand;
  }
}
function adminSectionLabel(s){return({overview:'Overview',orders:'Orders',products:'Products',categories:'Categories',ai:'إعدادات الذكاء الاصطناعي',settings:'Store Settings',messages:'Messages',reviews:'Reviews',coupons:'Coupons & Offers',users:'Customers'})[s]||'Admin'}
function pathForRoute(page,data){
  if(page==='home'){
    if(S.offersOnly||S.forceGrid||S.cat!=='all'||S.search)return S.cat&&S.cat!=='all'?`/category/${S.cat}`:'/products';
    return'/';
  }
  if(page==='product')return`/product/${data}`;
  if(page==='order-detail')return`/order/${data}`;
  if(page==='wishlist')return'/favorites';
  if(page==='admin-login')return'/admin/login';
  if(page==='admin')return'/admin'+(data&&data!=='overview'?'/'+data:'');
  const known=['cart','checkout','success','orders','points','account','contact'];
  if(known.includes(page))return page==='success'?'/order-success':'/'+page;
  return'/';
}

function esc(s){if(s==null)return'';return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}
function fmt(n){const x=parseFloat(n);return isNaN(x)?'$0.00':'$'+x.toFixed(2)}
function fmtLBP(n){if(!S.settings)return'';return Math.round(parseFloat(n)*S.settings.currency_rate).toLocaleString('en')+' LBP'}
let toastTimer;
function toast(msg){const el=document.getElementById('toast');clearTimeout(toastTimer);el.textContent=msg;el.classList.add('show');toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function saveCart(){localStorage.setItem('dl_cart',JSON.stringify(S.cart))}
function cartCount(){return S.cart.reduce((s,i)=>s+i.qty,0)}
function cartSub(){return parseFloat(S.cart.reduce((s,i)=>s+i.price*i.qty,0).toFixed(2))}
function cartDelivery(){return S.cart.length?4:0}
function cartTotal(){return parseFloat((cartSub()+cartDelivery()-(S.appliedDiscount||0)).toFixed(2))}
function updateCartBadge(){const c=cartCount();const b=document.getElementById('cart-badge');b.textContent=c;b.classList.toggle('hide',!c)}

/* =========================================================
   BOOT
========================================================= */
async function boot(){
  // Safety: never leave the visitor stuck forever on the loading screen.
  const loadingSafetyTimer=setTimeout(()=>{
    const loader=document.getElementById('loading-screen');
    if(loader)loader.style.display='none';
  },8000);

  applyDark();
  try{
  const bootRequests=Promise.all([
    sb.auth.getSession(),
    sb.from('settings').select('*').eq('id',1).maybeSingle(),
    sb.from('categories').select('*').eq('is_active',true).order('sort_order'),
    sb.from('products').select('*, product_images(id,url,sort_order)').eq('is_active',true).order('created_at',{ascending:false}),
    sb.from('ai_public_settings').select('*').maybeSingle()
  ]);

  const bootTimeout=new Promise((_,reject)=>setTimeout(
    ()=>reject(new Error('Website loading timed out. Check Supabase connection and browser Console.')),
    7000
  ));

  const [{data:{session}},settingsRes,catRes,prodRes,aiPubRes]=await Promise.race([
    bootRequests,
    bootTimeout
  ]);
  S.session=session;
  S.settings=settingsRes.data||{store_name:'Dash Lebanon',currency_rate:90000,points_per_dollar:7,cancel_fee:4,free_cancel_hours:24,whatsapp_number:'96181877323',contact_email:'',instagram_url:'',facebook_url:'',tiktok_url:'',instagram_handle:'',facebook_handle:'',tiktok_handle:'',whatsapp_handle:'',logo_url:'',favicon_url:'',page_visibility:{home:true,offers:true,wishlist:true,orders:true,points:true,account:true,contact:true},hero_title:'Everyday products, delivered fast.',hero_subtitle:'Quality home, kitchen & beauty finds — cash on delivery, anywhere in Lebanon.',announcement:''};
  S.categories=catRes.data||[];
  S.products=prodRes.data||[];
  S.aiPublic=aiPubRes.data||{enabled:false,assistant_name:'المساعد الذكي',welcome_message:''};
  applySettingsToChrome();
  if(session)await loadProfileAndWishlist();
  sb.auth.onAuthStateChange(async(event,sess)=>{
    S.session=sess;
    if(sess)await loadProfileAndWishlist(); else {S.profile=null;S.wishlist=[];S.isAdmin=false;S.deliveryLocation=null}
    updateChromeAuth();renderAdminNavVisibility();
  });
  // Resolve whatever URL the user actually landed on (deep link / refresh / shared link)
  const r=routeFromLocation();
  S.page=r.page;S.data=r.data;
  if(S.page==='admin')S.adminSection=r.data||'overview';
  if(S.page==='admin'&&!guardAdmin(true)){S.page='admin-login';S.data=null}
  document.getElementById('loading-screen').style.display='none';
  render();updateCartBadge();updateChromeAuth();renderAdminNavVisibility();
  syncUrl(false);
  initAiWidget();
  if(typeof maybePromptLocation==='function')maybePromptLocation();
  clearTimeout(loadingSafetyTimer);
  }catch(err){
    console.error('Boot error:',err);
    const loader=document.getElementById('loading-screen');
    if(loader)loader.style.display='none';
    clearTimeout(loadingSafetyTimer);
    const main=document.getElementById('main');
    if(main)main.innerHTML='<div style="padding:40px;text-align:center"><h2>Something went wrong loading the website.</h2><p>Please check the browser console for details.</p></div>';
  }
}
async function loadProfileAndWishlist(){
  const uid=S.session.user.id;
  const[{data:profile},{data:wl},{data:deliveryLocation}]=await Promise.all([
    sb.from('profiles').select('*').eq('id',uid).maybeSingle(),
    sb.from('wishlists').select('product_id').eq('user_id',uid),
    sb.from('delivery_locations').select('user_id,city,district,full_address,latitude,longitude,source,confirmed_at,updated_at').eq('user_id',uid).maybeSingle()
  ]);
  S.profile=profile;S.wishlist=(wl||[]).map(w=>w.product_id);
  S.deliveryLocation=deliveryLocation||null;
  S.isAdmin=!!(profile&&profile.role==='admin');
}
function renderAdminNavVisibility(){
  document.querySelectorAll('.admin-only-link').forEach(el=>el.classList.toggle('hide',!S.isAdmin));
}
function applySettingsToChrome(){
  const st=S.settings;
  document.title=st.store_name+' — '+(st.hero_title||'Shop');
  const ann=document.getElementById('announce');
  if(st.announcement){ann.textContent=st.announcement;ann.classList.remove('hide')}else ann.classList.add('hide');
  document.getElementById('footer-tag').textContent=st.hero_subtitle||'';
  document.getElementById('footer-year').textContent=new Date().getFullYear();
  const wa='https://wa.me/'+(st.whatsapp_number||'').replace(/\D/g,'');
  document.getElementById('wa-fab').href=wa;document.getElementById('drawer-wa').href=wa;document.getElementById('footer-wa').href=wa;
  document.getElementById('footer-email').href='mailto:'+(st.contact_email||'');
  document.getElementById('footer-email').textContent=st.contact_email||'';
  let soc='';
  if(st.instagram_url)soc+=`<a href="${esc(st.instagram_url)}" target="_blank">IG</a>`;
  if(st.facebook_url)soc+=`<a href="${esc(st.facebook_url)}" target="_blank">FB</a>`;
  if(st.tiktok_url)soc+=`<a href="${esc(st.tiktok_url)}" target="_blank">TT</a>`;
  document.getElementById('footer-soc').innerHTML=soc;
  document.getElementById('drawer-soc').innerHTML=soc;
}
function updateChromeAuth(){
  document.querySelectorAll('.nav-links button').forEach(b=>b.classList.toggle('on',b.dataset.nav===S.page));
  const dm=document.getElementById('drawer-dm-btn');if(dm)dm.textContent=(S.dark?'☀️ Light mode':'🌙 Dark mode');
  document.querySelectorAll('.admin-only-link').forEach(el=>el.classList.toggle('hide',!S.isAdmin));
}

/* =========================================================
   DARK MODE
========================================================= */
function applyDark(){document.documentElement.setAttribute('data-dark',S.dark?'1':'0');const dm=document.getElementById('drawer-dm-btn');if(dm)dm.textContent=(S.dark?'☀️ Light mode':'🌙 Dark mode')}
function toggleDark(){S.dark=!S.dark;localStorage.setItem('dl_dark',S.dark?'1':'0');applyDark()}

/* =========================================================
   ROUTER
========================================================= */
function nav(page,data=null,push=true){
  S.page=page;S.data=data;
  if(page==='admin')S.adminSection=data||'overview';
  if(page==='home'&&data&&data.offers){S.offersOnly=true;S.cat='offers';S.forceGrid=true}
  if(page!=='product'){S.dqty=1;S.buyMode='normal'}
  if(page==='admin'&&!guardAdmin())return;
  render();
  window.scrollTo(0,0);updateChromeAuth();closeDrawer();
  syncUrl(push);
}
let inAppNavDepth=0;
function syncUrl(push){
  const path=pathForRoute(S.page,S.page==='admin'?S.adminSection:S.data);
  const state={page:S.page,data:S.data,adminSection:S.adminSection,cat:S.cat,offersOnly:S.offersOnly,forceGrid:S.forceGrid,search:S.search};
  if(push&&location.pathname!==path){history.pushState(state,'',path);inAppNavDepth++}
  else history.replaceState(state,'',path);
  document.title=pageTitle();
}
let hiddenAdminClicks=0,hiddenAdminTimer=null;
function handleHiddenAdminClick(){
  hiddenAdminClicks++;
  clearTimeout(hiddenAdminTimer);
  hiddenAdminTimer=setTimeout(()=>{hiddenAdminClicks=0},3000);
  if(hiddenAdminClicks>=5){
    hiddenAdminClicks=0;
    clearTimeout(hiddenAdminTimer);
    nav('admin-login');
  }else{
    resetHome();
  }
}
function guardAdmin(silent=false){
  if(!S.session){if(!silent){toast('Please sign in to access the Admin Dashboard');nav('admin-login')}return false}
  if(!S.isAdmin){if(!silent){toast('This account does not have admin access');nav('admin-login')}return false}
  return true;
}
function resetHome(){S.forceGrid=false;S.cat='all';S.search='';S.offersOnly=false;nav('home');closeDrawer()}
function viewAllCategory(slug){S.cat=slug;S.offersOnly=(slug==='offers');S.forceGrid=true;S.search='';nav('home');}
function openSearch(){viewAllCategory('all');setTimeout(()=>{const f=document.getElementById('search-field');if(f)f.focus()},60)}
function goBack(){if(inAppNavDepth>0){history.back()}else{nav('home',null,false)}}
function routeFromLocation(){
  const path=location.pathname;
  for(const r of ROUTES){
    const m=path.match(r.pattern);
    if(m){
      let data=r.dataFrom?r.dataFrom(m):null;
      if(r.page==='home'&&data&&data.catSlug){S.cat=data.catSlug;S.offersOnly=(data.catSlug==='offers');S.forceGrid=true;data=null}
      if(r.page==='home'&&data&&data.forceGrid){S.forceGrid=true;data=null}
      return{page:r.page,data};
    }
  }
  return{page:'home',data:null};
}
window.addEventListener('popstate',(e)=>{
  if(inAppNavDepth>0)inAppNavDepth--;
  const st=e.state;
  if(st){S.page=st.page;S.data=st.data;S.adminSection=st.adminSection||'overview';S.cat=st.cat||'all';S.offersOnly=!!st.offersOnly;S.forceGrid=!!st.forceGrid;S.search=st.search||'';}
  else{const r=routeFromLocation();S.page=r.page;S.data=r.data;if(r.page==='admin')S.adminSection=r.data||'overview';}
  if(S.page==='admin'&&!guardAdmin())return;
  render();updateChromeAuth();document.title=pageTitle();
});
function openDrawer(){document.getElementById('drawer').classList.add('open');document.getElementById('drawer-ov').classList.add('open')}
function closeDrawer(){document.getElementById('drawer').classList.remove('open');document.getElementById('drawer-ov').classList.remove('open')}

const app=()=>document.getElementById('app');
function showFooterCart(hide){document.getElementById('site-footer').classList.toggle('hide',hide)}

function render(){
  const noFooter=['cart','checkout'];
  showFooterCart(noFooter.includes(S.page));
  document.body.classList.toggle('has-sticky-bar',noFooter.includes(S.page));
  switch(S.page){
    case'home':app().innerHTML=pHome();bindHome();break;
    case'product':pProduct();break;
    case'cart':app().innerHTML=pCart();break;
    case'checkout':app().innerHTML=pCheckout();break;
    case'success':app().innerHTML=pSuccess();break;
    case'orders':window.pOrders();break;
    case'order-detail':window.pOrderDetail();break;
    case'wishlist':pWishlist();break;
    case'points':pPoints();break;
    case'account':pAccount();break;
    case'contact':app().innerHTML=window.pContact();break;
    case'admin-login':pAdminLogin();break;
    case'admin':window.pAdmin();break;
    default:app().innerHTML=pHome();bindHome();
  }
  document.title=pageTitle();
}

/* =========================================================
   PRODUCT HELPERS
========================================================= */
function discPct(oldP,p){if(!oldP||oldP<=p)return 0;return Math.round((1-p/oldP)*100)}
function coverImg(p){return p.cover_image||(p.product_images&&p.product_images[0]&&p.product_images[0].url)||'https://placehold.co/400x400/e7ebf3/98a2b8?text=No+Image'}
function isWished(id){return S.wishlist.includes(id)}
function calcEarnPts(total){return Math.round(total*(S.settings.points_per_dollar||7))}

async function toggleWish(id,ev){
  if(ev)ev.stopPropagation();
  if(!S.session){toast('Log in to save favorites');nav('account');return}
  const uid=S.session.user.id;
  if(isWished(id)){
    await sb.from('wishlists').delete().eq('user_id',uid).eq('product_id',id);
    S.wishlist=S.wishlist.filter(x=>x!==id);
  }else{
    await sb.from('wishlists').insert({user_id:uid,product_id:id});
    S.wishlist.push(id);
  }
  document.querySelectorAll(`.wish-btn[data-pid="${id}"]`).forEach(b=>b.classList.toggle('active',isWished(id)));
}
function quickAdd(pid,ev){
  if(ev)ev.stopPropagation();
  const p=S.products.find(x=>x.id===pid);if(!p||p.is_active!==true)return;
  if((p.color_options||[]).length){nav('product',pid);return}
  const uid=p.id+'_single';
  const ex=S.cart.find(i=>i._uid===uid);
  if(ex)ex.qty+=1;else S.cart.push({_uid:uid,product_id:p.id,name:p.name,image:coverImg(p),price:p.price,qty:1,delivery_price:p.delivery_price,is_bundle:false,bundle_label:''});
  saveCart();updateCartBadge();toast('Added to cart');
}

/* =========================================================
   HOME PAGE — discover (hero + carousels) vs browse (grid)
========================================================= */
function pHome(){
  const discover=!S.forceGrid&&S.cat==='all'&&!S.search&&!S.offersOnly;
  return discover?pHomeDiscover():pHomeBrowse();
}
function pHomeDiscover(){
  const st=S.settings;
  const marqueeText=Array.from({length:8}).map(()=>'Shop now <b>↓</b>').join('');
  const cats=S.categories.filter(c=>S.products.some(p=>p.category_id===c.id));
  return `<div class="page">
    <div class="hero"><div class="hero-in">
      <div class="hero-eyebrow">Cash on delivery · anywhere in Lebanon</div>
      <h1>${heroHighlight(st.hero_title||'Shop smarter, live better.')}</h1>
      <p>${esc(st.hero_subtitle||'')}</p>
      <div class="hero-cta"><button class="btn btn-accent" onclick="viewAllCategory('offers')">See offers</button><button class="btn btn-ghost" style="background:rgba(255,255,255,.1);color:#fff;border-color:rgba(255,255,255,.35)" onclick="viewAllCategory('all')">Shop all</button></div>
    </div></div>
    <div class="marquee"><div class="marquee-track">${marqueeText}${marqueeText}</div></div>
    ${cats.map(c=>catCarouselHTML(c)).join('')}
    ${compareTableHTML()}
  </div>`;
}
function heroHighlight(title){
  const words=esc(title).split(' ');
  if(words.length<2)return esc(title);
  const mid=Math.min(2,words.length-1);
  return words.map((w,i)=>i===mid?`<span class="hl">${w}</span>`:w).join(' ');
}
function catCarouselHTML(c){
  const items=S.products.filter(p=>p.category_id===c.id).slice(0,10);
  if(!items.length)return'';
  const rowId='car-'+c.id;
  return `<div class="cat-section">
    <div class="cat-section-title">${esc(c.name)}</div>
    <div class="carousel-wrap">
      <div class="carousel-track" id="${rowId}">${items.map(p=>productCardHTML(p)).join('')}</div>
    </div>
    <div class="carousel-nav">
      <button class="car-arrow" onclick="scrollRow('${rowId}',-1)" aria-label="Previous">‹</button>
      <button class="car-arrow" onclick="scrollRow('${rowId}',1)" aria-label="Next">›</button>
    </div>
    <div class="view-all-row"><button class="btn btn-ghost btn-pill btn-sm" onclick="viewAllCategory('${c.slug}')">View all</button></div>
  </div>`;
}
function scrollRow(id,dir){const el=document.getElementById(id);if(!el)return;el.scrollBy({left:dir*260,behavior:'smooth'})}
function compareTableHTML(){
  const rows=[
    ['Fast delivery, all over Lebanon','yes','yes','no'],
    ['Cash on delivery','yes','yes','no'],
    ['WhatsApp support','yes','no','no'],
    ['Loyalty points on every order','yes','no','no'],
    ['Easy order cancellation','yes','no','no'],
  ];
  return `<div class="card compare-wrap">
    <div class="compare-title">Why Dash Lebanon?</div>
    <table class="compare-table">
      <tr><th></th><th>Dash Lebanon</th><th>Some Stores</th><th>Others</th></tr>
      ${rows.map(r=>`<tr><td>${esc(r[0])}</td><td class="${r[1]==='yes'?'yes':'no'}">${r[1]==='yes'?'✓':'✕'}</td><td class="${r[2]==='yes'?'yes':'no'}">${r[2]==='yes'?'✓':'✕'}</td><td class="${r[3]==='yes'?'yes':'no'}">${r[3]==='yes'?'✓':'✕'}</td></tr>`).join('')}
    </table>
  </div>`;
}

/* ---- browse mode : search / tabs / sort / grid (unchanged mechanics) ---- */
function catLabel(cat){if(cat==='all')return'All';if(cat==='offers')return'Offers';const c=S.categories.find(x=>x.slug===cat);return c?c.name:cat}
function buildCatPills(){
  const items=[{slug:'all',name:'All'},...S.categories,{slug:'offers',name:'Offers'}];
  return items.map(c=>{
    const count=c.slug==='all'?S.products.length:c.slug==='offers'?S.products.filter(p=>p.compare_at_price>p.price||p.bundle_qty).length:S.products.filter(p=>p.category_id===c.id).length;
    return `<button class="pill ${S.cat===c.slug?'on':''}" onclick="setCat('${c.slug}')">${esc(c.name)} <span style="opacity:.6">${count}</span></button>`;
  }).join('');
}
function setCat(slug){S.cat=slug;S.offersOnly=(slug==='offers');document.getElementById('pgrid').innerHTML=buildGrid();document.getElementById('cats-row').innerHTML=buildCatPills()}
function setSort(s){S.sort=s;document.getElementById('pgrid').innerHTML=buildGrid();document.querySelectorAll('.sort-btn').forEach(b=>b.classList.toggle('on',b.dataset.sort===s))}
let searchDebounce;
function doSearch(v){
  S.search=v;
  document.getElementById('search-clr').classList.toggle('show',v.length>0);
  clearTimeout(searchDebounce);
  searchDebounce=setTimeout(()=>{document.getElementById('pgrid').innerHTML=buildGrid()},150);
}
function clearSearchInp(){S.search='';document.getElementById('search-field').value='';document.getElementById('search-clr').classList.remove('show');document.getElementById('pgrid').innerHTML=buildGrid()}

function filteredProducts(){
  let list=S.products;
  if(S.cat==='offers')list=list.filter(p=>p.compare_at_price>p.price||p.bundle_qty);
  else if(S.cat!=='all')list=list.filter(p=>{const c=S.categories.find(x=>x.slug===S.cat);return c&&p.category_id===c.id});
  const q=S.search.trim().toLowerCase();
  if(q)list=list.filter(p=>p.name.toLowerCase().includes(q)||(p.description||'').toLowerCase().includes(q));
  if(S.sort==='price_asc')list=[...list].sort((a,b)=>a.price-b.price);
  else if(S.sort==='price_desc')list=[...list].sort((a,b)=>b.price-a.price);
  else if(S.sort==='rating')list=[...list].sort((a,b)=>b.rating_avg-a.rating_avg);
  return list;
}
function buildGrid(){
  const list=filteredProducts();
  if(!S.products.length)return skeletonCards(8);
  if(!list.length)return `<div class="empty-box"><div class="empty-ico">🔍</div><div class="empty-ttl">No results${S.search?' for "'+esc(S.search)+'"':''}</div><div class="empty-sub">Try a different search or category.</div></div>`;
  return list.map(p=>productCardHTML(p)).join('');
}
function skeletonCards(n){return Array.from({length:n}).map(()=>`<div class="pcard"><div class="pcard-img skel"></div><div class="pcard-body"><div class="skel" style="height:12px;width:80%;border-radius:4px;margin-bottom:8px"></div><div class="skel" style="height:12px;width:50%;border-radius:4px"></div></div></div>`).join('')}
function productCardHTML(p){
  const disc=discPct(p.compare_at_price,p.price);
  const wished=isWished(p.id);
  const isBundle=!!p.bundle_qty;
  return `<div class="pcard" onclick="nav('product','${p.id}')">
    <div class="pcard-img">
      ${disc>0?`<div class="chip-corner">SAVE ${disc}%</div>`:''}
      ${isBundle?`<div class="chip-corner bundle">Bundle</div>`:''}
      <img src="${esc(coverImg(p))}" loading="lazy" alt="${esc(p.name)}" onerror="this.src='https://placehold.co/400x400/e7ebf3/98a2b8?text=No+Image'">
      <button class="wish-btn ${wished?'active':''}" data-pid="${p.id}" onclick="toggleWish('${p.id}',event)">${wished?'♥':'♡'}</button>
    </div>
    <div class="pcard-body">
      <div class="pcard-name">${esc(p.name)}</div>
      <div class="pcard-price-row">
        <div class="pcard-price">${isBundle?'From ':''}${fmt(p.price)}</div>
        ${p.compare_at_price?`<div class="pcard-old">${fmt(p.compare_at_price)}</div>`:''}
      </div>
      ${isBundle?`<button class="pcard-cta" onclick="event.stopPropagation();nav('product','${p.id}')">Choose options</button>`:`<button class="pcard-cta" onclick="quickAdd('${p.id}',event)">Add to cart</button>`}
      <div class="pcard-foot"><span>${p.rating_count?`<span class="stars">★</span> ${p.rating_avg}`:'New'}</span><span>+${calcEarnPts(p.price)}pts</span></div>
    </div>
  </div>`;
}
function pHomeBrowse(){
  const title=S.offersOnly?'Offers':(S.cat!=='all'?catLabel(S.cat):'All products');
  return `<div class="page">
    <button class="back-link" onclick="resetHome()">← Back to shopping</button>
    <div class="section-head"><div class="section-title">${esc(title)}</div></div>
    <div class="search-wrap">
      <span class="search-ico">🔍</span>
      <input class="search-inp" id="search-field" placeholder="Search products…" value="${esc(S.search)}" oninput="doSearch(this.value)">
      <button class="search-clr ${S.search?'show':''}" id="search-clr" onclick="clearSearchInp()">✕</button>
    </div>
    <div class="cats-row" id="cats-row">${buildCatPills()}</div>
    <div class="sort-row">
      <span style="font-size:.76rem;color:var(--muted);font-weight:600;font-family:var(--font-m)">Sort:</span>
      <button class="sort-btn on" data-sort="def" onclick="setSort('def')">Default</button>
      <button class="sort-btn" data-sort="price_asc" onclick="setSort('price_asc')">Price ↑</button>
      <button class="sort-btn" data-sort="price_desc" onclick="setSort('price_desc')">Price ↓</button>
      <button class="sort-btn" data-sort="rating" onclick="setSort('rating')">Top rated</button>
      <span class="result-count" id="result-count">${filteredProducts().length} items</span>
    </div>
    <div class="grid" id="pgrid">${buildGrid()}</div>
  </div>`;
}
function bindHome(){}

/* =========================================================
   PRODUCT DETAIL
========================================================= */
let pdImages=[];let pdIdx=0;let pdReviews=[];
async function pProduct(){
  const p=S.products.find(x=>x.id===S.data);
  if(!p){nav('home');return}
  S.selectedColor=(p.color_options||[])[0]||'';
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const[{data:imgs},{data:reviews}]=await Promise.all([
    sb.from('product_images').select('*').eq('product_id',p.id).order('sort_order'),
    sb.from('reviews').select('*, profiles(first_name,last_name)').eq('product_id',p.id).eq('status','approved').order('created_at',{ascending:false})
  ]);
  pdImages=(imgs&&imgs.length)?imgs.map(i=>i.url):[coverImg(p)];
  // make sure the designated cover image (if set) appears first in the gallery
  if(p.cover_image){
    const ci=pdImages.indexOf(p.cover_image);
    if(ci>0){pdImages.splice(ci,1);pdImages.unshift(p.cover_image)}
    else if(ci===-1){pdImages.unshift(p.cover_image)}
  }
  pdIdx=0;pdReviews=reviews||[];
  renderProductPage(p);
}
function renderProductPage(p){
  const disc=discPct(p.compare_at_price,p.price);
  const wished=isWished(p.id);
  const earn=calcEarnPts(S.buyMode==='bundle'&&p.bundle_qty?p.bundle_price:p.price*S.dqty);
  let bundleSec='';
  if(p.bundle_qty){
    const savings=fmt(p.price*p.bundle_qty-p.bundle_price);
    bundleSec=`<div class="bundle-opts">
      <div class="bopt ${S.buyMode==='normal'?'on':''}" onclick="selMode('normal')"><div style="font-weight:700;font-size:.85rem">Single item</div><div style="color:var(--primary);font-weight:800;margin-top:4px;font-family:var(--font-m)">${fmt(p.price)}</div></div>
      <div class="bopt ${S.buyMode==='bundle'?'on':''}" onclick="selMode('bundle')"><div class="bopt-badge">Best value</div><div style="font-weight:700;font-size:.85rem">${p.bundle_qty} pack</div><div style="color:var(--primary);font-weight:800;margin-top:4px;font-family:var(--font-m)">${fmt(p.bundle_price)}</div><div style="color:var(--success);font-size:.72rem;font-weight:700;font-family:var(--font-m)">Save ${savings}</div></div>
    </div>`;
  }
  const specs=(p.specifications||[]).length?`<table class="spec-table">${p.specifications.map(s=>`<tr><td>${esc(s.label)}</td><td>${esc(s.value)}</td></tr>`).join('')}</table>`:'';
  const showQty=!p.bundle_qty||S.buyMode==='normal';
  const colorOptions=(p.color_options||[]).filter(Boolean);
  const colorSec=colorOptions.length?`<div class="fgroup" style="margin:14px 0"><label class="flabel" for="pd-color">Color</label><select class="fselect" id="pd-color" onchange="selColor(this.value)">${colorOptions.map(c=>`<option value="${esc(c)}" ${c===S.selectedColor?'selected':''}>${esc(c)}</option>`).join('')}</select></div>`:'';
  const others=S.products.filter(x=>x.id!==p.id).slice(0,4);
  const revAvg=p.rating_count?`<span class="stars">★★★★★</span> ${p.rating_avg} · ${p.rating_count} review${p.rating_count>1?'s':''}`:'No reviews yet';
  const revList=pdReviews.length?pdReviews.map(r=>`<div class="review-item"><div class="review-head"><div class="review-avatar">${esc((r.profiles?.first_name||'U')[0])}</div><div><div class="review-name">${esc(r.profiles?.first_name||'Customer')} ${esc(r.profiles?.last_name||'')}</div><div class="review-date">${new Date(r.created_at).toLocaleDateString()} · ${'★'.repeat(r.rating)}${'☆'.repeat(5-r.rating)}</div></div></div><div class="review-text">${esc(r.comment)}</div></div>`).join(''):`<div style="color:var(--muted);font-size:.88rem;padding:10px 0">No reviews yet — be the first to share your experience.</div>`;
  const hasMulti=pdImages.length>1;
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="pd-wrap">
      <div>
        <div class="pd-gallery-main" id="pd-gallery">
          ${hasMulti?`<button class="pd-arrow prev" onclick="pdPrev()" aria-label="Previous image">‹</button><button class="pd-arrow next" onclick="pdNext()" aria-label="Next image">›</button>`:''}
          <img id="pd-main-img" src="${esc(pdImages[0])}" onerror="this.src='https://placehold.co/500x500/e7ebf3/98a2b8?text=No+Image'">
          ${hasMulti?`<div class="pd-dots" id="pd-dots">${pdImages.map((_,i)=>`<span class="${i===0?'on':''}"></span>`).join('')}</div>`:''}
        </div>
        ${hasMulti?`<div class="pd-thumbs">${pdImages.map((im,i)=>`<div class="pd-thumb ${i===0?'on':''}" onclick="pdSwap(${i})"><img src="${esc(im)}"></div>`).join('')}</div>`:''}
      </div>
      <div>
        <div class="pd-name">${esc(p.name)}</div>
        <div class="pd-rating">${revAvg}</div>
        ${p.compare_at_price?`<div class="pd-price-row"><span class="pd-old">${fmt(p.compare_at_price)}</span>${disc>0?`<span class="status-badge st-cancelled">-${disc}%</span>`:''}</div>`:''}
        <div class="pd-price-row"><span class="pd-price" id="pd-price">${S.buyMode==='bundle'?fmt(p.bundle_price):fmt(p.price)}</span></div>
        <div class="pd-lbp" id="pd-lbp">${fmtLBP(S.buyMode==='bundle'?p.bundle_price:p.price)} · Delivery $4.00</div>
        <div class="pd-desc">${esc(p.description||'')}</div>
        ${specs}
        ${colorSec}
        ${bundleSec}
        <div class="pts-chip" id="pts-chip">★ Earn <strong>${earn}</strong> points with this order</div>
        <div class="qty-row" id="qty-row" style="${!showQty?'display:none':''}">
          <span style="font-weight:700;font-size:.88rem">Quantity</span>
          <div class="qty-ctrl"><button class="qbtn" onclick="pdQty(-1)">−</button><input class="qty-val" id="pd-qty" value="${S.dqty}" oninput="pdQtyManual(this.value)"><button class="qbtn" onclick="pdQty(1)">+</button></div>
        </div>
        <div class="pd-actions">
          <button class="btn btn-primary" onclick="addToCart('${p.id}')">Add to cart</button>
          <button class="icon-btn btn-icon-only wish-btn ${wished?'active':''}" data-pid="${p.id}" onclick="toggleWish('${p.id}',event);this.classList.toggle('active')" style="height:48px">${wished?'♥':'♡'}</button>
        </div>
      </div>
    </div>

    <div class="card" style="padding:20px;margin-top:26px">
      <div class="section-head"><div class="section-title" style="font-size:1.08rem">Customer reviews</div>${S.session?`<button class="btn btn-ghost btn-sm" onclick="openReviewModal('${p.id}')">Write a review</button>`:''}</div>
      ${revList}
    </div>

    ${others.length?`<div style="margin-top:26px"><div class="section-title" style="font-size:1.08rem;margin-bottom:12px">You might also like</div><div class="grid">${others.map(x=>productCardHTML(x)).join('')}</div></div>`:''}
  </div>`;
  if(hasMulti)bindGallerySwipe();
}
function pdSwap(i){
  pdIdx=i;
  const img=document.getElementById('pd-main-img');
  img.style.opacity='0';
  setTimeout(()=>{img.src=pdImages[i];img.style.opacity='1'},90);
  document.querySelectorAll('.pd-thumb').forEach((t,x)=>t.classList.toggle('on',x===i));
  const dots=document.getElementById('pd-dots');
  if(dots)dots.querySelectorAll('span').forEach((d,x)=>d.classList.toggle('on',x===i));
}
function pdNext(){pdSwap((pdIdx+1)%pdImages.length)}
function pdPrev(){pdSwap((pdIdx-1+pdImages.length)%pdImages.length)}
function bindGallerySwipe(){
  const el=document.getElementById('pd-gallery');
  if(!el)return;
  let startX=0,startY=0,dragging=false;
  el.addEventListener('touchstart',e=>{startX=e.touches[0].clientX;startY=e.touches[0].clientY;dragging=true},{passive:true});
  el.addEventListener('touchmove',e=>{ if(!dragging)return; },{passive:true});
  el.addEventListener('touchend',e=>{
    if(!dragging)return;dragging=false;
    const dx=e.changedTouches[0].clientX-startX;
    const dy=e.changedTouches[0].clientY-startY;
    if(Math.abs(dx)>40&&Math.abs(dx)>Math.abs(dy)){
      if(dx<0)pdNext();else pdPrev();
    }
  });
  const img=document.getElementById('pd-main-img');
  if(img)img.style.transition='opacity .15s';
}
function selMode(mode){
  S.buyMode=mode;const p=S.products.find(x=>x.id===S.data);
  document.querySelectorAll('.bopt').forEach((b,i)=>b.classList.toggle('on',(i===0&&mode==='normal')||(i===1&&mode==='bundle')));
  document.getElementById('qty-row').style.display=mode==='bundle'?'none':'flex';
  document.getElementById('pd-price').textContent=mode==='bundle'?fmt(p.bundle_price):fmt(p.price);
  document.getElementById('pd-lbp').textContent=`${fmtLBP(mode==='bundle'?p.bundle_price:p.price)} · Delivery $4.00`;
  const earn=calcEarnPts(mode==='bundle'?p.bundle_price:p.price*S.dqty);
  document.getElementById('pts-chip').innerHTML=`★ Earn <strong>${earn}</strong> points with this order`;
}
function selColor(color){S.selectedColor=color||''}
function pdQty(d){const p=S.products.find(x=>x.id===S.data);S.dqty=Math.max(1,S.dqty+d);document.getElementById('pd-qty').value=S.dqty;const earn=calcEarnPts(p.price*S.dqty);document.getElementById('pts-chip').innerHTML=`★ Earn <strong>${earn}</strong> points with this order`}
function pdQtyManual(v){S.dqty=Math.max(1,parseInt(v)||1)}
function addToCart(pid){
  const p=S.products.find(x=>x.id===pid);if(!p)return;
  if(S.buyMode==='bundle'&&p.bundle_qty){
    const uid=p.id+'_bundle_'+encodeURIComponent(S.selectedColor||'');
    const unitPrice=parseFloat((p.bundle_price/p.bundle_qty).toFixed(2));
    const ex=S.cart.find(i=>i._uid===uid);
    if(ex)ex.qty+=p.bundle_qty;else S.cart.push({_uid:uid,product_id:p.id,name:p.name,image:coverImg(p),price:unitPrice,qty:p.bundle_qty,delivery_price:p.delivery_price,is_bundle:true,bundle_label:`${p.bundle_qty}-pack`,selected_color:S.selectedColor||''});
  }else{
    const uid=p.id+'_single_'+encodeURIComponent(S.selectedColor||'');
    const ex=S.cart.find(i=>i._uid===uid);
    if(ex)ex.qty+=S.dqty;else S.cart.push({_uid:uid,product_id:p.id,name:p.name,image:coverImg(p),price:p.price,qty:S.dqty,delivery_price:p.delivery_price,is_bundle:false,bundle_label:'',selected_color:S.selectedColor||''});
  }
  saveCart();updateCartBadge();toast('Added to cart');
}

/* =========================================================
   REVIEW MODAL
========================================================= */
function openReviewModal(pid){
  let rating=5;
  const root=document.getElementById('modal-root');
  root.innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">Write a review</div>
    <div class="star-pick" id="star-pick">${[1,2,3,4,5].map(n=>`<span class="${n<=5?'on':''}" data-n="${n}" onclick="pickStar(${n})">★</span>`).join('')}</div>
    <div class="fgroup"><label class="flabel">Your review <span class="req">*</span></label><textarea class="ftextarea" id="rv-text" placeholder="Share your experience with this product…"></textarea></div>
    <button class="btn btn-primary" onclick="submitReview('${pid}')">Submit review</button>
  </div></div>`;
  window._rvRating=5;
}
function pickStar(n){window._rvRating=n;document.querySelectorAll('#star-pick span').forEach(s=>s.classList.toggle('on',parseInt(s.dataset.n)<=n))}
async function submitReview(pid){
  const text=document.getElementById('rv-text').value.trim();
  if(!text){toast('Please write a comment');return}
  const{error}=await sb.from('reviews').insert({product_id:pid,user_id:S.session.user.id,rating:window._rvRating||5,comment:text,status:'pending'});
  if(error){toast('Could not submit review');return}
  closeModal();toast('Thanks! Your review will appear once approved.');
}
function closeModal(ev){if(ev&&ev.target.className!=='modal-ov')return;document.getElementById('modal-root').innerHTML=''}

/* =========================================================
   WISHLIST PAGE
========================================================= */
async function pWishlist(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your wishlist');return}
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data}=await sb.from('wishlists').select('product_id').eq('user_id',S.session.user.id);
  const ids=(data||[]).map(w=>w.product_id);
  const items=S.products.filter(p=>ids.includes(p.id));
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="section-title" style="margin-bottom:14px">Wishlist (${items.length})</div>
    ${!items.length?`<div class="empty-box"><div class="empty-ico">♡</div><div class="empty-ttl">Your wishlist is empty</div><div class="empty-sub">Tap the heart on any product to save it here.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="resetHome()">Browse products</button></div>`:
    `<div class="grid">${items.map(p=>productCardHTML(p)).join('')}</div>`}
  </div>`;
}
function authRequiredHTML(action){
  return `<div class="page"><div class="empty-box"><div class="empty-ico">🔒</div><div class="empty-ttl">Sign in to ${esc(action)}</div><div class="empty-sub">Create a free account or log in to continue.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="nav('account')">Sign in</button></div></div>`;
}

/* =========================================================
   CART
========================================================= */
function pCart(){
  if(!S.cart.length)return `<div class="page">
    <button class="back-link" onclick="goBack()">← Continue shopping</button>
    <div class="empty-box"><div class="empty-ico">🛒</div><div class="empty-ttl">Your cart is empty</div><div class="empty-sub">Add products to get started.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="resetHome()">Browse products</button></div>
  </div>`;
  const earn=calcEarnPts(cartTotal());
  const rows=S.cart.map(i=>`<div class="ci-row">
    <img src="${esc(i.image)}" onerror="this.src='https://placehold.co/76x76/e7ebf3/98a2b8?text=?'">
    <div class="ci-body">
      <div class="ci-name">${esc(i.name)}${i.selected_color?` · ${esc(i.selected_color)}`:''}</div>
      <div class="ci-meta">${i.is_bundle?i.bundle_label+' · ':''}${fmt(i.price)} each</div>
      <div class="ci-ctrls">
        <button class="mini-btn" onclick="cartQty('${i._uid}',${i.qty-1})">−</button>
        <span style="font-weight:700;min-width:20px;text-align:center;font-family:var(--font-m)">${i.qty}</span>
        <button class="mini-btn" onclick="cartQty('${i._uid}',${i.qty+1})">+</button>
        <span class="ci-sub">${fmt(i.price*i.qty)}</span>
      </div>
    </div>
    <button class="ci-rm" onclick="cartRemove('${i._uid}')">✕</button>
  </div>`).join('');
  return `<div class="page" style="padding-bottom:110px">
    <button class="back-link" onclick="goBack()">← Continue shopping</button>
    ${rows}
    <div class="card" style="padding:15px 18px;display:flex;align-items:center;gap:11px;margin-bottom:14px;background:rgba(245,166,35,.06);border-color:rgba(245,166,35,.3)">
      <div style="font-size:1.35rem">★</div><div style="flex:1"><strong style="font-size:.88rem">You'll earn ${earn} points</strong><div style="font-size:.76rem;color:var(--muted)">from this order</div></div>
    </div>
    <div class="card" style="padding:18px">
      <div class="summary-row"><span>Subtotal</span><span>${fmt(cartSub())}</span></div>
      <div class="summary-row"><span>Delivery</span><span>${fmt(cartDelivery())}</span></div>
      <div class="summary-row total"><span>Total</span><span>${fmt(cartTotal())}</span></div>
    </div>
  </div>
  <div class="sticky-bar"><div class="sticky-bar-in"><button class="btn btn-primary" onclick="nav('checkout')">Checkout — ${fmt(cartTotal())}</button></div></div>`;
}
function cartQty(uid,q){if(q<1){cartRemove(uid);return}const i=S.cart.find(x=>x._uid===uid);if(i)i.qty=q;saveCart();render();updateCartBadge()}
function cartRemove(uid){S.cart=S.cart.filter(x=>x._uid!==uid);saveCart();render();updateCartBadge()}

/* =========================================================
   CHECKOUT
========================================================= */
function pCheckout(){
  const prof=S.profile;
  const loc=S.deliveryLocation||{};
  return `<div class="page" style="padding-bottom:104px">
    <button class="back-link" onclick="goBack()">← Back to cart</button>
    <div class="card form-card">
      <div class="form-title">Contact information</div>
      <div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="co-email" type="email" autocomplete="email" required value="${esc(S.session?.user?.email||'')}"></div>
      <div class="fgroup"><label class="flabel">Full name <span class="req">*</span></label><input class="finput" id="co-name" value="${esc(prof?(prof.first_name+' '+prof.last_name):'')}"></div>
      <div class="frow2">
        <div class="fgroup"><label class="flabel">Phone <span class="req">*</span></label><input class="finput" id="co-phone" value="${esc(prof?.phone||'')}"></div>
        <div class="fgroup"><label class="flabel">Second phone</label><input class="finput" id="co-phone2"></div>
      </div>
    </div>
    <div class="card form-card">
      <div class="form-title">📍 Delivery location</div>
      <div class="delivery-location-card" style="margin-bottom:0">
        ${loc.confirmed_at?`<strong>${esc(loc.city||'')}${loc.district?` · ${esc(loc.district)}`:''}</strong><div style="font-size:.84rem;color:var(--muted);margin-top:4px">${esc(loc.full_address||'')}</div>`:`<div style="font-size:.84rem;color:var(--muted)">Add the delivery address for this order. You can enter it manually.</div>`}
        <div class="delivery-location-actions"><button class="btn btn-ghost btn-sm" onclick="openDeliveryLocationEditor()">${loc.confirmed_at?'Edit saved address':'Add delivery address'}</button></div>
      </div>
      <div class="muted-note" style="margin-top:9px">Delivery is a fixed $4.00 anywhere in Lebanon.</div>
    </div>
    <div class="card form-card">
      <div class="form-title">Delivery address</div>
      <div class="frow2">
        <div class="fgroup"><label class="flabel">City <span class="req">*</span></label><input class="finput" id="co-city" value="${esc(loc.city||'')}"></div>
        <div class="fgroup"><label class="flabel">District / area</label><input class="finput" id="co-district" value="${esc(loc.district||'')}"></div>
      </div>
      <div class="fgroup"><label class="flabel">Full address <span class="req">*</span></label><input class="finput" id="co-address" value="${esc(loc.full_address||'')}"></div>
      <div class="fgroup"><label class="flabel">Floor</label><input class="finput" id="co-floor"></div>
      <div class="fgroup"><label class="flabel">Notes</label><textarea class="ftextarea" id="co-notes"></textarea></div>
    </div>
    <div class="card form-card">
      <div class="form-title">Coupon code</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><input class="finput" id="co-coupon" placeholder="Enter code" style="flex:1;min-width:140px"><button class="btn btn-ghost" style="width:auto;padding:12px 18px" onclick="applyCoupon()">Apply</button></div>
      <div id="coupon-msg" style="font-size:.8rem;margin-top:8px;font-family:var(--font-m)"></div>
    </div>
  </div>
  <div class="sticky-bar"><div class="sticky-bar-in"><button class="btn btn-primary" id="place-order-btn" onclick="placeOrder()">Place order — ${fmt(cartTotal())}</button></div></div>`;
}
S.appliedDiscount=0;S.appliedCoupon=null;
async function applyCoupon(){
  const code=document.getElementById('co-coupon').value.trim().toUpperCase();
  const msg=document.getElementById('coupon-msg');
  if(!code){msg.textContent='';return}
  const{data,error}=await sb.rpc('validate_coupon',{p_code:code,p_subtotal:cartSub()});
  if(error||data==null){S.appliedDiscount=0;S.appliedCoupon=null;msg.textContent='Invalid or expired code';msg.style.color='var(--danger)';return}
  S.appliedDiscount=parseFloat(data);S.appliedCoupon={code};
  msg.textContent=`Applied! You save ${fmt(S.appliedDiscount)}`;msg.style.color='var(--success)';
  document.getElementById('place-order-btn').textContent=`Place order — ${fmt(cartTotal())}`;
}
async function placeOrder(){
  const fields=[['co-name','name'],['co-email','email'],['co-phone','phone'],['co-city','city'],['co-address','address']];
  const info={};let ok=true;
  fields.forEach(([id,key])=>{const el=document.getElementById(id);const v=el.value.trim();if(!v){el.classList.add('inv');ok=false}else{el.classList.remove('inv');info[key]=v}});
  if(!ok){toast('Please fill in all required fields');return}
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(info.email)){document.getElementById('co-email').classList.add('inv');toast('Please enter a valid email address');return}
  info.district=document.getElementById('co-district').value.trim();
  info.phone2=document.getElementById('co-phone2').value.trim();
  info.floor=document.getElementById('co-floor').value.trim();
  info.notes=document.getElementById('co-notes').value.trim();
  const colorNotes=S.cart.filter(i=>i.selected_color).map(i=>`${i.name} — ${i.selected_color} (qty ${i.qty})`);
  if(colorNotes.length)info.notes=[info.notes,`Product colors:\n${colorNotes.join('\n')}`].filter(Boolean).join('\n\n');
  const btn=document.getElementById('place-order-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div> Placing order…';

  /* Prices, delivery, coupon and points are recomputed server-side by place_order(). */
  const{data:res,error}=await sb.rpc('place_order',{p_items:cartPayload(),p_info:info,p_coupon:S.appliedCoupon?S.appliedCoupon.code:null});
  if(error||!res){btn.disabled=false;btn.textContent='Place order';const em=error?.message||'';toast(/coupon_limit_reached/.test(em)?'This coupon reached its per-customer limit':/invalid_coupon/.test(em)?'Coupon is no longer valid':'Could not place order — please try again');return}
  const earn=res.points_earned||0,orderNumber=res.order_number;
  if(S.session&&S.profile)S.profile.loyalty_points=(S.profile.loyalty_points||0)+earn;
  S.currentOrder={number:orderNumber,earn};
  S.cart=[];saveCart();updateCartBadge();S.appliedDiscount=0;S.appliedCoupon=null;
  nav('success',null,false);
}
function pSuccess(){
  const o=S.currentOrder||{};
  return `<div class="page"><div style="text-align:center;padding:44px 18px;max-width:420px;margin:0 auto">
    <div style="font-size:3rem;margin-bottom:14px">✅</div>
    <h2 style="font-family:var(--font-d);font-size:1.4rem;margin-bottom:9px">Order placed!</h2>
    ${o.number?`<div class="card" style="display:inline-block;padding:9px 18px;margin-bottom:12px;font-size:.84rem;font-family:var(--font-m)">Order number: <strong>${esc(o.number)}</strong></div>`:''}
    ${o.earn?`<div class="pts-hero"><div class="pts-hero-num">+${o.earn}</div><div>points earned</div></div>`:''}
    <p style="color:var(--muted);font-size:.9rem;line-height:1.7;margin-bottom:18px">Thanks for shopping with Dash Lebanon. Our team will confirm your order and be in touch shortly.</p>
    <div style="display:flex;flex-direction:column;gap:9px">
      <button class="btn btn-primary" onclick="resetHome()">Back to store</button>
      <button class="btn btn-ghost" onclick="nav('orders',null,false)">تتبع طلبيs</button>
    </div>
  </div></div>`;
}

function cartPayload(){return S.cart.map(i=>({product_id:i.product_id,qty:i.qty,is_bundle:!!i.is_bundle}))}

/* =========================================================
   ORDERS / TRACKING
========================================================= */
async function pOrders(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your orders');return}
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data}=await sb.from('orders').select('*, order_items(*)').eq('user_id',S.session.user.id).order('created_at',{ascending:false});
  const orders=data||[];
  if(!orders.length){app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button><div class="empty-box"><div class="empty-ico">📦</div><div class="empty-ttl">No orders yet</div><div class="empty-sub">Your orders will show up here.</div><br><button class="btn btn-primary" style="width:auto;padding:12px 26px" onclick="resetHome()">Browse products</button></div></div>`;return}
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="section-title" style="margin-bottom:14px">My Orders</div>
    ${orders.map(o=>`<div class="card order-row" onclick="nav('order-detail','${o.id}')" style="cursor:pointer">
      <div class="order-head"><div><div class="order-num">${esc(o.order_number)}</div><div class="order-date">${new Date(o.created_at).toLocaleDateString()}</div></div><span class="status-badge st-${o.status}">${o.status}</span></div>
      <div style="font-size:.83rem;color:var(--muted)">${o.order_items.length} item${o.order_items.length>1?'s':''} · ${fmt(o.total)}</div>
    </div>`).join('')}
  </div>`;
}
async function pOrderDetail(){
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data:o}=await sb.from('orders').select('*, order_items(*)').eq('id',S.data).eq('user_id',S.session?.user?.id||'00000000-0000-0000-0000-000000000000').maybeSingle();
  if(!o){nav('orders');return}
  const steps=['pending','confirmed','processing','shipping','delivered'];
  const cur=steps.indexOf(o.status);
  const cancelled=o.status==='cancelled';
  const canCancel=!cancelled&&o.status!=='delivered';
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="section-head"><div class="section-title" style="font-size:1.1rem">${esc(o.order_number)}</div><span class="status-badge st-${o.status}">${o.status}</span></div>
    ${!cancelled?`<div class="card" style="padding:18px 14px;margin-bottom:14px"><div class="track-steps">${steps.map((s,i)=>`<div class="track-step"><div class="track-dot ${i<=cur?'done':''}">${i<=cur?'✓':i+1}</div><div class="track-lbl">${s}</div></div>`).join('')}</div></div>`:
    `<div class="alert alert-err">This order was cancelled.${o.cancel_reason?' Reason: '+esc(o.cancel_reason):''}</div>`}
    <div class="card" style="padding:18px;margin-bottom:14px">
      <div class="form-title">Items</div>
      ${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)}${i.is_bundle?' ('+esc(i.bundle_label)+')':''} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}
      <div class="summary-row"><span>Subtotal</span><span>${fmt(o.subtotal)}</span></div>
      ${o.discount_amount>0?`<div class="summary-row"><span>Discount</span><span style="color:var(--success)">-${fmt(o.discount_amount)}</span></div>`:''}
      <div class="summary-row"><span>Delivery</span><span>${fmt(o.delivery_fee)}</span></div>
      <div class="summary-row total"><span>Total</span><span>${fmt(o.total)}</span></div>
    </div>
    <div class="card" style="padding:18px;margin-bottom:14px">
      <div class="form-title">Delivery details</div>
      <div class="summary-row"><span>Name</span><span>${esc(o.full_name)}</span></div>
      <div class="summary-row"><span>Phone</span><span>${esc(o.phone)}</span></div>
      <div class="summary-row"><span>Address</span><span style="text-align:right">${esc(o.city)}, ${esc(o.district)} — ${esc(o.full_address)}</span></div>
    </div>
    ${canCancel?`<button class="btn btn-danger" onclick="cancelOrder('${esc(o.id)}','${esc(o.created_at)}')">Cancel order</button>`:''}
  </div>`;
}
async function cancelOrder(id,createdAt){
  const hoursSince=(Date.now()-new Date(createdAt).getTime())/3600000;
  const late=hoursSince>(S.settings.free_cancel_hours||24);
  const reason=prompt(late?`This order is past the free-cancellation window (${S.settings.free_cancel_hours}h). A $${S.settings.cancel_fee} fee may apply — our team will follow up. Add a reason (optional):`:'Add a cancellation reason (optional):');
  if(reason===null)return;
  const{error}=await sb.rpc('cancel_order',{p_order:id,p_reason:reason});
  if(error){toast('Could not cancel this order');return}
  toast('Order cancelled');nav('orders',null,false);
}

/* =========================================================
   POINTS PAGE
========================================================= */
function tierFor(pts){if(pts>=3000)return{name:'Platinum',pct:8};if(pts>=1500)return{name:'Gold',pct:5};if(pts>=500)return{name:'Silver',pct:3};return{name:'Bronze',pct:0}}
async function pPoints(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your points');return}
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data:hist}=await sb.from('points_history').select('*').eq('user_id',S.session.user.id).order('created_at',{ascending:false}).limit(20);
  const pts=S.profile?.loyalty_points||0;const tier=tierFor(pts);
  const next=pts>=3000?null:pts>=1500?3000:pts>=500?1500:500;
  const tiers=[{n:'Bronze',req:'0–499',pct:0},{n:'Silver',req:'500–1499',pct:3},{n:'Gold',req:'1500–2999',pct:5},{n:'Platinum',req:'3000+',pct:8}];
  app().innerHTML=`<div class="page">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="pts-hero"><div style="font-size:.83rem;opacity:.8;font-family:var(--font-m)">Total points</div><div class="pts-hero-num">${pts}</div><div class="rank-badge">${tier.name}</div>${next?`<div style="font-size:.76rem;margin-top:9px;opacity:.85;font-family:var(--font-m)">${next-pts} pts to next tier</div>`:''}</div>
    <div class="tiers">${tiers.map(t=>`<div class="card tier ${t.n===tier.name?'on':''}"><div class="tier-name">${t.n}</div><div class="tier-req">${t.req} pts</div><div class="tier-pct">${t.pct>0?t.pct+'% off':'—'}</div></div>`).join('')}</div>
    <div class="card" style="padding:18px">
      <div class="form-title">Points history</div>
      ${(hist&&hist.length)?hist.map(h=>`<div class="summary-row"><span>${esc(h.note||'Activity')}<br><span style="font-size:.7rem;color:var(--muted)">${new Date(h.created_at).toLocaleDateString()}</span></span><span style="font-weight:800;color:${h.points>0?'var(--success)':'var(--danger)'}">${h.points>0?'+':''}${h.points}</span></div>`).join(''):`<div style="color:var(--muted);font-size:.85rem;padding:10px 0">No activity yet</div>`}
    </div>
  </div>`;
}

/* =========================================================
   ACCOUNT — direct email/password auth (OTP/Firebase removed)
========================================================= */
let authTab='login';
function pAccount(){
  if(!S.session){app().innerHTML=pAuthForms();renderAuthBody();return}
  renderAccountLoggedIn();
}
function pAuthForms(){return `<div class="page" style="max-width:440px">
  <button class="back-link" onclick="goBack()">← Back</button>
  <div class="card form-card"><div class="auth-tabs" id="auth-tabs-nav">
    <button class="auth-tab ${authTab==='login'?'on':''}" onclick="setAuthTab('login')">Log in</button>
    <button class="auth-tab ${authTab==='register'?'on':''}" onclick="setAuthTab('register')">Register</button>
    <button class="auth-tab ${authTab==='forgot'?'on':''}" onclick="setAuthTab('forgot')">Forgot</button>
  </div><div id="auth-msg"></div><div id="auth-body"></div></div></div>`}
function setAuthTab(t){authTab=t;render();renderAuthBody()}
function renderAuthBody(){
 const body=document.getElementById('auth-body');if(!body)return;
 if(authTab==='login') body.innerHTML=`<div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="lg-email" type="email" autocomplete="email"></div><div class="fgroup"><label class="flabel">Password <span class="req">*</span></label><input class="finput" id="lg-pass" type="password" autocomplete="current-password"></div><button class="btn btn-primary" id="lg-btn" onclick="doLogin()">Log in</button>`;
 else if(authTab==='register') body.innerHTML=`<div class="frow2"><div class="fgroup"><label class="flabel">First name <span class="req">*</span></label><input class="finput" id="rg-fname"></div><div class="fgroup"><label class="flabel">Last name <span class="req">*</span></label><input class="finput" id="rg-lname"></div></div><div class="fgroup"><label class="flabel">Username <span class="req">*</span></label><input class="finput" id="rg-username"></div><div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="rg-email" type="email" autocomplete="email"></div><div class="fgroup"><label class="flabel">Phone number</label><input class="finput" id="rg-phone" type="tel" autocomplete="tel"></div><div class="fgroup"><label class="flabel">Password <span class="req">*</span></label><input class="finput" id="rg-pass" type="password" autocomplete="new-password"></div><button class="btn btn-primary" id="rg-btn" onclick="doRegister()">Create account</button>`;
 else body.innerHTML=`<p class="muted-note">Enter your email and we'll send you a reset link.</p><div class="fgroup"><label class="flabel">Email <span class="req">*</span></label><input class="finput" id="fg-email" type="email" autocomplete="email"></div><button class="btn btn-primary" id="fg-btn" onclick="doForgot()">Send reset link</button>`;
}
function authMsg(text,ok){const el=document.getElementById('auth-msg');if(el)el.innerHTML=text?`<div class="alert ${ok?'alert-ok':'alert-err'}">${esc(text)}</div>`:''}
async function doLogin(){const email=document.getElementById('lg-email')?.value.trim(),pass=document.getElementById('lg-pass')?.value;if(!email||!pass)return authMsg('Please fill in all fields',false);const btn=document.getElementById('lg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{error}=await sb.auth.signInWithPassword({email,password:pass});btn.disabled=false;btn.textContent='Log in';if(error)return authMsg(error.message,false);await loadProfileAndWishlist();toast('Welcome back!');nav('account',null,false)}
async function doRegister(){const fname=document.getElementById('rg-fname').value.trim(),lname=document.getElementById('rg-lname').value.trim(),username=document.getElementById('rg-username').value.trim(),email=document.getElementById('rg-email').value.trim(),phone=document.getElementById('rg-phone').value.trim(),pass=document.getElementById('rg-pass').value;if(!fname||!lname||!username||!email||!pass)return authMsg('Please fill in all required fields',false);if(pass.length<6)return authMsg('Password must be at least 6 characters',false);const btn=document.getElementById('rg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{data,error}=await sb.auth.signUp({email,password:pass,options:{data:{first_name:fname,last_name:lname,username,phone}}});btn.disabled=false;btn.textContent='Create account';if(error)return authMsg(error.message,false);if(data.session){S.session=data.session;await loadProfileAndWishlist();toast('Welcome to Dash Lebanon!');nav('account',null,false)}else{authMsg('Account created. You can log in now.',true);setAuthTab('login')}}
async function doForgot(){const email=document.getElementById('fg-email')?.value.trim();if(!email)return authMsg('Please enter your email',false);const btn=document.getElementById('fg-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';const{error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});btn.disabled=false;btn.textContent='Send reset link';authMsg(error?error.message:'If that email is registered, a reset link is on its way.',!error)}

function renderAccountLoggedIn(){
  const p=S.profile||{};
  app().innerHTML=`<div class="page" style="max-width:520px">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="profile-hero">
      <div class="avatar-circ">${esc((p.first_name||'U')[0])}</div>
      <div><div style="font-weight:800">${esc(p.first_name||'')} ${esc(p.last_name||'')}</div><div style="color:var(--muted);font-size:.83rem;font-family:var(--font-m)">@${esc(p.username||'')}</div></div>
    </div>
    <div class="card" style="padding:4px">
      <div class="menu-list">
        <div class="menu-item" onclick="nav('orders')">📦 My Orders <span>›</span></div>
        <div class="menu-item" onclick="nav('wishlist')">♡ Wishlist <span>›</span></div>
        <div class="menu-item" onclick="nav('points')">★ My Points (${p.loyalty_points||0}) <span>›</span></div>
        <div class="menu-item" onclick="openDeliveryLocationEditor()">📍 Delivery location <span>${S.deliveryLocation?.confirmed_at?'Edit':'Add'} ›</span></div>
        <div class="menu-item" onclick="openEditProfile()">✎ Edit profile <span>›</span></div>
      </div>
    </div>
    <button class="btn btn-danger" style="margin-top:14px" onclick="doLogout()">Log out</button>
  </div>`;
}
/* Delivery location editor moved to js/22-location.js */
function openEditProfile(){
  const p=S.profile||{};
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">Edit profile</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">First name</label><input class="finput" id="ep-fname" value="${esc(p.first_name||'')}"></div>
      <div class="fgroup"><label class="flabel">Last name</label><input class="finput" id="ep-lname" value="${esc(p.last_name||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Phone</label><input class="finput" id="ep-phone" value="${esc(p.phone||'')}"></div>
    <button class="btn btn-primary" onclick="saveProfile()">Save changes</button>
  </div></div>`;
}
async function saveProfile(){
  const fname=document.getElementById('ep-fname').value.trim();
  const lname=document.getElementById('ep-lname').value.trim();
  const phone=document.getElementById('ep-phone').value.trim();
  const{error}=await sb.from('profiles').update({first_name:fname,last_name:lname,phone}).eq('id',S.session.user.id);
  if(error){toast('Could not save changes');return}
  S.profile={...S.profile,first_name:fname,last_name:lname,phone};
  closeModal();toast('Profile updated');renderAccountLoggedIn();
}
async function doLogout(){await sb.auth.signOut();if(window.firebase&&firebase.apps.length)await firebase.auth().signOut().catch(()=>{});S.profile=null;S.wishlist=[];S.deliveryLocation=null;toast('Logged out');resetHome()}

/* =========================================================
   CONTACT
========================================================= */
function pContact(){
  const st=S.settings;
  return `<div class="page" style="max-width:560px">
    <button class="back-link" onclick="goBack()">← Back</button>
    <div class="hero" style="padding:28px 22px"><div class="hero-in"><div class="hero-eyebrow">We usually reply within the hour</div><h1 style="font-size:1.5rem">Contact us</h1><p>We're here to help with anything you need.</p></div></div>
    <div class="card form-card">
      <div id="ct-msg"></div>
      <div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="ct-name"></div>
      <div class="fgroup"><label class="flabel">Phone <span class="req">*</span></label><input class="finput" id="ct-phone"></div>
      <div class="fgroup"><label class="flabel">Message <span class="req">*</span></label><textarea class="ftextarea" id="ct-msg-txt"></textarea></div>
      <button class="btn btn-primary" id="ct-btn" onclick="sendContact()">Send message</button>
    </div>
    <div class="card" style="padding:18px;text-align:center">
      <div class="footer-h">Follow us</div>
      <div class="soc-row" style="justify-content:center">
        ${st.instagram_url?`<a href="${esc(st.instagram_url)}" target="_blank">IG</a>`:''}
        ${st.facebook_url?`<a href="${esc(st.facebook_url)}" target="_blank">FB</a>`:''}
        ${st.tiktok_url?`<a href="${esc(st.tiktok_url)}" target="_blank">TT</a>`:''}
        <a href="https://wa.me/${(st.whatsapp_number||'').replace(/\D/g,'')}" target="_blank">WA</a>
      </div>
    </div>
  </div>`;
}
async function sendContact(){
  const name=document.getElementById('ct-name').value.trim();
  const phone=document.getElementById('ct-phone').value.trim();
  const msg=document.getElementById('ct-msg-txt').value.trim();
  if(!name||!phone||!msg){toast('Please fill in all fields');return}
  const btn=document.getElementById('ct-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';
  const{error}=await sb.from('contact_messages').insert({name,phone,message:msg});
  btn.disabled=false;btn.textContent='Send message';
  if(error){document.getElementById('ct-msg').innerHTML='<div class="alert alert-err">Could not send — please try again.</div>';return}
  document.getElementById('ct-msg').innerHTML=`<div class="alert alert-ok">Message sent — we'll get back to you soon.</div>`;
  document.getElementById('ct-name').value='';document.getElementById('ct-phone').value='';document.getElementById('ct-msg-txt').value='';
}

/* =========================================================
   ADMIN LOGIN
========================================================= */
function pAdminLogin(){
  if(S.session&&S.isAdmin){nav('admin','overview',false);return}
  app().innerHTML=`<div class="page" style="max-width:460px;padding-top:42px">
    <div class="card" style="padding:28px;box-shadow:var(--shadow-lg)">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px"><div style="width:48px;height:48px;border-radius:14px;display:grid;place-items:center;background:var(--primary);color:#fff;font-size:22px">🔐</div><div><div class="disp" style="font-size:1.5rem">Admin Login</div><div style="color:var(--muted);font-size:.84rem">Dash Lebanon Administration</div></div></div>
      <div id="admin-login-msg"></div>
      <div class="fgroup"><label class="flabel">Admin email</label><input class="finput" id="admin-username" type="email" autocomplete="username" placeholder="admin@example.com" onkeydown="if(event.key==='Enter')doAdminLogin()"></div>
      <div class="fgroup"><label class="flabel">Password</label><input class="finput" id="admin-password" type="password" autocomplete="current-password" placeholder="Enter password" onkeydown="if(event.key==='Enter')doAdminLogin()"></div>
      <button class="btn btn-primary" id="admin-login-btn" onclick="doAdminLogin()">Sign in to Admin Dashboard</button>
      <div style="margin-top:14px;color:var(--muted);font-size:.78rem;text-align:center">This area is restricted to authorized administrators.</div>
    </div>
  </div>`;
}
function adminLoginMsg(text,ok){const el=document.getElementById('admin-login-msg');if(!el)return;el.innerHTML=text?`<div class="alert ${ok?'alert-ok':'alert-err'}">${esc(text)}</div>`:''}
async function doAdminLogin(){
  const username=document.getElementById('admin-username').value.trim();
  const password=document.getElementById('admin-password').value;
  if(!username||!password){adminLoginMsg('Please enter your username and password.',false);return}
  const btn=document.getElementById('admin-login-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';
  const {error}=await sb.auth.signInWithPassword({email:username,password});
  btn.disabled=false;btn.textContent='Sign in to Admin Dashboard';
  if(error){adminLoginMsg('Invalid admin email or password.',false);return}
  const {data:{session}}=await sb.auth.getSession();S.session=session;
  await loadProfileAndWishlist();
  if(!S.isAdmin){await sb.auth.signOut();S.session=null;S.profile=null;adminLoginMsg('This account is not configured as an administrator.',false);return}
  toast('Welcome to the Admin Dashboard');nav('admin','overview');
}

/* =========================================================
   ADMIN DASHBOARD
========================================================= */
function pAdmin(){
  app().innerHTML=`<div class="admin-shell">
    <div class="admin-sidebar">
      <div class="admin-sidebar-title">Dashboard</div>
      ${adminNavBtn('overview','📊 Overview')}
      ${adminNavBtn('orders','📦 Orders')}
      ${adminNavBtn('products','🏷 Products')}
      ${adminNavBtn('categories','🗂 Categories')}
      ${adminNavBtn('reviews','⭐ Reviews')}
      ${adminNavBtn('messages','✉ Messages')}
      <div class="admin-sidebar-title" style="margin-top:10px">Configuration</div>
      ${adminNavBtn('ai','✨ إعدادات الذكاء الاصطناعي')}
      ${adminNavBtn('settings','⚙ Store Settings')}
    </div>
    <div class="admin-main" id="admin-main">${skeletonAdminBlock()}</div>
  </div>`;
  loadAdminSection(S.adminSection||'overview');
}
function adminNavBtn(id,label){return `<button class="admin-nav-btn ${S.adminSection===id?'on':''}" onclick="navAdminSection('${id}')">${label}</button>`}
function navAdminSection(id){S.adminSection=id;nav('admin',id)}
function skeletonAdminBlock(){return `<div class="skel skel-row" style="width:40%"></div><div class="skel skel-row"></div><div class="skel skel-row"></div><div class="skel skel-row" style="width:70%"></div>`}
function adminEmptyBlock(ico,title,sub){return `<div class="empty-box"><div class="empty-ico">${ico}</div><div class="empty-ttl">${esc(title)}</div><div class="empty-sub">${esc(sub)}</div></div>`}
function adminErrorBlock(msg){return `<div class="alert alert-err">${esc(msg)}</div>`}
async function loadAdminSection(id){
  const main=document.getElementById('admin-main');if(!main)return;
  try{
    switch(id){
      case'overview':return await renderAdminOverview(main);
      case'orders':return await renderAdminOrders(main);
      case'products':return await renderAdminProducts(main);
      case'categories':return await renderAdminCategories(main);
      case'reviews':return await renderAdminReviews(main);
      case'messages':return await renderAdminMessages(main);
      case'ai':return await renderAdminAI(main);
      case'settings':return await renderAdminSettings(main);
      default:return await renderAdminOverview(main);
    }
  }catch(err){main.innerHTML=adminErrorBlock('Something went wrong loading this section.')}
}

/* ---- Overview ---- */
async function renderAdminOverview(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Overview</div></div><div class="stat-grid">${skeletonAdminBlock()}</div>`;
  const[{count:ordersCount},{count:prodCount},{count:userCount},{count:msgCount},{data:revData}]=await Promise.all([
    sb.from('orders').select('*',{count:'exact',head:true}),
    sb.from('products').select('*',{count:'exact',head:true}),
    sb.from('profiles').select('*',{count:'exact',head:true}),
    sb.from('contact_messages').select('*',{count:'exact',head:true}).eq('is_read',false),
    sb.from('orders').select('total').neq('status','cancelled')
  ]);
  const revenue=(revData||[]).reduce((s,o)=>s+parseFloat(o.total||0),0);
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Overview</div></div>
  <div class="stat-grid">
    <div class="card stat-card"><div class="stat-num">${ordersCount||0}</div><div class="stat-lbl">Total orders</div></div>
    <div class="card stat-card"><div class="stat-num">${fmt(revenue)}</div><div class="stat-lbl">Revenue (non-cancelled)</div></div>
    <div class="card stat-card"><div class="stat-num">${prodCount||0}</div><div class="stat-lbl">Products</div></div>
    <div class="card stat-card"><div class="stat-num">${userCount||0}</div><div class="stat-lbl">Registered users</div></div>
    <div class="card stat-card"><div class="stat-num">${msgCount||0}</div><div class="stat-lbl">Unread messages</div></div>
  </div>
  <div class="card" style="padding:18px">
    <div class="form-title" style="margin-bottom:10px">Quick links</div>
    <div style="display:flex;flex-wrap:wrap;gap:8px">
      <button class="btn btn-ghost btn-sm" onclick="navAdminSection('orders')">Manage orders</button>
      <button class="btn btn-ghost btn-sm" onclick="navAdminSection('products')">Manage products</button>
      <button class="btn btn-ghost btn-sm" onclick="navAdminSection('ai')">Configure AI assistant</button>
    </div>
  </div>`;
}

/* ---- Orders ---- */
let adminOrderFilter='all';
async function renderAdminOrders(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Orders</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('orders').select('*, order_items(*)').order('created_at',{ascending:false}).limit(300);
  if(error){main.innerHTML=adminErrorBlock('Could not load orders.');return}
  window._adminOrders=data||[];
  drawAdminOrders(main);
}
function drawAdminOrders(main){
  const list=(window._adminOrders||[]).filter(o=>adminOrderFilter==='all'||o.status===adminOrderFilter);
  const tabs=['all','pending','confirmed','processing','shipping','delivered','cancelled'];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Orders</div></div>
  <div class="admin-tabs">${tabs.map(t=>`<button class="admin-tab ${adminOrderFilter===t?'on':''}" onclick="setAdminOrderFilter('${t}')">${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div>
  ${!list.length?adminEmptyBlock('📦','No orders','No orders match this filter yet.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th></tr>
    ${list.map(o=>`<tr class="clickable" onclick="openAdminOrder('${o.id}')">
      <td class="mono">${esc(o.order_number)}</td><td>${esc(o.full_name||'—')}</td><td>${o.order_items.length}</td><td>${fmt(o.total)}</td>
      <td><span class="status-badge st-${o.status}">${o.status}</span></td><td>${new Date(o.created_at).toLocaleDateString()}</td>
    </tr>`).join('')}
  </table></div>`}`;
}
function setAdminOrderFilter(t){adminOrderFilter=t;drawAdminOrders(document.getElementById('admin-main'))}
function openAdminOrder(id){
  const o=(window._adminOrders||[]).find(x=>x.id===id);if(!o)return;
  const statuses=['pending','confirmed','processing','shipping','delivered','cancelled'];
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()" style="max-width:520px">
    <div class="modal-handle"></div>
    <div class="modal-title">${esc(o.order_number)}</div>
    <div class="muted-note" style="margin-bottom:12px">${esc(o.full_name)} · ${esc(o.phone)}<br>${esc(o.city)}, ${esc(o.district)} — ${esc(o.full_address)}</div>
    ${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}
    ${o.notes?`<div class="muted-note" style="margin:10px 0"><strong>Order notes</strong><br>${esc(o.notes).replace(/\n/g,'<br>')}</div>`:''}
    <div class="summary-row total" style="margin-top:6px"><span>Total</span><span>${fmt(o.total)}</span></div>
    <div class="fgroup" style="margin-top:14px"><label class="flabel">Status</label>
      <select class="fselect" id="adm-order-status">${statuses.map(s=>`<option value="${s}" ${s===o.status?'selected':''}>${s}</option>`).join('')}</select>
    </div>
    <button class="btn btn-primary" onclick="saveOrderStatus('${o.id}')">Save status</button>
  </div></div>`;
}
async function saveOrderStatus(id){
  const status=document.getElementById('adm-order-status').value;
  const{error}=await sb.from('orders').update({status}).eq('id',id);
  if(error){toast('Could not update order');return}
  const o=(window._adminOrders||[]).find(x=>x.id===id);if(o)o.status=status;
  closeModal();toast('Order updated');drawAdminOrders(document.getElementById('admin-main'));
}

/* ---- Products ---- */
async function renderAdminProducts(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Products</div></div>${skeletonAdminBlock()}`;
  const[{data:prods,error},{data:cats}]=await Promise.all([
    sb.from('products').select('*, product_images(id,url,sort_order)').order('created_at',{ascending:false}),
    sb.from('categories').select('*').order('sort_order')
  ]);
  if(error){main.innerHTML=adminErrorBlock('Could not load products.');return}
  const{data:costs,error:costError}=await sb.from('product_costs').select('product_id,cost_price,profit_percent');
  if(costError){main.innerHTML=adminErrorBlock('Apply the separate product-cost SQL file before managing product prices.');return}
  const costByProduct=new Map((costs||[]).map(x=>[x.product_id,x]));
  (prods||[]).forEach(p=>{const c=costByProduct.get(p.id);p.cost_price=c?.cost_price??'';p.profit_percent=c?.profit_percent??30});
  window._adminProducts=prods||[];window._adminCats=cats||[];
  drawAdminProducts(main);
}
function drawAdminProducts(main){
  const list=window._adminProducts||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Products</div><button class="btn btn-primary btn-sm" onclick="openProductModal()">+ Add product</button></div>
  ${!list.length?adminEmptyBlock('🏷','No products yet','Add your first product to get started.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Product</th><th>Category</th><th>Price</th><th>Status</th><th></th></tr>
    ${list.map(p=>`<tr>
      <td><div class="prod-cell"><img class="thumb-24" src="${esc(coverImg(p))}" onerror="this.src='https://placehold.co/60x60/e7ebf3/98a2b8?text=?'">${esc(p.name)}</div></td>
      <td>${esc((window._adminCats||[]).find(c=>c.id===p.category_id)?.name||'—')}</td>
      <td>${fmt(p.price)}</td>
      <td><span class="status-badge ${p.is_active?'st-approved':'st-user'}">${p.is_active?'Active':'Hidden'}</span></td>
      <td style="text-align:right;white-space:nowrap"><button class="btn btn-ghost btn-sm" onclick="openProductModal('${p.id}')">Edit</button> <span class="danger-text" onclick="deleteProduct('${p.id}')">Delete</span></td>
    </tr>`).join('')}
  </table></div>`}`;
}
function openProductModal(id){
  const p=id?(window._adminProducts||[]).find(x=>x.id===id):null;
  const cats=window._adminCats||[];
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()" style="max-width:520px">
    <div class="modal-handle"></div><div class="modal-title">${p?'Edit product':'Add product'}</div>
    <div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="pm-name" value="${esc(p?.name||'')}"></div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Original cost ($) <span class="req">*</span></label><input class="finput" id="pm-cost" type="number" min="0.01" step="0.01" value="${p?.cost_price??''}" oninput="updateProfitPricePreview()"></div>
      <div class="fgroup"><label class="flabel">Profit on cost (%)</label><input class="finput" id="pm-profit" type="number" min="0" step="0.01" value="${p?.profit_percent??30}" oninput="updateProfitPricePreview()"></div>
    </div>
    <div class="fgroup"><label class="flabel">Customer price (calculated)</label><input class="finput" id="pm-price" type="number" step="0.01" value="${p?.price??''}" readonly><div class="muted-note">The original cost and profit rate are only available in the admin dashboard.</div></div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Compare-at price</label><input class="finput" id="pm-compare" type="number" step="0.01" value="${p?.compare_at_price??''}"></div>
    </div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Offer quantity (e.g. 2 pieces)</label><input class="finput" id="pm-bundle-qty" type="number" min="2" step="1" value="${p?.bundle_qty??''}"></div>
      <div class="fgroup"><label class="flabel">Offer total price ($)</label><input class="finput" id="pm-bundle-price" type="number" min="0.01" step="0.01" value="${p?.bundle_price??''}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Available colors (comma or new line separated)</label><textarea class="ftextarea" id="pm-colors" placeholder="Black, White, Blue">${esc((p?.color_options||[]).join('\n'))}</textarea></div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Legacy product delivery price (not used; nationwide fee is $4)</label><input class="finput" id="pm-delivery" type="number" step="0.01" value="${p?.delivery_price??0}"></div>
      <div class="fgroup"><label class="flabel">Category</label><select class="fselect" id="pm-cat"><option value="">— None —</option>${cats.map(c=>`<option value="${c.id}" ${p?.category_id===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select></div>
    </div>
    <div class="fgroup"><label class="flabel">Image URLs (واحد بكل سطر — يدعم 50+)</label><textarea class="ftextarea" id="pm-image-urls" placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.jpg">${esc((p?.product_images||[]).map(x=>x.url).join('\n'))}</textarea></div>
    <div class="fgroup"><label class="flabel">رفع صور من الجهاز (اختيار عدة صور)</label><input class="finput" id="pm-files" type="file" accept="image/*" multiple><div class="muted-note">الصور تُرفع إلى Supabase Storage وتُربط بالمنتج.</div></div>
    <div class="fgroup"><label class="flabel">Description</label><textarea class="ftextarea" id="pm-desc">${esc(p?.description||'')}</textarea></div>
    <div class="toggle-row" style="padding:0 0 14px"><div class="toggle-lbl">Active (visible on the store)</div><label class="switch"><input type="checkbox" id="pm-active" ${p?(p.is_active?'checked':''):'checked'}><span class="switch-track"></span></label></div>
    <button class="btn btn-primary" onclick="saveProduct(${p?`'${p.id}'`:'null'})">Save product</button>
  </div></div>`;
}
async function saveProduct(id){
  const cost=parseFloat(document.getElementById('pm-cost').value);
  const profit=parseFloat(document.getElementById('pm-profit').value);
  const price=Math.round(cost*(1+profit/100)*100)/100;
  const bundleQty=parseInt(document.getElementById('pm-bundle-qty').value,10)||null;
  const bundlePrice=parseFloat(document.getElementById('pm-bundle-price').value)||null;
  if(!Number.isFinite(cost)||cost<=0||!Number.isFinite(profit)||profit<0){toast('Enter a valid original cost and profit rate');return}
  if((bundleQty&&!bundlePrice)||(!bundleQty&&bundlePrice)|| (bundleQty&&bundleQty<2)){toast('Enter both a valid offer quantity and total price');return}
  const row={
    name:document.getElementById('pm-name').value.trim(),
    price,
    bundle_qty:bundleQty,
    bundle_price:bundlePrice,
    color_options:[...new Set(document.getElementById('pm-colors').value.split(/[\n,]+/).map(x=>x.trim()).filter(Boolean))],
    compare_at_price:document.getElementById('pm-compare').value?parseFloat(document.getElementById('pm-compare').value):null,
    delivery_price:parseFloat(document.getElementById('pm-delivery').value)||0,
    category_id:document.getElementById('pm-cat').value||null,
    description:document.getElementById('pm-desc').value.trim(),
    is_active:document.getElementById('pm-active').checked,
  };
  if(!row.name){toast('Product name is required');return}
  let productId=id;
  const saved=id?await sb.from('products').update(row).eq('id',id).select().single():await sb.from('products').insert(row).select().single();
  if(saved.error){console.error(saved.error);toast('Could not save product');return}
  productId=saved.data.id;
  const{error:costSaveError}=await sb.from('product_costs').upsert({product_id:productId,cost_price:cost,profit_percent:profit},{onConflict:'product_id'});
  if(costSaveError){console.error(costSaveError);toast('Product saved, but its private cost did not save. Check the separate SQL file and try again.');return}
  const urls=[...new Set(document.getElementById('pm-image-urls').value.split(/\n+/).map(x=>x.trim()).filter(x=>/^https?:\/\//i.test(x)))];
  const files=[...document.getElementById('pm-files').files];
  const existing=(id?(window._adminProducts||[]).find(x=>x.id===id)?.product_images||[]:[]);
  const rows=[...urls.map((url,i)=>({product_id:productId,url,sort_order:i})),...existing.filter(x=>!urls.includes(x.url)).map((x,i)=>({product_id:productId,url:x.url,sort_order:urls.length+i}))];
  for(let i=0;i<files.length;i++){
    const f=files[i], safe=f.name.replace(/[^\w.\-]/g,'_');
    const path=`${productId}/${Date.now()}-${i}-${safe}`;
    const up=await sb.storage.from('product-images').upload(path,f,{upsert:false,contentType:f.type});
    if(up.error){console.error(up.error);toast('تم حفظ المنتج لكن تعذر رفع إحدى الصور');continue}
    const pub=sb.storage.from('product-images').getPublicUrl(path).data.publicUrl;
    rows.push({product_id:productId,url:pub,sort_order:rows.length});
  }
  if(id) await sb.from('product_images').delete().eq('product_id',productId);
  if(rows.length){const r=await sb.from('product_images').insert(rows);if(r.error)console.error(r.error)}
  if(rows[0]?.url) await sb.from('products').update({cover_image:rows[0].url}).eq('id',productId);
  closeModal();toast('Product saved');renderAdminProducts(document.getElementById('admin-main'));
  const{data}=await sb.from('products').select('*, product_images(id,url,sort_order)').eq('is_active',true).order('created_at',{ascending:false});
  S.products=data||[];
}
function updateProfitPricePreview(){
  const cost=parseFloat(document.getElementById('pm-cost')?.value)||0;
  const profit=parseFloat(document.getElementById('pm-profit')?.value)||0;
  const price=document.getElementById('pm-price');
  if(price)price.value=cost>0?((Math.round(cost*(1+profit/100)*100))/100).toFixed(2):'';
}
async function deleteProduct(id){
  if(!confirm('Delete this product? This cannot be undone.'))return;
  const{error}=await sb.from('products').delete().eq('id',id);
  if(error){toast('Could not delete product');return}
  toast('Product deleted');renderAdminProducts(document.getElementById('admin-main'));
}

/* ---- Categories ---- */
async function renderAdminCategories(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Categories</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('categories').select('*').order('sort_order');
  if(error){main.innerHTML=adminErrorBlock('Could not load categories.');return}
  window._adminCats2=data||[];
  drawAdminCategories(main);
}
function drawAdminCategories(main){
  const list=window._adminCats2||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Categories</div><button class="btn btn-primary btn-sm" onclick="openCategoryModal()">+ Add category</button></div>
  ${!list.length?adminEmptyBlock('🗂','No categories yet','Add a category to organize your products.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Name</th><th>Slug</th><th>Status</th><th></th></tr>
    ${list.map(c=>`<tr><td>${esc(c.name)}</td><td class="mono">${esc(c.slug)}</td><td><span class="status-badge ${c.is_active?'st-approved':'st-user'}">${c.is_active?'Active':'Hidden'}</span></td>
    <td style="text-align:right;white-space:nowrap"><button class="btn btn-ghost btn-sm" onclick="openCategoryModal('${c.id}')">Edit</button> <span class="danger-text" onclick="deleteCategory('${c.id}')">Delete</span></td></tr>`).join('')}
  </table></div>`}`;
}
function openCategoryModal(id){
  const c=id?(window._adminCats2||[]).find(x=>x.id===id):null;
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()">
    <div class="modal-handle"></div><div class="modal-title">${c?'Edit category':'Add category'}</div>
    <div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="cm-name" value="${esc(c?.name||'')}"></div>
    <div class="fgroup"><label class="flabel">Slug <span class="req">*</span></label><input class="finput" id="cm-slug" value="${esc(c?.slug||'')}" placeholder="e.g. kitchen"></div>
    <div class="toggle-row" style="padding:0 0 14px"><div class="toggle-lbl">Active</div><label class="switch"><input type="checkbox" id="cm-active" ${c?(c.is_active?'checked':''):'checked'}><span class="switch-track"></span></label></div>
    <button class="btn btn-primary" onclick="saveCategory(${c?`'${c.id}'`:'null'})">Save category</button>
  </div></div>`;
}
async function saveCategory(id){
  const row={name:document.getElementById('cm-name').value.trim(),slug:document.getElementById('cm-slug').value.trim().toLowerCase().replace(/\s+/g,'-'),is_active:document.getElementById('cm-active').checked};
  if(!row.name||!row.slug){toast('Name and slug are required');return}
  const{error}=id?await sb.from('categories').update(row).eq('id',id):await sb.from('categories').insert(row);
  if(error){toast('Could not save category');return}
  closeModal();toast('Category saved');renderAdminCategories(document.getElementById('admin-main'));
  const{data}=await sb.from('categories').select('*').eq('is_active',true).order('sort_order');S.categories=data||[];
}
async function deleteCategory(id){
  if(!confirm('Delete this category?'))return;
  const{error}=await sb.from('categories').delete().eq('id',id);
  if(error){toast('Could not delete — make sure no products use it.');return}
  toast('Category deleted');renderAdminCategories(document.getElementById('admin-main'));
}

/* ---- Reviews moderation ---- */
async function renderAdminReviews(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Reviews</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('reviews').select('*, profiles(first_name,last_name), products(name)').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock('Could not load reviews.');return}
  window._adminReviews=data||[];drawAdminReviews(main);
}
function drawAdminReviews(main){
  const list=window._adminReviews||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Reviews</div></div>
  ${!list.length?adminEmptyBlock('⭐','No reviews yet','Customer reviews will show up here for moderation.'):`
  <div class="card admin-table-wrap"><table class="admin-table">
    <tr><th>Product</th><th>Customer</th><th>Rating</th><th>Comment</th><th>Status</th><th></th></tr>
    ${list.map(r=>`<tr><td>${esc(r.products?.name||'—')}</td><td>${esc(r.profiles?.first_name||'')} ${esc(r.profiles?.last_name||'')}</td><td>${'★'.repeat(r.rating)}</td><td style="max-width:220px">${esc(r.comment)}</td>
    <td><span class="status-badge st-${r.status}">${r.status}</span></td>
    <td style="white-space:nowrap">${r.status!=='approved'?`<button class="btn btn-ghost btn-sm" onclick="setReviewStatus('${r.id}','approved')">Approve</button>`:''} ${r.status!=='rejected'?`<span class="danger-text" onclick="setReviewStatus('${r.id}','rejected')">Reject</span>`:''}</td></tr>`).join('')}
  </table></div>`}`;
}
async function setReviewStatus(id,status){
  const{error}=await sb.from('reviews').update({status}).eq('id',id);
  if(error){toast('Could not update review');return}
  const r=(window._adminReviews||[]).find(x=>x.id===id);if(r)r.status=status;
  toast('Review updated');drawAdminReviews(document.getElementById('admin-main'));
}

/* ---- Contact messages ---- */
async function renderAdminMessages(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Messages</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('contact_messages').select('*').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock('Could not load messages.');return}
  window._adminMsgs=data||[];drawAdminMessages(main);
}
function drawAdminMessages(main){
  const list=window._adminMsgs||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Messages</div></div>
  ${!list.length?adminEmptyBlock('✉','No messages','Contact form submissions will appear here.'):
  list.map(m=>`<div class="card" style="padding:16px;margin-bottom:10px;${m.is_read?'':'border-color:var(--primary)'}">
    <div style="display:flex;justify-content:space-between;gap:10px"><strong>${esc(m.name)}</strong><span class="muted-note">${new Date(m.created_at).toLocaleString()}</span></div>
    <div class="muted-note" style="margin:4px 0">${esc(m.phone)}</div>
    <div style="font-size:.86rem;margin:8px 0">${esc(m.message)}</div>
    <div style="display:flex;gap:8px">${!m.is_read?`<button class="btn btn-ghost btn-sm" onclick="markMsgRead('${m.id}')">Mark read</button>`:''}<span class="danger-text" onclick="deleteMsg('${m.id}')">Delete</span></div>
  </div>`).join('')}`;
}
async function markMsgRead(id){await sb.from('contact_messages').update({is_read:true}).eq('id',id);const m=(window._adminMsgs||[]).find(x=>x.id===id);if(m)m.is_read=true;drawAdminMessages(document.getElementById('admin-main'))}
async function deleteMsg(id){if(!confirm('Delete this message?'))return;await sb.from('contact_messages').delete().eq('id',id);window._adminMsgs=(window._adminMsgs||[]).filter(x=>x.id!==id);drawAdminMessages(document.getElementById('admin-main'))}

/* ---- إعدادات الذكاء الاصطناعي ---- */
async function renderAdminAI(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">إعدادات الذكاء الاصطناعي</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('ai_settings').select('*').eq('id',1).maybeSingle();
  if(error||!data){main.innerHTML=adminErrorBlock('تعذر تحميل إعدادات الذكاء الاصطناعي.');return}
  window._adminAI=data;
  drawAdminAI(main);
}
function drawAdminAI(main){
  const a=window._adminAI;
  main.innerHTML=`<div class="admin-head"><div class="admin-title">إعدادات الذكاء الاصطناعي</div></div>
  <div class="card" style="padding:18px;margin-bottom:16px">
    <div class="toggle-row"><div><div class="toggle-lbl">تفعيل المساعد الذكي</div><div class="toggle-sub">تشغيل أو إيقاف نافذة المحادثة الذكية لجميع الزوار.</div></div><label class="switch"><input type="checkbox" id="ai-enabled" ${a.enabled?'checked':''}><span class="switch-track"></span></label></div>
  </div>
  <div class="card form-card">
    <div class="form-title">عام</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">اسم المساعد</label><input class="finput" id="ai-name" value="${esc(a.assistant_name||'')}"></div>
      <div class="fgroup"><label class="flabel">اسم الموديل</label><input class="finput" id="ai-model" value="${esc(a.model_name||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">رسالة الترحيب</label><textarea class="ftextarea" id="ai-welcome">${esc(a.welcome_message||'')}</textarea></div>
  </div>
  <div class="card form-card">
    <div class="form-title">المزوّد</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">المزوّد</label><select class="fselect" id="ai-provider"><option value="anthropic" ${a.provider==='anthropic'?'selected':''}>Anthropic</option><option value="openai" ${a.provider==='openai'?'selected':''}>OpenAI-compatible</option></select></div>
      <div class="fgroup"><label class="flabel">رابط API</label><input class="finput" id="ai-url" value="${esc(a.api_url||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">مفتاح API</label><input class="finput" id="ai-apikey" type="password" autocomplete="off" placeholder="${a.api_key?'•••••••••••••••• (saved — leave blank to keep)':'sk-...'}"></div>
    <div class="alert" style="background:rgba(224,67,62,.08);color:var(--danger)">⚠️ يُخزَّن المفتاح في قاعدة البيانات وقد يصل إلى جلسة المتصفح. يجب الحفاظ على أمان حساب الإدارة وإعدادات قاعدة البيانات.</div>
    <button class="btn btn-ghost" type="button" style="width:auto;padding:11px 18px;margin-top:4px" onclick="testAiConnection()" id="ai-test-btn">🔌 اختبار الاتصال بالـAI / Test Connection</button>
    <div id="ai-test-result" style="margin-top:12px"></div>
  </div>
  <div class="card form-card">
    <div class="form-title">التعليمات</div>
    <div class="fgroup"><label class="flabel">تعليمات النظام</label><textarea class="ftextarea" id="ai-instructions" style="min-height:160px">${esc(a.system_instructions||'')}</textarea></div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">المواضيع المسموح بها</label><textarea class="ftextarea" id="ai-allowed">${esc(a.allowed_topics||'')}</textarea></div>
      <div class="fgroup"><label class="flabel">المواضيع الممنوعة</label><textarea class="ftextarea" id="ai-restricted">${esc(a.restricted_topics||'')}</textarea></div>
    </div>
  </div>
  <div class="card form-card">
    <div class="form-title">متقدم</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">درجة الحرارة (0–1)</label><input class="finput" id="ai-temp" type="number" min="0" max="1" step="0.1" value="${a.temperature??0.4}"></div>
      <div class="fgroup"><label class="flabel">الحد الأقصى لرموز الرد</label><input class="finput" id="ai-maxtok" type="number" value="${a.max_tokens??700}"></div>
    </div>
  </div>
  <div class="admin-fab-save"><button class="btn btn-primary" style="width:auto;padding:13px 26px" onclick="saveAiSettings()">حفظ إعدادات الذكاء الاصطناعي</button></div>`;
}
async function saveAiSettings(){
  const apiKeyInput=document.getElementById('ai-apikey').value.trim();
  const row={
    enabled:document.getElementById('ai-enabled').checked,
    assistant_name:document.getElementById('ai-name').value.trim()||'المساعد الذكي',
    model_name:document.getElementById('ai-model').value.trim(),
    welcome_message:document.getElementById('ai-welcome').value.trim(),
    provider:document.getElementById('ai-provider').value,
    api_url:document.getElementById('ai-url').value.trim(),
    system_instructions:document.getElementById('ai-instructions').value.trim(),
    allowed_topics:document.getElementById('ai-allowed').value.trim(),
    restricted_topics:document.getElementById('ai-restricted').value.trim(),
    temperature:parseFloat(document.getElementById('ai-temp').value)||0.4,
    max_tokens:parseInt(document.getElementById('ai-maxtok').value)||700,
    updated_at:new Date().toISOString()
  };
  if(apiKeyInput)row.api_key=apiKeyInput; // leave unchanged if left blank
  const{error}=await sb.from('ai_settings').update(row).eq('id',1);
  if(error){toast('تعذر حفظ إعدادات الذكاء الاصطناعي');return}
  toast('تم حفظ إعدادات الذكاء الاصطناعي');
  const{data}=await sb.from('ai_public_settings').select('*').maybeSingle();
  S.aiPublic=data||S.aiPublic;initAiWidget();
}

/* ---- AI Test Connection ---- */
function aiTestReasonLabel(reason){
  return({
    missing_api_key:'❌ API Key مفقود / API Key is missing',
    missing_model:'❌ Model غير محدد / اسم الموديل is missing',
    missing_url:'❌ رابط API غير محدد / رابط API is missing',
    unauthorized:'❌ API Key غير صحيح (Unauthorized / 401)',
    rate_limited:'❌ Rate Limit — تم تجاوز حد الطلبات (429)',
    quota_or_billing:'❌ مشكلة في الرصيد أو حدود الاستخدام (402/403)',
    model_not_found:'❌ Model غير صحيح أو غير متاح (404)',
    bad_request:'❌ الطلب غير صالح (400) — تحقق من اسم الـModel أو الإعدادات',
    provider_error:'❌ خطأ من مزوّد الـAI (OpenRouter/Anthropic/OpenAI)',
    network_error:'❌ تعذر الوصول للسيرفر (مشكلة اتصال شبكة)',
    edge_function_error:'❌ مشكلة داخل Supabase Edge Function',
    disabled:'⚠️ مساعد الـAI معطّل حالياً (فعّل الزر بالأعلى)',
  })[reason]||'❌ خطأ غير معروف / Unknown error';
}
async function testAiConnection(){
  const btn=document.getElementById('ai-test-btn');
  const box=document.getElementById('ai-test-result');
  const apiKeyInput=document.getElementById('ai-apikey').value.trim(); // sent over HTTPS to our own edge function only; never logged or echoed back
  const payload={
    action:'test',
    provider:document.getElementById('ai-provider').value,
    api_url:document.getElementById('ai-url').value.trim(),
    model_name:document.getElementById('ai-model').value.trim(),
    temperature:parseFloat(document.getElementById('ai-temp').value)||0.4,
    max_tokens:parseInt(document.getElementById('ai-maxtok').value)||700,
  };
  if(apiKeyInput)payload.api_key=apiKeyInput; // omitted => edge function uses the saved key from the database
  btn.disabled=true;const oldLabel=btn.textContent;btn.innerHTML='<span class="spin"></span> جاري الاختبار…';
  box.innerHTML='';
  try{
    const{data,error}=await sb.functions.invoke(AI_FUNCTION_NAME,{body:payload});
    if(error||!data){
      box.innerHTML=`<div class="alert alert-err">❌ تعذر الوصول إلى Edge Function باسم "${esc(AI_FUNCTION_NAME)}". تأكد من نشرها على مشروع Supabase الحالي.<br><span class="mono" style="font-size:.76rem">${esc((error&&error.message)||'no response')}</span></div>`;
    }else if(data.ok){
      box.innerHTML=`<div class="alert alert-ok">
        ✅ تم الاتصال بالـAI بنجاح<br>
        <strong>المزوّد:</strong> ${esc(data.provider||'—')}<br>
        <strong>Model:</strong> ${esc(data.model||'—')}<br>
        API Key يعمل بشكل صحيح — الـAI جاهز للاستخدام.
      </div>`;
    }else{
      box.innerHTML=`<div class="alert alert-err">
        ${aiTestReasonLabel(data.reason)}<br>
        ${data.http_status?`<strong>HTTP Status:</strong> ${esc(String(data.http_status))}<br>`:''}
        ${data.error_code?`<strong>Error Code:</strong> ${esc(String(data.error_code))}<br>`:''}
        ${data.stage?`<strong>مكان الخطأ:</strong> ${esc(data.stage)}<br>`:''}
        ${data.message?`<div class="mono" style="font-size:.76rem;margin-top:6px;white-space:pre-wrap">${esc(data.message)}</div>`:''}
      </div>`;
    }
  }catch(err){
    box.innerHTML=`<div class="alert alert-err">❌ خطأ غير متوقع أثناء الاختبار.<br><span class="mono" style="font-size:.76rem">${esc(err.message||String(err))}</span></div>`;
  }
  btn.disabled=false;btn.textContent=oldLabel;
}

/* ---- Store settings ---- */
async function renderAdminSettings(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Store Settings</div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('settings').select('*').eq('id',1).maybeSingle();
  if(error||!data){main.innerHTML=adminErrorBlock('Could not load settings.');return}
  window._adminSettings=data;drawAdminSettings(main);
}
function drawAdminSettings(main){
  const s=window._adminSettings;
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Store Settings</div></div>
  <div class="card form-card">
    <div class="form-title">Store</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Store name</label><input class="finput" id="st-name" value="${esc(s.store_name||'')}"></div>
      <div class="fgroup"><label class="flabel">Currency rate (USD→LBP)</label><input class="finput" id="st-rate" type="number" value="${s.currency_rate??0}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Hero title</label><input class="finput" id="st-hero" value="${esc(s.hero_title||'')}"></div>
    <div class="fgroup"><label class="flabel">Hero subtitle</label><textarea class="ftextarea" id="st-sub">${esc(s.hero_subtitle||'')}</textarea></div>
    <div class="fgroup"><label class="flabel">Announcement bar</label><input class="finput" id="st-announce" value="${esc(s.announcement||'')}"></div>
  </div>
  <div class="card form-card">
    <div class="form-title">Loyalty & cancellation</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Points per $</label><input class="finput" id="st-pts" type="number" value="${s.points_per_dollar??0}"></div>
      <div class="fgroup"><label class="flabel">Cancel fee ($)</label><input class="finput" id="st-fee" type="number" value="${s.cancel_fee??0}"></div>
    </div>
    <div class="fgroup"><label class="flabel">Free cancellation window (hours)</label><input class="finput" id="st-hours" type="number" value="${s.free_cancel_hours??24}"></div>
  </div>
  <div class="card form-card">
    <div class="form-title">Contact & social</div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">WhatsApp number</label><input class="finput" id="st-wa" value="${esc(s.whatsapp_number||'')}"></div>
      <div class="fgroup"><label class="flabel">Contact email</label><input class="finput" id="st-email" value="${esc(s.contact_email||'')}"></div>
    </div>
    <div class="frow2">
      <div class="fgroup"><label class="flabel">Instagram URL</label><input class="finput" id="st-ig" value="${esc(s.instagram_url||'')}"></div>
      <div class="fgroup"><label class="flabel">Facebook URL</label><input class="finput" id="st-fb" value="${esc(s.facebook_url||'')}"></div>
    </div>
    <div class="fgroup"><label class="flabel">TikTok URL</label><input class="finput" id="st-tt" value="${esc(s.tiktok_url||'')}"></div>
  </div>
  <div class="admin-fab-save"><button class="btn btn-primary" style="width:auto;padding:13px 26px" onclick="saveStoreSettings()">Save settings</button></div>`;
}
async function saveStoreSettings(){
  const row={
    store_name:document.getElementById('st-name').value.trim(),
    currency_rate:parseFloat(document.getElementById('st-rate').value)||0,
    hero_title:document.getElementById('st-hero').value.trim(),
    hero_subtitle:document.getElementById('st-sub').value.trim(),
    announcement:document.getElementById('st-announce').value.trim(),
    points_per_dollar:parseFloat(document.getElementById('st-pts').value)||0,
    cancel_fee:parseFloat(document.getElementById('st-fee').value)||0,
    free_cancel_hours:parseInt(document.getElementById('st-hours').value)||24,
    whatsapp_number:document.getElementById('st-wa').value.trim(),
    contact_email:document.getElementById('st-email').value.trim(),
    instagram_url:document.getElementById('st-ig').value.trim(),
    facebook_url:document.getElementById('st-fb').value.trim(),
    tiktok_url:document.getElementById('st-tt').value.trim(),
  };
  const{error}=await sb.from('settings').update(row).eq('id',1);
  if(error){toast('Could not save settings');return}
  toast('Store settings saved');
  S.settings={...S.settings,...row};applySettingsToChrome();
}

/* =========================================================
   AI ASSISTANT (customer-facing widget)
========================================================= */
const AI={sessionId:null,conversationId:null,messages:[],loading:false,open:false};
let aiLastUserMsg='';
function initAiWidget(){
  const pub=S.aiPublic||{};
  if(!pub.enabled){closeAiPanel();return}
  const nameEl=document.getElementById('ai-head-name');if(nameEl)nameEl.textContent=pub.assistant_name||'المساعد الذكي';
  const avEl=document.getElementById('ai-head-avatar');if(avEl)avEl.textContent=(pub.assistant_name||'A').trim()[0].toUpperCase();
  if(!AI.sessionId){AI.sessionId=localStorage.getItem('dl_ai_session');if(!AI.sessionId){AI.sessionId=(crypto.randomUUID?crypto.randomUUID():'sess-'+Date.now()+'-'+Math.random().toString(16).slice(2));localStorage.setItem('dl_ai_session',AI.sessionId)}}
  renderAiBody();
}
function toggleAiPanel(){AI.open?closeAiPanel():openAiPanel()}
function openAiPanel(){AI.open=true;document.getElementById('ai-panel').classList.add('open');document.getElementById('ai-panel-ov').classList.add('open');setTimeout(()=>{const i=document.getElementById('ai-input');if(i)i.focus()},220)}
function closeAiPanel(){AI.open=false;const p=document.getElementById('ai-panel');const o=document.getElementById('ai-panel-ov');if(p)p.classList.remove('open');if(o)o.classList.remove('open')}
function aiNewConversation(){AI.conversationId=null;AI.messages=[];renderAiBody();toast('تم بدء محادثة جديدة')}
function aiAutoGrow(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,90)+'px'}
function aiInputKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();aiSend()}}
function aiQuick(text){const i=document.getElementById('ai-input');i.value=text;aiSend()}
function aiCleanSpeech(text){return String(text||'').replace(/[\p{Extended_Pictographic}]/gu,' ').replace(/[_*`#~\-–—•|<>[\]{}()]/g,' ').replace(/\s+/g,' ').trim()}
function aiSpeak(index){const m=AI.messages[index];if(!m||!window.speechSynthesis)return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(aiCleanSpeech(m.content));u.lang=/[\u0600-\u06FF]/.test(u.text)?'ar-LB':'en-US';window.speechSynthesis.speak(u)}
function aiVoiceInput(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){toast('التحويل الصوتي غير مدعوم في هذا المتصفح');return}
 const r=new SR();r.lang='ar-LB';r.interimResults=false;r.maxAlternatives=3;
 r.onstart=()=>toast('تحدث الآن…');r.onresult=e=>{const best=[...e.results[0]].sort((a,b)=>b.confidence-a.confidence)[0];const input=document.getElementById('ai-input');input.value=best.transcript;aiAutoGrow(input)};
 r.onerror=()=>toast('تعذر تحويل الصوت إلى نص');r.start();
}
function aiProductCard(pid){
 const p=S.products.find(x=>x.id===pid);if(!p)return'';
 const productImage=p.cover_image||(p.product_images&&p.product_images[0]&&p.product_images[0].url)||'';
 const hasPrice=p.price!==null&&p.price!==undefined&&p.price!==''&&Number.isFinite(Number(p.price));
 const hasOldPrice=p.compare_at_price!==null&&p.compare_at_price!==undefined&&p.compare_at_price!==''&&Number.isFinite(Number(p.compare_at_price));
 const oldPrice=hasOldPrice?Number(p.compare_at_price):null,currentPrice=hasPrice?Number(p.price):null,hasDiscount=hasPrice&&hasOldPrice&&oldPrice>currentPrice,discount=hasDiscount?discPct(oldPrice,currentPrice):0;
 const available=p.is_active===true;
 return `<article class="ai-product">
   ${productImage?`<img src="${esc(productImage)}" alt="${esc(p.name||'صورة المنتج')}" loading="lazy">`:`<div class="ai-product-noimage">لا توجد صورة متاحة</div>`}
   <div class="ai-product-name">${esc(p.name)}</div>
   ${p.description?`<div class="ai-product-desc">${esc(p.description)}</div>`:''}
   ${hasPrice?`<div class="ai-product-price"><span class="ai-product-current">${fmt(p.price)}</span>${hasDiscount?`<del class="ai-product-old">${fmt(oldPrice)}</del>${discount>0?`<span class="ai-product-discount">-${discount}%</span>`:''}`:''}</div>`:''}
   <div class="ai-product-stock ${available?'':'unavailable'}">${available?'● متوفر':'● غير متوفر'}</div>
   ${available&&hasPrice?`<button class="btn btn-primary btn-sm" onclick="quickAdd('${esc(p.id)}');renderAiBody()">أضف إلى السلة</button>`:''}
 </article>`;
}
function aiCartSummary(){return S.cart.map(i=>`${i.name} × ${i.qty} = ${fmt(i.price*i.qty)}`).join('\n')||'السلة فارغة'}
async function aiCreateOrderFromChat(info){
 if(!S.cart.length)throw new Error('السلة فارغة');
 if(!S.deliveryLocation?.confirmed_at)throw new Error('delivery_location_required');
 const info2={name:info.full_name,phone:info.phone,phone2:info.phone2||'',city:info.city||'',district:info.district||'',address:info.address,floor:'',notes:''};
 const {data:res,error}=await sb.rpc('place_order',{p_items:cartPayload(),p_info:info2,p_coupon:null}); if(error||!res)throw error||new Error('order_failed');
 const orderNumber=res.order_number,subtotal=cartSub(),delivery=4,items=S.cart.slice();
 S.cart=[];saveCart();updateCartBadge();
 return {orderNumber,total:res.total,subtotal,delivery,items,info};
}
async function aiOrderDialog(){
 if(!S.cart.length){toast('السلة فارغة');return}
 if(!S.deliveryLocation?.confirmed_at){toast('أضف عنوان التوصيل وأكّده أولاً');openDeliveryLocationEditor(true);return}
 const loc=S.deliveryLocation;
 document.getElementById('modal-root').innerHTML=`<div class="modal-ov"><div class="modal-sheet"><div class="modal-title">تأكيد بيانات الطلب</div>
 <div class="fgroup"><label class="flabel">الاسم الكامل *</label><input class="finput" id="ai-o-name" value="${esc(S.profile?`${S.profile.first_name||''} ${S.profile.last_name||''}`.trim():'')}"></div><div class="fgroup"><label class="flabel">رقم الهاتف *</label><input class="finput" id="ai-o-phone" value="${esc(S.profile?.phone||'')}"></div><div class="fgroup"><label class="flabel">رقم هاتف ثانٍ</label><input class="finput" id="ai-o-phone2"></div>
 <div class="delivery-location-card"><strong>📍 عنوان التوصيل</strong><div class="fgroup" style="margin-top:9px"><label class="flabel">المحافظة / المدينة *</label><input class="finput" id="ai-o-city" value="${esc(loc.city||'')}"></div><div class="fgroup"><label class="flabel">المنطقة / الحي</label><input class="finput" id="ai-o-district" value="${esc(loc.district||'')}"></div><div class="fgroup"><label class="flabel">العنوان التفصيلي *</label><textarea class="ftextarea" id="ai-o-address">${esc(loc.full_address||'')}</textarea></div><button class="btn btn-ghost btn-sm" onclick="closeModal();openDeliveryLocationEditor(true)">تعديل العنوان المحفوظ</button></div>
 <div class="summary-row"><span>إجمالي المنتجات</span><span>${fmt(cartSub())}</span></div><div class="summary-row"><span>رسوم التوصيل الثابتة</span><span>$4.00</span></div><div class="summary-row total"><span>المجموع النهائي</span><span>${fmt(cartSub()+4)}</span></div>
 <button class="btn btn-primary" onclick="aiConfirmOrder()">تأكيد الطلب</button><button class="btn btn-ghost" onclick="closeModal()">إلغاء</button></div></div>`;
}
async function aiConfirmOrder(){
 const info={full_name:document.getElementById('ai-o-name').value.trim(),phone:document.getElementById('ai-o-phone').value.trim(),phone2:document.getElementById('ai-o-phone2').value.trim(),city:document.getElementById('ai-o-city').value.trim(),district:document.getElementById('ai-o-district').value.trim(),address:document.getElementById('ai-o-address').value.trim()};
 if(!info.full_name||!info.phone||!info.city||!info.address){toast('يرجى تعبئة الحقول المطلوبة');return}
 if(!S.deliveryLocation?.confirmed_at){toast('أكّد عنوان التوصيل قبل الطلب');return}
 try{const o=await aiCreateOrderFromChat(info);closeModal();AI.messages.push({role:'assistant',content:`تم إتمام طلبك بنجاح.\n\nرقم الطلب: ${o.orderNumber}\nالاسم: ${o.info.full_name}\nالهاتف: ${o.info.phone}${o.info.phone2?`\nالهاتف الثاني: ${o.info.phone2}`:''}\nعنوان التوصيل: ${o.info.city}${o.info.district?`، ${o.info.district}`:''} — ${o.info.address}\n\nالمنتجات:\n${o.items.map((x,i)=>`${i+1}. ${x.product_name}\nالكمية: ${x.quantity}\nالسعر: ${fmt(x.unit_price)}`).join('\n')}\n\nإجمالي المنتجات: ${fmt(o.subtotal)}\nرسوم التوصيل الثابتة: ${fmt(o.delivery)}\nالمجموع النهائي: ${fmt(o.total)}\n\nتم إرسال طلبك بنجاح.`});renderAiBody();nav('orders',null,false)}catch(e){console.error(e);toast('تعذر إنشاء الطلب')}
}

function renderAiBody(){
  const body=document.getElementById('ai-body');if(!body)return;
  if(!AI.messages.length){
    const pub=S.aiPublic||{};
    body.innerHTML=`<div class="ai-empty"><div class="ai-empty-ico">✨</div><div style="font-weight:700;color:var(--text);margin-bottom:4px">${esc(pub.assistant_name||'المساعد الذكي')}</div><div style="font-size:.83rem">${esc(pub.welcome_message||'اسألني أي شيء عن المتجر.')}</div>
    <div class="ai-suggest">
      <button onclick="aiQuick('ما المنتجات أو العروض المتوفرة حاليًا؟')">العروض الحالية</button>
      <button onclick="aiQuick('كيف يمكنني تتبع طلبي؟')">تتبع طلبي</button>
      <button onclick="aiQuick('ما سياسة التوصيل والإلغاء لديكم؟')">التوصيل والإلغاء</button>
    </div></div>`;
    return;
  }
  body.innerHTML=AI.messages.map((m,idx)=>{
    if(m.role==='user')return `<div class="ai-msg user">${esc(m.content)}</div>`;
    if(m.role==='error')return `<div class="ai-msg error">${esc(m.content)}<br><button class="ai-retry" onclick="aiRetry()">إعادة المحاولة</button></div>`;
    const cards=(m.products||[]).map(aiProductCard).join('');
    const orderBtn=m.offerOrder?`<button class="btn btn-primary btn-sm" onclick="aiOrderDialog()">متابعة الطلب</button>`:'';
    return `<div class="ai-msg assistant">${mdLite(m.content)}${cards}${orderBtn}<div class="ai-msg-actions"><button class="ai-speak" onclick="aiSpeak(${idx})" title="قراءة الرسالة">🔊 قراءة</button></div></div>`;
  }).join('')+(AI.loading?`<div class="ai-typing"><span></span><span></span><span></span></div>`:'');
  body.scrollTop=body.scrollHeight;
}
async function aiSend(){
  const input=document.getElementById('ai-input');
  const text=input.value.trim();
  if(!text||AI.loading)return;
  aiLastUserMsg=text;
  AI.messages.push({role:'user',content:text});
  input.value='';aiAutoGrow(input);
  AI.loading=true;document.getElementById('ai-send').disabled=true;
  renderAiBody();
  await aiCallEdge(text);
}
async function aiRetry(){
  AI.messages=AI.messages.filter(m=>m.role!=='error');
  AI.loading=true;renderAiBody();
  await aiCallEdge(aiLastUserMsg);
}
async function aiCallEdge(text){
  try{

    const { data, error } = await sb.functions.invoke(
      AI_FUNCTION_NAME,
      {
        body: {
          message: text,
          conversationId: AI.conversationId,
          sessionId: AI.sessionId,
          model: "openai/gpt-oss-20b",
          clientContext: {
            products: S.products.map(p=>({id:p.id,name:p.name,price:p.price,compare_at_price:p.compare_at_price,description:p.description,is_active:p.is_active,image:coverImg(p)})),
            cart: S.cart.map(i=>({product_id:i.product_id,name:i.name,qty:i.qty,price:i.price})),
            cartTotals: {subtotal:cartSub(),delivery:cartDelivery(),total:cartTotal()},
            deliveryLocation: S.deliveryLocation&&S.deliveryLocation.confirmed_at?{confirmed:true,city:S.deliveryLocation.city,district:S.deliveryLocation.district||'',full_address:S.deliveryLocation.full_address}:null
          }
        }
      }
    );

    AI.loading = false;

    if(error || !data || data.error){

      console.error("AI Edge Function Error:", error, data);

      AI.messages.push({
        role: 'error',
        content:
          data?.error ||
          data?.message ||
          error?.message ||
          'عذرًا، المساعد الذكي غير متاح حاليًا. يرجى المحاولة لاحقًا.'
      });

    }else{

      console.log("AI Response:", data);

      AI.conversationId =
        data.conversationId ||
        AI.conversationId;

      const reply =
        data.reply ||
        data.message ||
        data.response ||
        data.content ||
        data?.data?.choices?.[0]?.message?.content ||
        'عذرًا، لم أتمكن من إنشاء رد.';

      AI.messages.push({
        role: 'assistant',
        content: reply,
        products: Array.isArray(data.productIds)?data.productIds:[],
        offerOrder: !!data.offerOrder
      });

    }

  }catch(err){

    console.error("AI Unexpected Error:", err);

    AI.loading = false;

    AI.messages.push({
      role: 'error',
      content:
        'عذرًا، المساعد الذكي غير متاح حاليًا. يرجى المحاولة لاحقًا.'
    });

  }

  document.getElementById('ai-send').disabled = false;

  renderAiBody();
}

/* ---- tiny markdown renderer for AI replies: headers, bold/italic, code,
        bullet/numbered lists, and pipe tables → real <table> markup ---- */
function mdLite(raw){
  if(!raw)return'';
  const lines=String(raw).replace(/\r\n/g,'\n').split('\n');
  let html='';let i=0;const n=lines.length;
  const inline=s=>esc(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/(^|[^*])\*([^*]+)\*/g,'$1<em>$2</em>');
  const isTableRow=l=>/^\s*\|.*\|\s*$/.test(l);
  while(i<n){
    const line=lines[i];
    if(/^```/.test(line)){
      const code=[];i++;
      while(i<n&&!/^```/.test(lines[i])){code.push(lines[i]);i++}
      i++;html+=`<pre><code>${esc(code.join('\n'))}</code></pre>`;continue;
    }
    if(isTableRow(line)){
      const rows=[];while(i<n&&isTableRow(lines[i])){rows.push(lines[i]);i++}
      if(rows.length>=2){
        const parseRow=r=>r.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(c=>c.trim());
        const header=parseRow(rows[0]);
        const sepLine=/^[\s:|-]+$/.test(rows[1]);
        const bodyRows=(sepLine?rows.slice(2):rows.slice(1)).map(parseRow);
        html+=`<div class="ai-table-wrap"><table class="ai-table"><thead><tr>${header.map(h=>`<th>${inline(h)}</th>`).join('')}</tr></thead><tbody>${bodyRows.map(r=>`<tr>${r.map(c=>`<td>${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
      }else{html+=`<p>${inline(rows.join(' '))}</p>`}
      continue;
    }
    if(/^#{1,3}\s+/.test(line)){
      const lvl=Math.min(line.match(/^#+/)[0].length+1,3);
      html+=`<h${lvl}>${inline(line.replace(/^#{1,3}\s+/,''))}</h${lvl}>`;i++;continue;
    }
    if(/^\s*[-*]\s+/.test(line)){
      const items=[];while(i<n&&/^\s*[-*]\s+/.test(lines[i])){items.push(lines[i].replace(/^\s*[-*]\s+/,''));i++}
      html+=`<ul>${items.map(it=>`<li>${inline(it)}</li>`).join('')}</ul>`;continue;
    }
    if(/^\s*\d+\.\s+/.test(line)){
      const items=[];while(i<n&&/^\s*\d+\.\s+/.test(lines[i])){items.push(lines[i].replace(/^\s*\d+\.\s+/,''));i++}
      html+=`<ol>${items.map(it=>`<li>${inline(it)}</li>`).join('')}</ol>`;continue;
    }
    if(line.trim()===''){i++;continue}
    const para=[line];i++;
    while(i<n&&lines[i].trim()!==''&&!/^(#{1,3}\s|```|\s*[-*]\s|\s*\d+\.\s)/.test(lines[i])&&!isTableRow(lines[i])){para.push(lines[i]);i++}
    html+=`<p>${para.map(inline).join('<br>')}</p>`;
  }
  return html;
}

/* AI image attachment: keeps images client-side until the AI request. */
let aiPendingImages=[];

/* Keep AI image requests small enough for browser/serverless request limits. */
async function aiPrepareImage(file){
  if(!file||!file.type.startsWith('image/'))throw new Error('invalid_image');
  if(file.size>8*1024*1024)throw new Error('image_too_large');
  const dataUrl=await new Promise((resolve,reject)=>{
    const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);
  });
  const img=await new Promise((resolve,reject)=>{
    const el=new Image();el.onload=()=>resolve(el);el.onerror=reject;el.src=dataUrl;
  });
  const maxSide=1280;
  const scale=Math.min(1,maxSide/Math.max(img.naturalWidth||img.width,img.naturalHeight||img.height));
  const canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round((img.naturalWidth||img.width)*scale));
  canvas.height=Math.max(1,Math.round((img.naturalHeight||img.height)*scale));
  canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
  let quality=0.78, out=canvas.toDataURL('image/jpeg',quality);
  while(out.length>1_200_000&&quality>0.5){
    quality-=0.08;out=canvas.toDataURL('image/jpeg',quality);
  }
  if(out.length>1_500_000)throw new Error('image_too_large');
  return {name:file.name,type:'image/jpeg',dataUrl:out};
}
function aiHandleImages(event){
  const files=Array.from(event.target.files||[])
    .filter(f=>f.type.startsWith('image/')).slice(0,4);
  if(!files.length)return;
  Promise.all(files.map(aiPrepareImage)).then(items=>{
    const total=items.reduce((n,x)=>n+x.dataUrl.length,0);
    if(total>4_500_000)throw new Error('images_too_large');
    aiPendingImages=items;
    toast(`${items.length} image${items.length>1?'s':''} attached`);
    renderAiBody();
  }).catch(e=>{
    console.error('AI image preparation failed:',e);
    toast('الصورة كبيرة أو غير صالحة. جرّب صورة أصغر.');
    aiPendingImages=[];
  });
}

/* Patch AI call to include attached images without exposing provider keys. */
const _dashOriginalAiCallEdge=window.aiCallEdge;
window.aiCallEdge=async function(text){
  if(!aiPendingImages.length)return _dashOriginalAiCallEdge(text);
  const originalInvoke=sb.functions.invoke.bind(sb.functions);
  // The existing AI function accepts JSON. We temporarily wrap invoke so the original function receives images.
  sb.functions.invoke=async function(name,opts){
    if(name===AI_FUNCTION_NAME && opts?.body){opts={...opts,body:{...opts.body,images:aiPendingImages.map(x=>({type:x.type,dataUrl:x.dataUrl}))}}}
    return originalInvoke(name,opts);
  };
  try{return await _dashOriginalAiCallEdge(text)}finally{sb.functions.invoke=originalInvoke;aiPendingImages=[];const input=document.getElementById('ai-image-input');if(input)input.value='';}
};


/* =========================================================
   LOCATION — permission prompt, automatic (GPS + reverse geocoding),
   manual entry, confirmation, saved address. No background tracking:
   position is read once, only after the user taps "Allow"/"Use my location".
========================================================= */
const LOC_ASKED_KEY='dl_loc_asked';
let locDraft=null; // {latitude,longitude,city,district,address,source}
let locReturnToAi=false;

function locEsc(s){return esc(s)}
function locSheet(html){document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet loc-sheet" onclick="event.stopPropagation()"><div class="modal-handle"></div>${html}</div></div>`}

/* First visit only: explain why, then let the user decide. */
async function maybePromptLocation(){
  try{
    if(localStorage.getItem(LOC_ASKED_KEY)||S.deliveryLocation?.confirmed_at||!navigator.geolocation)return;
    if(navigator.permissions){const st=await navigator.permissions.query({name:'geolocation'});if(st.state==='denied'){localStorage.setItem(LOC_ASKED_KEY,'denied');return}}
  }catch(e){}
  setTimeout(()=>{if(S.page==='admin'||S.page==='admin-login')return;
    locSheet(`<div class="loc-hero">📍</div><div class="modal-title">Allow location access</div>
    <p class="muted-note loc-copy">We use your location only to fill in your delivery address when you order. It is read once, never tracked in the background, and you can always type the address instead.</p>
    <button class="btn btn-primary" onclick="locAnswer('allow')">Allow location</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="locAnswer('later')">Not now</button>`)},1500);
}
function locAnswer(a){localStorage.setItem(LOC_ASKED_KEY,a==='allow'?'1':'later');if(a==='allow')openDeliveryLocationEditor(false,'auto');else closeModal()}

function locGetPosition(){
  return new Promise((resolve,reject)=>{
    if(!navigator.geolocation)return reject({code:'unsupported'});
    navigator.geolocation.getCurrentPosition(p=>resolve(p.coords),e=>reject({code:e.code===1?'denied':e.code===3?'timeout':'unavailable'}),{enableHighAccuracy:true,timeout:15000,maximumAge:60000});
  });
}
async function locReverse(latitude,longitude){
  if(typeof DELIVERY_REVERSE_GEOCODING_READY!=='undefined'&&DELIVERY_REVERSE_GEOCODING_READY){
    const{data,error}=await sb.functions.invoke('reverse-geocode',{body:{latitude,longitude}});
    if(!error&&data?.address)return{city:data.city||data.region||'',district:data.district||'',address:data.address};
  }
  const r=await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=18&addressdetails=1&accept-language=en&lat=${encodeURIComponent(latitude)}&lon=${encodeURIComponent(longitude)}`);
  if(!r.ok)throw new Error('geocode_failed');
  const j=await r.json(),a=j.address||{};
  return{city:a.state||a.city||a.town||'',district:a.suburb||a.neighbourhood||a.village||a.town||a.city||'',address:j.display_name||''};
}

function openDeliveryLocationEditor(returnToAi=false,mode){
  locReturnToAi=returnToAi;
  const saved=S.deliveryLocation;
  mode=mode||(saved?.confirmed_at?'saved':(navigator.geolocation?'auto':'manual'));
  if(mode==='saved'){
    locSheet(`<div class="modal-title">📍 Saved delivery location</div>
    <div class="loc-card"><strong>${locEsc(saved.city||'')}${saved.district?' · '+locEsc(saved.district):''}</strong><div class="muted-note">${locEsc(saved.full_address||'')}</div></div>
    <button class="btn btn-primary" onclick="closeModal();${locReturnToAi?'aiOrderDialog()':'void 0'}">Use this location</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="openDeliveryLocationEditor(${locReturnToAi},'auto')">Change</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="deleteDeliveryLocation()">Remove saved address</button>`);return;
  }
  const auto=mode==='auto';
  locSheet(`<div class="modal-title">📍 Delivery location</div>
  <div class="loc-choice"><label class="${auto?'on':''}" onclick="openDeliveryLocationEditor(${locReturnToAi},'auto')"><input type="radio" name="lm" ${auto?'checked':''}> <span><b>Automatic</b><small>Use my current location</small></span></label>
  <label class="${auto?'':'on'}" onclick="openDeliveryLocationEditor(${locReturnToAi},'manual')"><input type="radio" name="lm" ${auto?'':'checked'}> <span><b>Enter manually</b><small>Type your address</small></span></label></div>
  <div id="loc-body"></div>`);
  if(auto)locRunAuto();else locManualForm();
}
let locRunId=0;
async function locRunAuto(){
  const body=document.getElementById('loc-body'),id=++locRunId;
  body.innerHTML=`<div class="loc-status"><div class="spin spin-dark"></div> Finding your location…</div><button class="btn btn-ghost" onclick="locRunId++;locManualForm()">Enter address manually</button>`;
  try{
    const c=await locGetPosition();
    if(id!==locRunId)return;
    locDraft={latitude:+c.latitude.toFixed(6),longitude:+c.longitude.toFixed(6),source:'geolocation'};
    let g={city:'',district:'',address:''};
    try{g=await locReverse(locDraft.latitude,locDraft.longitude)}catch(e){}
    if(id!==locRunId)return;
    Object.assign(locDraft,g);
    if(!g.address){locManualForm('We found you but could not read the address. Please type it.');return}
    body.innerHTML=`<div class="loc-card"><div class="muted-note">Is this your delivery location?</div><strong>${locEsc(g.address)}</strong></div>
    <button class="btn btn-primary" onclick="locConfirmAuto()">Confirm location</button>
    <button class="btn btn-ghost" style="margin-top:8px" onclick="locManualForm('',true)">Change location</button>`;
  }catch(e){
    if(id!==locRunId)return;
    const msg={denied:'Location permission was denied. You can enter the address manually.',timeout:'Locating took too long. Try again or enter it manually.',unavailable:'Your location is unavailable right now. Enter it manually.',unsupported:'This browser does not support location. Enter it manually.'}[e.code]||'Could not get your location.';
    locManualForm(msg);
  }
}
function locManualForm(msg,keep){
  const body=document.getElementById('loc-body');if(!body)return;
  const d=keep&&locDraft?locDraft:(S.deliveryLocation||{});
  if(!keep)locDraft=null;
  body.innerHTML=`${msg?`<div class="alert alert-err">${locEsc(msg)}</div>`:''}
  <div class="fgroup"><label class="flabel">City / governorate <span class="req">*</span></label><input class="finput" id="dl-city" maxlength="120" value="${locEsc(d.city||'')}"></div>
  <div class="fgroup"><label class="flabel">District / area</label><input class="finput" id="dl-district" maxlength="120" value="${locEsc(d.district||'')}"></div>
  <div class="fgroup"><label class="flabel">Full address <span class="req">*</span></label><textarea class="ftextarea" id="dl-address" maxlength="500">${locEsc(d.full_address||d.address||'')}</textarea></div>
  <button class="btn btn-primary" id="dl-save" onclick="saveDeliveryLocation()">Confirm and save address</button>`;
}
function locConfirmAuto(){
  const d=locDraft;if(!d)return;
  persistDeliveryLocation({city:d.city,district:d.district,full_address:d.address,latitude:d.latitude,longitude:d.longitude,source:'geolocation'});
}
function saveDeliveryLocation(){
  const city=document.getElementById('dl-city').value.trim().slice(0,120),district=document.getElementById('dl-district').value.trim().slice(0,120),full_address=document.getElementById('dl-address').value.trim().slice(0,500);
  if(!city||!full_address){toast('Enter the city and full address');return}
  const keepGps=locDraft&&locDraft.address===full_address&&locDraft.city===city;
  persistDeliveryLocation({city,district,full_address,latitude:keepGps?locDraft.latitude:null,longitude:keepGps?locDraft.longitude:null,source:keepGps?'geolocation':'manual'});
}
async function persistDeliveryLocation(l){
  const now=new Date().toISOString();
  const loc={user_id:S.session?.user?.id||null,...l,confirmed_at:now,updated_at:now};
  if(S.session){
    const{error}=await sb.from('delivery_locations').upsert(loc,{onConflict:'user_id'});
    if(error){console.error(error);toast('Could not save the address to your account');return}
  }
  S.deliveryLocation=loc;locDraft=null;closeModal();toast(S.session?'Delivery address saved':'Address confirmed for this order');
  if(locReturnToAi){locReturnToAi=false;aiOrderDialog()}
  else if(S.page==='account')renderAccountLoggedIn();
  else if(S.page==='checkout')rerenderCheckoutKeepInputs();
}
function rerenderCheckoutKeepInputs(){
  const ids=['co-name','co-phone','co-phone2','co-floor','co-notes','co-coupon'],v=Object.fromEntries(ids.map(i=>[i,document.getElementById(i)?.value||'']));
  render();ids.forEach(i=>{const el=document.getElementById(i);if(el&&v[i])el.value=v[i]});
}
async function deleteDeliveryLocation(){
  if(S.session){const{error}=await sb.from('delivery_locations').delete().eq('user_id',S.session.user.id);if(error){toast('Could not remove the address');return}}
  S.deliveryLocation=null;locDraft=null;closeModal();toast('Address removed');
  if(S.page==='account')renderAccountLoggedIn();else if(S.page==='checkout')rerenderCheckoutKeepInputs();
}

/* =========================================================
   MOBILE NAV — bottom bar with a single sliding active circle,
   center "+" quick-action sheet.
========================================================= */
const MN_TABS=['home','orders',null,'chat','profile'];
function mnActive(){
  if(typeof AI!=='undefined'&&AI.open)return'chat';
  const p=S.page;
  if(p==='admin'||p==='admin-login')return null;
  if(p==='orders'||p==='order-detail')return'orders';
  if(p==='account'||p==='points')return'profile';
  return'home';
}
function updateMobileNav(){
  const a=mnActive(),bar=document.getElementById('mobile-nav'),dot=document.getElementById('mn-dot');
  if(!bar)return;
  bar.classList.toggle('hide-nav',a===null);
  document.body.classList.toggle('has-mnav',a!==null);
  document.querySelectorAll('[data-mnav]').forEach(el=>{const on=el.dataset.mnav===a;el.classList.toggle('on',on);el.setAttribute('aria-current',on?'page':'false')});
  const i=MN_TABS.indexOf(a);
  if(dot){dot.style.opacity=i<0?0:1;if(i>=0)dot.style.transform=`translateX(${i*100}%)`}
}
function mnGo(t){
  closePlusSheet();
  if(t==='home')resetHome();
  else if(t==='orders')nav('orders');
  else if(t==='profile')nav('account');
  else if(t==='chat'){toggleAiPanel();setTimeout(updateMobileNav,0)}
}
function openPlusSheet(){
  const n=cartCount();
  document.getElementById('plus-sheet').innerHTML=`<div class="modal-handle"></div><div class="ps-title">Quick actions</div>
  <button onclick="closePlusSheet();${n?"nav('checkout')":"viewAllCategory('all')"}"><span>🛍️</span><b>Add order</b><small>${n?n+' item'+(n>1?'s':'')+' ready to checkout':'Browse products'}</small></button>
  <button onclick="closePlusSheet();openDeliveryLocationEditor()"><span>📍</span><b>Add address</b><small>${S.deliveryLocation?.confirmed_at?'Change delivery location':'Use GPS or type it'}</small></button>
  <button onclick="closePlusSheet();openSearch()"><span>🔍</span><b>Search</b><small>Find a product</small></button>
  <button onclick="closePlusSheet();nav('cart')"><span>🛒</span><b>Cart</b><small>${n} in cart</small></button>
  <button onclick="closePlusSheet();nav('wishlist')"><span>♡</span><b>Favorites</b><small>Saved products</small></button>
  <button onclick="closePlusSheet();nav('contact')"><span>✉️</span><b>Contact us</b><small>We reply fast</small></button>`;
  document.getElementById('plus-ov').classList.add('open');document.getElementById('plus-sheet').classList.add('open');
  document.getElementById('mn-plus').classList.add('on');
}
function closePlusSheet(){
  ['plus-ov','plus-sheet'].forEach(id=>document.getElementById(id)?.classList.remove('open'));
  document.getElementById('mn-plus')?.classList.remove('on');
}
function togglePlusSheet(){document.getElementById('plus-sheet').classList.contains('open')?closePlusSheet():openPlusSheet()}
/* keep the active circle in sync with every navigation / panel change */
(function(){
  const _nav=window.nav;window.nav=function(){const r=_nav.apply(this,arguments);updateMobileNav();return r};
  const _close=window.closeAiPanel;window.closeAiPanel=function(){_close();updateMobileNav()};
  window.addEventListener('popstate',()=>setTimeout(updateMobileNav,0));
  window.addEventListener('DOMContentLoaded',()=>setTimeout(updateMobileNav,0));
})();

/* =========================================================
   GROWTH FEATURES — COUPONS + PROMOTIONS ADMIN
========================================================= */
function growthAdminNav(){
  return `${adminNavBtn('coupons','🎟 Coupons & Offers')}`;
}

/* Re-declare admin shell so the new section is visible. */
function pAdmin(){
  app().innerHTML=`<div class="admin-shell">
    <div class="admin-sidebar">
      <div class="admin-sidebar-title">Dashboard</div>
      ${adminNavBtn('overview','📊 Overview')}
      ${adminNavBtn('orders','📦 Orders')}
      ${adminNavBtn('products','🏷 Products')}
      ${adminNavBtn('categories','🗂 Categories')}
      ${adminNavBtn('reviews','⭐ Reviews')}
      ${adminNavBtn('messages','✉ Messages')}
      <div class="admin-sidebar-title" style="margin-top:10px">Growth</div>
      ${growthAdminNav()}
      <div class="admin-sidebar-title" style="margin-top:10px">Configuration</div>
      ${adminNavBtn('ai','✨ إعدادات الذكاء الاصطناعي')}
      ${adminNavBtn('settings','⚙ Store Settings')}
    </div>
    <div class="admin-main" id="admin-main">${skeletonAdminBlock()}</div>
  </div>`;
  loadAdminSection(S.adminSection||'overview');
}

/* Extend the original dispatcher with the new coupon section. */
const _growthOriginalLoadAdminSection=window.loadAdminSection;
window.loadAdminSection=async function(id){
  if(id==='coupons') return renderAdminCoupons(document.getElementById('admin-main'));
  return _growthOriginalLoadAdminSection(id);
};

async function renderAdminCoupons(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Coupons & Offers</div><button class="btn btn-primary btn-sm" onclick="openCouponModal()">+ New coupon</button></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('coupons').select('*').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock('Could not load coupons. Run the supplied SQL first.');return}
  window._adminCoupons=data||[];
  drawAdminCoupons(main);
}
function drawAdminCoupons(main){
  const list=window._adminCoupons||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Coupons & Offers</div><button class="btn btn-primary btn-sm" onclick="openCouponModal()">+ New coupon</button></div>
  <div class="muted-note" style="margin-bottom:12px">Create percentage or fixed-amount discounts, minimum order values, start/end dates, and per-user usage limits. Rules are enforced server-side.</div>
  ${!list.length?adminEmptyBlock('🎟','No coupons yet','Create your first promotion.'):`
  <div class="card admin-table-wrap"><table class="admin-table"><tr><th>Code</th><th>Discount</th><th>Minimum</th><th>Uses</th><th>Dates</th><th>Status</th><th></th></tr>
  ${list.map(c=>{
    const active=!!c.is_active && (!c.expires_at||new Date(c.expires_at)>new Date()) && (!c.starts_at||new Date(c.starts_at)<=new Date());
    const d=c.discount_type==='percent'?`${c.discount_value}%`:`${fmt(c.discount_value)}`;
    return `<tr><td class="mono"><strong>${esc(c.code)}</strong><div style="font-size:.72rem;color:var(--muted)">${esc(c.description||'')}</div></td><td>${d}</td><td>${fmt(c.min_subtotal||0)}</td><td>${c.used_count||0}${c.max_uses?` / ${c.max_uses}`:''}</td><td style="font-size:.72rem">${c.starts_at?new Date(c.starts_at).toLocaleDateString():'Now'} → ${c.expires_at?new Date(c.expires_at).toLocaleDateString():'∞'}</td><td><span class="status-badge ${active?'st-approved':'st-cancelled'}">${active?'Active':'Off'}</span></td><td style="text-align:right;white-space:nowrap"><button class="btn btn-ghost btn-sm" onclick="openCouponModal('${c.id}')">Edit</button> <button class="btn btn-ghost btn-sm" onclick="toggleCoupon('${c.id}',${!c.is_active})">${c.is_active?'Disable':'Enable'}</button></td></tr>`;
  }).join('')}</table></div>`}`;
}
function openCouponModal(id){
  const c=id?(window._adminCoupons||[]).find(x=>x.id===id):null;
  const iso=v=>v?new Date(v).toISOString().slice(0,16):'';
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()" style="max-width:540px">
    <div class="modal-handle"></div><div class="modal-title">${c?'Edit coupon':'New coupon'}</div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Code *</label><input class="finput" id="cp-code" maxlength="40" value="${esc(c?.code||'')}" placeholder="DASH20"></div><div class="fgroup"><label class="flabel">Type</label><select class="fselect" id="cp-type"><option value="percent" ${c?.discount_type==='percent'||!c?'selected':''}>Percentage</option><option value="fixed" ${c?.discount_type==='fixed'?'selected':''}>Fixed amount</option></select></div></div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Discount *</label><input class="finput" id="cp-value" type="number" step="0.01" min="0" value="${c?.discount_value??''}"></div><div class="fgroup"><label class="flabel">Minimum order</label><input class="finput" id="cp-min" type="number" step="0.01" min="0" value="${c?.min_subtotal??0}"></div></div>
    <div class="fgroup"><label class="flabel">Description</label><input class="finput" id="cp-desc" maxlength="160" value="${esc(c?.description||'')}" placeholder="20% off your order"></div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Starts</label><input class="finput" id="cp-start" type="datetime-local" value="${iso(c?.starts_at)}"></div><div class="fgroup"><label class="flabel">Expires</label><input class="finput" id="cp-end" type="datetime-local" value="${iso(c?.expires_at)}"></div></div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Max total uses</label><input class="finput" id="cp-max" type="number" min="1" value="${c?.max_uses??''}" placeholder="Unlimited"></div><div class="fgroup"><label class="flabel">Max uses / customer</label><input class="finput" id="cp-usermax" type="number" min="1" value="${c?.max_uses_per_user??''}" placeholder="Unlimited"></div></div>
    <label style="display:flex;align-items:center;gap:9px;margin:8px 0 14px"><input id="cp-active" type="checkbox" ${c?.is_active!==false?'checked':''}> Active</label>
    <button class="btn btn-primary" onclick="saveCoupon('${c?.id||''}')">Save coupon</button>
  </div></div>`;
}
async function saveCoupon(id){
  const code=document.getElementById('cp-code').value.trim().toUpperCase().replace(/\s+/g,'');
  const type=document.getElementById('cp-type').value;
  const value=parseFloat(document.getElementById('cp-value').value);
  const min=parseFloat(document.getElementById('cp-min').value)||0;
  if(!/^[A-Z0-9_-]{3,40}$/.test(code)||!(value>0)){toast('Enter a valid code and discount');return}
  if(type==='percent'&&value>100){toast('Percentage cannot exceed 100');return}
  const payload={
    code,
    discount_type:type,
    discount_value:value,
    min_subtotal:min,
    description:document.getElementById('cp-desc').value.trim()||null,
    starts_at:document.getElementById('cp-start').value?new Date(document.getElementById('cp-start').value).toISOString():null,
    expires_at:document.getElementById('cp-end').value?new Date(document.getElementById('cp-end').value).toISOString():null,
    max_uses:parseInt(document.getElementById('cp-max').value)||null,
    max_uses_per_user:parseInt(document.getElementById('cp-usermax').value)||null,
    is_active:document.getElementById('cp-active').checked
  };
  if(payload.expires_at&&payload.starts_at&&new Date(payload.expires_at)<=new Date(payload.starts_at)){toast('Expiry must be after start');return}

  const{data,error}=await sb.rpc('admin_save_coupon',{p_id:id||null,p_coupon:payload});
  if(error){
    console.error('admin_save_coupon',error);
    const detail=[error.code,error.message,error.details,error.hint].filter(Boolean).join(' — ');
    toast(error.code==='23505'?'Coupon code already exists':`Could not save coupon: ${detail||'database error'}`);
    return;
  }
  if(!data){toast('Could not save coupon: no response from database');return}
  closeModal();toast('Coupon saved');await renderAdminCoupons(document.getElementById('admin-main'));
}
async function toggleCoupon(id,active){
  const{data,error}=await sb.rpc('admin_toggle_coupon',{p_id:id,p_active:active});
  if(error){
    console.error('admin_toggle_coupon',error);
    const detail=[error.code,error.message,error.details,error.hint].filter(Boolean).join(' — ');
    toast(`Could not update coupon: ${detail||'database error'}`);
    return;
  }
  const c=(window._adminCoupons||[]).find(x=>x.id===id);if(c)c.is_active=active;drawAdminCoupons(document.getElementById('admin-main'));toast(active?'Coupon enabled':'Coupon disabled');
}

/* =========================================================
   DASH LEBANON — V2 UX / INVOICES / BRAND / PAGES / USERS / VOICE
   Additive upgrade. Keeps the existing palette and Supabase app.
========================================================= */

const DL_PAGE_VIS_DEFAULT={home:true,offers:true,wishlist:true,orders:true,points:true,account:true,contact:true};
const DL_SOCIALS=['instagram','facebook','tiktok','whatsapp'];
let dlVoiceState={recorder:null,chunks:[],blob:null,mime:'',duration:0,timer:null,start:0};

function dlPageVisible(key){
  if(key==='home'||key==='cart'||key==='checkout'||key==='success'||key==='product'||key==='order-detail'||key==='admin'||key==='admin-login') return true;
  const v=S.settings?.page_visibility||{};
  return v[key]!==false;
}

function dlSocialHandle(url,type){
  if(!url)return '';
  try{
    const u=new URL(url);
    let parts=u.pathname.split('/').filter(Boolean);
    if(type==='tiktok' && parts[0]?.startsWith('@')) return parts[0];
    if(type==='instagram') return parts[0]?`@${parts[0].replace(/^@/,'')}`:'';
    if(type==='facebook') return parts[0]?`/${parts.join('/')}`:'';
    return parts[parts.length-1]||'';
  }catch{return ''}
}
function dlSocialLabel(st,type){
  const key=type+'_handle';
  return (st&&st[key]&&st[key].trim()) || dlSocialHandle(st?.[type+'_url'],type) || '';
}
function dlIcon(type){
  const common='viewBox="0 0 24 24" aria-hidden="true" focusable="false"';
  const paths={
    instagram:`<svg ${common} fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.3" cy="6.8" r="1" fill="currentColor" stroke="none"/></svg>`,
    facebook:`<svg ${common} fill="currentColor"><path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.87.24-1.46 1.5-1.46h1.6V3.98c-.28-.04-1.24-.12-2.36-.12-2.34 0-3.95 1.43-3.95 4.06V10H7.6v3h2.7v8h3.2z"/></svg>`,
    tiktok:`<svg ${common} fill="currentColor"><path d="M15.3 3.2c.54 1.92 1.7 3.02 3.52 3.48v3.18c-1.35-.08-2.45-.45-3.52-1.07v6.4a4.9 4.9 0 1 1-4.9-4.9c.3 0 .6.03.9.08v3.28a1.95 1.95 0 1 0 1.82 1.94V3.2h2.18z"/></svg>`,
    whatsapp:`<svg ${common} fill="currentColor"><path d="M12 2.3a9.7 9.7 0 0 0-8.4 14.55L2.7 21.7l4.96-.9A9.7 9.7 0 1 0 12 2.3zm0 17.6a7.9 7.9 0 0 1-4.02-1.1l-.29-.17-2.94.53.55-2.86-.19-.3A7.9 7.9 0 1 1 12 19.9zm4.38-5.95c-.24-.12-1.43-.7-1.65-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1-.37-1.9-1.18-.7-.62-1.18-1.38-1.32-1.61-.14-.24-.01-.37.1-.49.1-.1.24-.27.36-.41.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.31-.74-1.79-.19-.47-.39-.41-.54-.42h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2 0 1.18.86 2.32.98 2.48.12.16 1.68 2.56 4.07 3.59.57.25 1.01.4 1.35.51.57.18 1.09.16 1.5.1.46-.07 1.43-.58 1.63-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28z"/></svg>`
  };
  return paths[type]||'';
}
function dlSocialsHTML(st, opts={}){
  const cls=opts.className||'social-icon-row';
  const only=opts.only||DL_SOCIALS;
  return only.map(type=>{
    const url=type==='whatsapp'
      ? ((st?.whatsapp_number||'').replace(/\D/g,'')?`https://wa.me/${st.whatsapp_number.replace(/\D/g,'')}?text=${encodeURIComponent('مرحبا، بدي استفسر عن منتجاتكم.')}`:(st?.whatsapp_link||'').trim())
      : (st?.[type+'_url']||'');
    if(!url)return '';
    return `<a class="social-icon" href="${esc(url)}" target="_blank" rel="noopener noreferrer" aria-label="${type}"><span>${dlIcon(type)}</span><span class="social-icon-name">${esc(dlSocialLabel(st,type))}</span></a>`;
  }).join('');
}
function dlBrandMarkup(st,compact=false){
  const name=esc(st?.store_name||'Dash Lebanon');
  return st?.logo_url
    ? `<img class="brand-logo" src="${esc(st.logo_url)}" alt="${name}" onerror="this.classList.add('broken')"><span class="brand-word">${name}</span>`
    : `<span class="dot"></span><span class="brand-word">${name}</span>`;
}
function dlRefreshBrandChrome(){
  const st=S.settings||{};
  document.querySelectorAll('.brand').forEach(el=>el.innerHTML=dlBrandMarkup(st));
  const fb=document.getElementById('footer-brand');
  if(fb)fb.innerHTML=dlBrandMarkup(st,true);
  let fav=document.getElementById('site-favicon');
  if(!fav){fav=document.createElement('link');fav.id='site-favicon';fav.rel='icon';document.head.appendChild(fav)}
  fav.href=st.favicon_url||st.logo_url||'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="%232952e3"/><circle cx="32" cy="32" r="11" fill="%23f5a623"/></svg>';
  const themeMeta=document.querySelector('meta[name="theme-color"]');if(themeMeta&&st.primary_color)themeMeta.content=themeMeta.content;
}
function dlApplyPageVisibility(){
  const mapping={offers:'offers',wishlist:'wishlist',orders:'orders',contact:'contact'};
  document.querySelectorAll('[data-page-gate]').forEach(el=>el.classList.toggle('hide',!dlPageVisible(el.dataset.pageGate)));
  Object.entries(mapping).forEach(([k])=>{
    document.querySelectorAll(`[data-nav="${k}"]`).forEach(el=>el.classList.toggle('hide',!dlPageVisible(k)));
  });
}

function dlAdminNav(id,label,icon){return `<button class="admin-nav-btn ${S.adminSection===id?'on':''}" onclick="navAdminSection('${id}')"><span class="admin-nav-icon">${icon}</span><span>${label}</span></button>`}
function dlAdminShell(){
  return `<div class="admin-shell v2-admin-shell">
    <aside class="admin-sidebar v2-admin-sidebar">
      <div class="admin-brand-panel"><div class="admin-brand-kicker">Control center</div><div class="admin-brand-title">${esc(S.settings?.store_name||'Store')} <span>Workspace</span></div></div>
      <div class="admin-sidebar-title">Manage</div>
      ${dlAdminNav('overview','Overview','◈')}
      ${dlAdminNav('orders','Orders','▤')}
      ${dlAdminNav('products','Products','◇')}
      ${dlAdminNav('categories','Categories','⌘')}
      ${dlAdminNav('reviews','Reviews','★')}
      ${dlAdminNav('messages','Messages','✉')}
      ${dlAdminNav('users','Customers','◯')}
      <div class="admin-sidebar-title" style="margin-top:14px">Growth</div>
      ${dlAdminNav('coupons','Coupons & Offers','%')}
      <div class="admin-sidebar-title" style="margin-top:14px">Configuration</div>
      ${dlAdminNav('settings','Store Settings','⚙')}
      ${dlAdminNav('ai','AI Assistant','✦')}
      <div class="admin-sidebar-status"><span class="status-dot"></span> Secure admin session</div>
    </aside>
    <main class="admin-main v2-admin-main" id="admin-main">${skeletonAdminBlock()}</main>
  </div>`;
}
window.pAdmin=function(){app().innerHTML=dlAdminShell();loadAdminSection(S.adminSection||'overview')};

const _v2BaseLoad=window.loadAdminSection;
window.loadAdminSection=async function(id){
  const main=document.getElementById('admin-main');
  if(id==='users')return renderAdminUsers(main);
  if(id==='orders')return renderAdminOrdersV2(main);
  if(id==='messages')return renderAdminMessagesV2(main);
  if(id==='settings')return renderAdminSettingsV2(main);
  return _v2BaseLoad(id);
};

async function renderAdminUsers(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Customers</div><div class="admin-kicker">Account access and customer overview</div></div></div><div class="admin-card-grid"><div class="card admin-command"><div class="admin-command-icon">◯</div><div><strong>Account controls</strong><div class="muted-note">Disable or re-enable an account from here. Password changes use a secure reset email.</div></div></div></div>${skeletonAdminBlock()}`;
  const {data,error}=await sb.rpc('admin_list_users');
  if(error){main.innerHTML=adminErrorBlock(`Could not load users: ${error.message||'database error'}`);return}
  window._adminUsers=data||[];
  drawAdminUsers(main);
}
function drawAdminUsers(main){
  const list=window._adminUsers||[];
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Customers</div><div class="admin-kicker">${list.length} account${list.length===1?'':'s'} in your store</div></div></div>
  ${!list.length?adminEmptyBlock('◯','No users','Registered customers will appear here.'): `<div class="card admin-table-wrap v2-table-card"><table class="admin-table v2-table"><thead><tr><th>Customer</th><th>Contact</th><th>Role</th><th>Access</th><th>Joined</th><th></th></tr></thead><tbody>${list.map(u=>{
    const status=u.account_status||'enabled';
    return `<tr><td><div class="user-cell"><div class="user-avatar">${esc((u.first_name||u.email||'U').slice(0,1).toUpperCase())}</div><div><strong>${esc([u.first_name,u.last_name].filter(Boolean).join(' ')||u.username||'Unnamed')}</strong><div class="muted-note">@${esc(u.username||'—')}</div></div></div></td><td><div>${esc(u.email||'—')}</div><div class="muted-note">${esc(u.phone||'')}</div></td><td><span class="status-badge ${u.role==='admin'?'st-admin':'st-user'}">${u.role==='admin'?'Admin':'Customer'}</span></td><td><span class="state-pill ${status==='enabled'?'is-on':status==='disabled'?'is-off':'is-ban'}"><i></i>${status}</span></td><td>${u.created_at?new Date(u.created_at).toLocaleDateString():'—'}</td><td class="actions-cell"><button class="btn btn-ghost btn-sm" onclick="adminToggleUser('${u.id}','${status==='enabled'?'disabled':'enabled'}')">${status==='enabled'?'Disable':'Enable'}</button>${status!=='banned'?`<button class="btn btn-ghost btn-sm" onclick="adminToggleUser('${u.id}','banned')">Ban</button>`:`<button class="btn btn-ghost btn-sm" onclick="adminToggleUser('${u.id}','enabled')">Unban</button>`}<button class="btn btn-ghost btn-sm" onclick="adminSendReset('${esc(u.email||'')}')">Reset password</button></td></tr>`;
  }).join('')}</tbody></table></div>`}`;
}
async function adminToggleUser(id,status){
  const {data,error}=await sb.rpc('admin_set_account_status',{p_user_id:id,p_status:status});
  if(error){toast(`Could not update account: ${error.message||'error'}`);return}
  const u=(window._adminUsers||[]).find(x=>x.id===id);if(u)u.account_status=status;
  drawAdminUsers(document.getElementById('admin-main'));toast(status==='enabled'?'Account enabled':'Account disabled');
}
async function adminSendReset(email){
  if(!email){toast('This user has no email address available');return}
  if(!confirm(`Send a password reset link to ${email}?`))return;
  const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});
  if(error){toast(`Could not send reset: ${error.message}`);return}
  toast('Password reset email sent');
}

/* ---------------- Orders / invoices ---------------- */
function dlStatusLabel(s){return s?String(s).replace(/_/g,' '):'—'}
function dlInvoice(order, opts={}){
  const st=S.settings||{};
  const items=order.order_items||[];
  const hasDiscount=parseFloat(order.discount_amount||0)>0;
  const social=DL_SOCIALS.map(t=>{
    const url=t==='whatsapp'?(st.whatsapp_link||((st.whatsapp_number||'').replace(/\D/g,'')?`https://wa.me/${st.whatsapp_number.replace(/\D/g,'')}`:'')):(st[t+'_url']||'');
    if(!url)return '';
    return `<a href="${esc(url)}">${dlIcon(t)}<span>${esc(dlSocialLabel(st,t))}</span></a>`;
  }).join('');
  return `<section class="invoice ${opts.preview?'invoice-preview':''} ${opts.compact?'invoice-compact':''}
    ><div class="invoice-top"><div class="invoice-brand">${st.logo_url?`<img src="${esc(st.logo_url)}" alt="">`:''}<div><div class="invoice-store">${esc(st.store_name||'Store')}</div><div class="invoice-tag">${esc(st.hero_subtitle||'')}</div></div></div><div class="invoice-meta"><b>INVOICE</b><span>${esc(order.order_number||order.id||'')}</span><span>${order.created_at?new Date(order.created_at).toLocaleString():''}</span></div></div>
    <div class="invoice-grid"><div class="invoice-box"><div class="invoice-label">BILL TO</div><strong>${esc(order.full_name||'—')}</strong><div>${esc(order.phone||'')}</div>${order.phone2?`<div>${esc(order.phone2)}</div>`:''}<div>${esc(order.city||'')}${order.district?`, ${esc(order.district)}`:''}</div><div>${esc(order.full_address||'')}</div>${order.floor?`<div>Floor: ${esc(order.floor)}</div>`:''}</div><div class="invoice-box"><div class="invoice-label">ORDER</div><div>Status <strong>${esc(dlStatusLabel(order.status))}</strong></div>${order.coupon_code?`<div>Coupon <strong>${esc(order.coupon_code)}</strong></div>`:''}${order.notes?`<div>Notes: ${esc(order.notes)}</div>`:''}</div></div>
    <table class="invoice-items"><thead><tr><th>Product</th><th>Qty</th><th>Unit</th><th>Total</th></tr></thead><tbody>${items.map(i=>`<tr><td><strong>${esc(i.product_name||'Item')}</strong>${i.is_bundle&&i.bundle_label?`<small>${esc(i.bundle_label)}</small>`:''}</td><td>${i.quantity||0}</td><td>${fmt(i.unit_price)}</td><td>${fmt((parseFloat(i.unit_price)||0)*(i.quantity||0))}</td></tr>`).join('')}</tbody></table>
    <div class="invoice-summary"><div><span>Subtotal</span><b>${fmt(order.subtotal)}</b></div>${hasDiscount?`<div class="invoice-discount"><span>Discount${order.coupon_code?` · ${esc(order.coupon_code)}`:''}</span><b>-${fmt(order.discount_amount)}</b></div>`:''}<div><span>Delivery</span><b>${fmt(order.delivery_fee)}</b></div><div class="invoice-grand"><span>Total</span><b>${fmt(order.total)}</b></div></div>
    <div class="invoice-foot"><div><strong>Thank you for your order.</strong><span>Cash on delivery · Lebanon</span></div><div class="invoice-socials">${social}</div></div>
  </section>`;
}
function dlPrintDocument(invoices){
  const pages=[];
  for(let i=0;i<invoices.length;i+=2){pages.push(`<div class="print-page">${dlInvoice(invoices[i],{compact:true})}${invoices[i+1]?dlInvoice(invoices[i+1],{compact:true}):'<div class="invoice-spacer"></div>'}</div>`)}
  return `<!doctype html><html><head><meta charset="utf-8"><title>Invoices</title><style>${dlPrintCSS()}</style></head><body>${pages.join('')}</body></html>`;
}
function dlPrintOneDocument(order){return `<!doctype html><html><head><meta charset="utf-8"><title>Invoice ${esc(order.order_number||'')}</title><style>${dlPrintCSS()} .print-page.one{grid-template-rows:1fr}.print-page.one .invoice{height:100%}</style></head><body><div class="print-page one">${dlInvoice(order,{compact:false})}</div></body></html>`}
function dlPrintCSS(){return `
@page{size:A4;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}.print-page{width:210mm;height:297mm;padding:7mm;display:grid;grid-template-rows:1fr 1fr;overflow:hidden;page-break-after:always}.invoice{height:calc((297mm - 14mm)/2);border:1px solid #cfd5df;padding:7mm;display:flex;flex-direction:column;overflow:hidden;position:relative;background:#fff}.invoice-spacer{height:100%}.invoice-top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;border-bottom:1px solid #e3e7ef;padding-bottom:5mm}.invoice-brand{display:flex;align-items:center;gap:10px;min-width:0}.invoice-brand img{width:13mm;height:13mm;object-fit:contain;border-radius:3mm}.invoice-store{font-size:17pt;font-weight:800;letter-spacing:-.3px}.invoice-tag{font-size:8pt;color:#6a7382;margin-top:2px;max-width:85mm}.invoice-meta{display:flex;flex-direction:column;text-align:right;gap:2px;font-size:8pt;color:#6a7382}.invoice-meta b{font-size:11pt;color:#111}.invoice-grid{display:grid;grid-template-columns:1.3fr 1fr;gap:4mm;margin:4mm 0}.invoice-box{border:1px solid #e1e5ed;border-radius:3mm;padding:3.4mm;font-size:8pt;line-height:1.55}.invoice-label{font-size:6.5pt;font-weight:800;letter-spacing:1px;color:#788294;margin-bottom:1.5mm}.invoice-items{width:100%;border-collapse:collapse;font-size:7.5pt}.invoice-items th{text-transform:uppercase;font-size:6.5pt;color:#6d7685;letter-spacing:.5px;text-align:left;border-bottom:1px solid #d9dee7;padding:2.5mm 1.5mm}.invoice-items td{padding:2.6mm 1.5mm;border-bottom:1px solid #edf0f4;vertical-align:top}.invoice-items th:not(:first-child),.invoice-items td:not(:first-child){text-align:right}.invoice-items small{display:block;color:#7b8492;margin-top:1px}.invoice-summary{margin-left:auto;width:62mm;margin-top:4mm;font-size:8pt}.invoice-summary>div{display:flex;justify-content:space-between;padding:1.7mm 0}.invoice-discount{color:#16824d}.invoice-grand{font-size:11pt;border-top:1.5px solid #111;margin-top:1mm;padding-top:3mm!important}.invoice-foot{margin-top:auto;border-top:1px solid #e3e7ef;padding-top:3mm;display:flex;justify-content:space-between;align-items:flex-end;gap:12mm;font-size:7pt;color:#6d7682}.invoice-foot strong{display:block;color:#111;font-size:8pt}.invoice-foot span{display:block;margin-top:1px}.invoice-socials{display:flex;gap:3mm;align-items:center;flex-wrap:wrap;justify-content:flex-end}.invoice-socials a{display:flex;align-items:center;gap:1.5mm;color:#222;text-decoration:none}.invoice-socials svg{width:4mm;height:4mm}.invoice-socials span{font-size:6.5pt}.invoice-compact{padding:5.5mm}.invoice-compact .invoice-top{padding-bottom:3.5mm}.invoice-compact .invoice-brand img{width:9mm;height:9mm}.invoice-compact .invoice-store{font-size:12pt}.invoice-compact .invoice-tag{font-size:6.5pt}.invoice-compact .invoice-grid{margin:3mm 0;gap:3mm}.invoice-compact .invoice-box{padding:2.4mm;font-size:6.6pt}.invoice-compact .invoice-items{font-size:6.3pt}.invoice-compact .invoice-items th{font-size:5.5pt;padding:1.6mm 1mm}.invoice-compact .invoice-items td{padding:1.8mm 1mm}.invoice-compact .invoice-summary{font-size:6.7pt;width:48mm;margin-top:2.5mm}.invoice-compact .invoice-summary>div{padding:1mm 0}.invoice-compact .invoice-grand{font-size:8.5pt;padding-top:2mm!important}.invoice-compact .invoice-foot{padding-top:2mm;font-size:5.8pt}.invoice-compact .invoice-foot strong{font-size:6.5pt}.invoice-compact .invoice-socials{gap:2mm}.invoice-compact .invoice-socials svg{width:3mm;height:3mm}.invoice-compact .invoice-socials span{font-size:5.5pt}`}
function dlOpenPrint(html){
  // Open synchronously from the button click so popup blockers are less likely to interfere.
  let w=null;
  try{w=window.open('','_blank')}catch{}
  if(w){
    try{
      w.addEventListener('load',()=>setTimeout(()=>{try{w.focus();w.print()}catch(e){console.error('Print failed',e);}},350),{once:true});
      w.document.open();w.document.write(html);w.document.close();w.opener=null;
      return true;
    }catch(e){try{w.close()}catch{}console.error('Print window failed',e)}
  }
  // Fallback when the browser blocks new windows: print from a temporary hidden frame.
  try{
    const frame=document.createElement('iframe');
    frame.setAttribute('title','Invoice print preview');
    frame.setAttribute('aria-hidden','true');
    frame.style.cssText='position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;opacity:0;pointer-events:none';
    frame.onload=()=>setTimeout(()=>{try{frame.contentWindow.focus();frame.contentWindow.print()}catch(e){console.error('Frame print failed',e);toast('Printing failed. Try Ctrl+P or allow pop-ups for this site')}},350);
    document.body.appendChild(frame);
    frame.srcdoc=html;
    return true;
  }catch(e){console.error('Print setup failed',e);toast('Could not open print preview. Allow pop-ups or press Ctrl+P.');return false}
}
function viewInvoice(id){const o=(window._adminOrders||[]).find(x=>x.id===id)||S.currentOrder;if(!o)return;document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet invoice-modal" onclick="event.stopPropagation()"><div class="modal-handle"></div><div class="invoice-toolbar"><div><div class="modal-title">Invoice ${esc(o.order_number||'')}</div><div class="muted-note">Print-ready A4 invoice preview</div></div><button class="btn btn-primary btn-sm" onclick="printInvoice('${o.id}')">Print invoice</button></div><div class="invoice-preview-wrap">${dlInvoice(o,{preview:true})}</div></div></div>`}
function printInvoice(id){const o=(window._adminOrders||[]).find(x=>x.id===id)||S.currentOrder;if(!o){toast('Invoice not found');return}dlOpenPrint(dlPrintOneDocument(o))}
function printAllInvoices(){const list=window._adminOrders||[];if(!list.length){toast('No orders to print');return}dlOpenPrint(dlPrintDocument(list))}

async function renderAdminOrdersV2(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Orders</div><div class="admin-kicker">Orders, invoices, delivery details</div></div><div class="admin-head-actions"><button class="btn btn-primary btn-sm" onclick="printAllInvoices()">▣ Print all invoices</button></div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('orders').select('*, order_items(*)').order('created_at',{ascending:false}).limit(500);
  if(error){main.innerHTML=adminErrorBlock(`Could not load orders: ${error.message||'database error'}`);return}
  window._adminOrders=data||[];drawAdminOrdersV2(main);
}
function drawAdminOrdersV2(main){
  const list=(window._adminOrders||[]).filter(o=>adminOrderFilter==='all'||o.status===adminOrderFilter);
  const tabs=['all','pending','confirmed','processing','shipping','delivered','cancelled'];
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Orders</div><div class="admin-kicker">${list.length} visible order${list.length===1?'':'s'}</div></div><div class="admin-head-actions"><button class="btn btn-primary btn-sm" onclick="printAllInvoices()">▣ Print all invoices</button></div></div>
  <div class="admin-tabs v2-admin-tabs">${tabs.map(t=>`<button class="admin-tab ${adminOrderFilter===t?'on':''}" onclick="setAdminOrderFilter('${t}')">${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div>
  ${!list.length?adminEmptyBlock('▤','No orders','No orders match this filter yet.'): `<div class="card admin-table-wrap v2-table-card"><table class="admin-table v2-table"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th><th></th></tr></thead><tbody>${list.map(o=>`<tr class="clickable"><td onclick="openAdminOrderV2('${o.id}')"><span class="mono">${esc(o.order_number)}</span></td><td onclick="openAdminOrderV2('${o.id}')"><div><strong>${esc(o.full_name||'—')}</strong></div><div class="muted-note">${esc(o.phone||'')}</div></td><td onclick="openAdminOrderV2('${o.id}')">${o.order_items?.length||0}</td><td onclick="openAdminOrderV2('${o.id}')"><strong>${fmt(o.total)}</strong></td><td onclick="openAdminOrderV2('${o.id}')"><span class="state-pill ${o.status==='delivered'?'is-on':o.status==='cancelled'?'is-off':'is-live'}"><i></i>${esc(dlStatusLabel(o.status))}</span></td><td onclick="openAdminOrderV2('${o.id}')">${o.created_at?new Date(o.created_at).toLocaleDateString():''}</td><td class="actions-cell"><button class="btn btn-ghost btn-sm" onclick="viewInvoice('${o.id}')">Invoice</button></td></tr>`).join('')}</tbody></table></div>`}`;
}
window.renderAdminOrders=renderAdminOrdersV2;
window.drawAdminOrders=drawAdminOrdersV2;
window.setAdminOrderFilter=function(t){adminOrderFilter=t;drawAdminOrdersV2(document.getElementById('admin-main'))};
function openAdminOrderV2(id){const o=(window._adminOrders||[]).find(x=>x.id===id);if(!o)return;const statuses=['pending','confirmed','processing','shipping','delivered','cancelled'];S.currentOrder=o;document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet order-modal-v2" onclick="event.stopPropagation()"><div class="modal-handle"></div><div class="invoice-toolbar"><div><div class="modal-title">${esc(o.order_number)}</div><div class="muted-note">${esc(o.full_name||'')} · ${esc(o.phone||'')}</div></div><div class="modal-actions"><button class="btn btn-ghost btn-sm" onclick="viewInvoice('${o.id}')">View invoice</button><button class="btn btn-primary btn-sm" onclick="printInvoice('${o.id}')">Print</button></div></div><div class="order-detail-grid"><div class="card order-detail-panel"><div class="panel-kicker">Customer</div><h3>${esc(o.full_name||'—')}</h3><div>${esc(o.phone||'')}</div>${o.phone2?`<div>${esc(o.phone2)}</div>`:''}<div>${esc(o.city||'')}${o.district?`, ${esc(o.district)}`:''}</div><div>${esc(o.full_address||'')}</div>${o.floor?`<div>Floor: ${esc(o.floor)}</div>`:''}</div><div class="card order-detail-panel"><div class="panel-kicker">Totals</div>${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}<div class="summary-row"><span>Subtotal</span><span>${fmt(o.subtotal)}</span></div>${o.discount_amount>0?`<div class="summary-row invoice-discount-row"><span>Discount${o.coupon_code?' · '+esc(o.coupon_code):''}</span><span>-${fmt(o.discount_amount)}</span></div>`:''}<div class="summary-row"><span>Delivery</span><span>${fmt(o.delivery_fee)}</span></div><div class="summary-row total"><span>Total</span><span>${fmt(o.total)}</span></div></div></div><div class="card form-card"><div class="fgroup"><label class="flabel">Order status</label><select class="fselect" id="adm-order-status">${statuses.map(s=>`<option value="${s}" ${s===o.status?'selected':''}>${s}</option>`).join('')}</select></div><button class="btn btn-primary" onclick="saveOrderStatus('${o.id}')">Save status</button></div></div></div>`}

/* ---------------- Contact voice notes ---------------- */
function dlRecorderMime(){return ['audio/mp4;codecs=mp4a.40.2','audio/mp4','audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'].find(x=>window.MediaRecorder?.isTypeSupported?.(x))||''}
function dlVoiceReset(){clearInterval(dlVoiceState.timer);if(dlVoiceState.recorder?.state==='recording'){try{dlVoiceState.recorder.stop()}catch{}}dlVoiceState={recorder:null,chunks:[],blob:null,mime:'',duration:0,timer:null,start:0};const timer=document.getElementById('voice-timer');if(timer)timer.textContent='00:00'}
async function startVoiceNote(){
  if(!window.isSecureContext){toast('Voice recording requires HTTPS (or localhost)');return}
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('Voice recording is not supported in this browser');return}
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    const mime=dlRecorderMime();let r;
    try{r=mime?new MediaRecorder(stream,{mimeType:mime}):new MediaRecorder(stream)}catch{r=new MediaRecorder(stream)}
    dlVoiceState={recorder:r,chunks:[],blob:null,mime:r.mimeType||mime||'audio/webm',duration:0,timer:null,start:Date.now()};
    r.ondataavailable=e=>{if(e.data?.size)dlVoiceState.chunks.push(e.data)};
    r.onerror=()=>{stream.getTracks().forEach(t=>t.stop());clearInterval(dlVoiceState.timer);toast('Recording failed. Please try again.')};
    r.onstop=()=>{stream.getTracks().forEach(t=>t.stop());clearInterval(dlVoiceState.timer);dlVoiceState.duration=Math.min(60,Math.round((Date.now()-dlVoiceState.start)/1000));dlVoiceState.blob=new Blob(dlVoiceState.chunks,{type:dlVoiceState.mime});const a=document.getElementById('voice-preview');if(a){if(a.dataset.objectUrl)URL.revokeObjectURL(a.dataset.objectUrl);const url=URL.createObjectURL(dlVoiceState.blob);a.dataset.objectUrl=url;a.src=url;a.classList.remove('hide');a.load()}const b=document.getElementById('voice-record-btn');if(b){b.disabled=false;b.classList.remove('recording');b.textContent='● Record again'}};
    r.start(250);const b=document.getElementById('voice-record-btn');if(b){b.classList.add('recording');b.textContent='■ Stop recording'}
    dlVoiceState.timer=setInterval(()=>{const n=Math.floor((Date.now()-dlVoiceState.start)/1000);const el=document.getElementById('voice-timer');if(el)el.textContent=`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;if(n>=60)stopVoiceNote()},250)
  }catch(e){toast(e?.name==='NotAllowedError'?'Allow microphone access in your browser settings':'Could not start recording. Check your microphone and try again.')}
}
function stopVoiceNote(){const r=dlVoiceState.recorder;if(r&&r.state!=='inactive'){clearInterval(dlVoiceState.timer);try{r.stop()}catch{}const b=document.getElementById('voice-record-btn');if(b){b.classList.remove('recording');b.textContent='Preparing recording…';b.disabled=true;setTimeout(()=>{if(b.isConnected)b.disabled=false},300)}}}
function clearVoiceNote(){const a=document.getElementById('voice-preview');if(a){a.pause();a.removeAttribute('src');if(a.dataset.objectUrl)URL.revokeObjectURL(a.dataset.objectUrl);delete a.dataset.objectUrl;a.load();a.classList.add('hide')}dlVoiceReset();const b=document.getElementById('voice-record-btn');if(b){b.disabled=false;b.classList.remove('recording');b.textContent='● Record voice note'}}
function toggleVoiceRecord(){dlVoiceState.recorder?.state==='recording'?stopVoiceNote():startVoiceNote()}
window.pContact=function(){const st=S.settings||{};return `<div class="page contact-v2-page" style="max-width:700px"><button class="back-link" onclick="goBack()">← Back</button><div class="hero contact-hero-v2"><div class="hero-in"><div class="hero-eyebrow">Support & customer care</div><h1 style="font-size:1.7rem">Contact us</h1><p>Send a message or record a voice note. We'll get back to you.</p></div></div><div class="card form-card contact-card-v2"><div id="ct-msg"></div><div class="frow2"><div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="ct-name"></div><div class="fgroup"><label class="flabel">Phone <span class="req">*</span></label><input class="finput" id="ct-phone" type="tel"></div></div><div class="fgroup"><label class="flabel">Message <span class="req">*</span></label><textarea class="ftextarea" id="ct-msg-txt" rows="5" placeholder="Tell us how we can help..."></textarea></div><div class="voice-recorder"><div><div class="voice-rec-title">Voice note</div><div class="voice-rec-sub">Optional · up to 60 seconds</div></div><div class="voice-rec-actions"><button type="button" class="btn btn-ghost btn-sm" id="voice-record-btn" onclick="toggleVoiceRecord()">● Record voice note</button><span class="voice-timer" id="voice-timer">00:00</span></div><audio id="voice-preview" class="voice-audio hide" controls></audio><button type="button" class="voice-clear" onclick="clearVoiceNote()">Clear recording</button></div><button class="btn btn-primary" id="ct-btn" onclick="sendContactV2()">Send message</button></div><div class="card contact-social-v2"><div class="footer-h">Find us online</div><div class="social-icon-row social-icon-row-large">${dlSocialsHTML(st)}</div></div></div>`}
async function sendContactV2(){
  if(dlVoiceState.recorder?.state==='recording'){toast('Stop the voice recording before sending');return}
  const name=document.getElementById('ct-name')?.value.trim();const phone=document.getElementById('ct-phone')?.value.trim();const msg=document.getElementById('ct-msg-txt')?.value.trim();
  if(!name||!phone||!msg){toast('Please fill in your name, phone and message');return}
  if(dlVoiceState.duration>60){toast('Voice note must be 60 seconds or less');return}
  const btn=document.getElementById('ct-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';
  let voicePath=null,voiceMime=null,voiceDuration=null;
  try{
    if(dlVoiceState.blob){const ext=dlVoiceState.mime.includes('ogg')?'ogg':dlVoiceState.mime.includes('mp4')?'m4a':'webm';voicePath=`${crypto.randomUUID()}.${ext}`;voiceMime=dlVoiceState.mime;voiceDuration=dlVoiceState.duration;const up=await sb.storage.from('contact-voice').upload(voicePath,dlVoiceState.blob,{contentType:dlVoiceState.mime,upsert:false});if(up.error)throw up.error}
    const {error}=await sb.from('contact_messages').insert({name,phone,message:msg,voice_path:voicePath,voice_mime:voiceMime,voice_duration_ms:voiceDuration?voiceDuration*1000:null});
    if(error)throw error;
    document.getElementById('ct-msg').innerHTML='<div class="alert alert-ok">Message sent — thank you. We will get back to you soon.</div>';
    document.getElementById('ct-name').value='';document.getElementById('ct-phone').value='';document.getElementById('ct-msg-txt').value='';clearVoiceNote();
  }catch(e){if(voicePath)await sb.storage.from('contact-voice').remove([voicePath]).catch(()=>{});document.getElementById('ct-msg').innerHTML=`<div class="alert alert-err">Could not send the message. ${esc(e.message||'Please try again.')}</div>`}
  btn.disabled=false;btn.textContent='Send message';
}

/* ---------------- Admin messages: voice playback ---------------- */
async function renderAdminMessagesV2(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Messages</div><div class="admin-kicker">Text and voice notes from customers</div></div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('contact_messages').select('*').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock(`Could not load messages: ${error.message||'database error'}`);return}
  window._adminMsgs=data||[];
  await Promise.all((window._adminMsgs||[]).filter(m=>m.voice_path).map(async m=>{await dlRefreshVoiceUrl(m)}));
  drawAdminMessagesV2(main);
}
function dlNormalizeVoicePath(value){
  if(!value)return '';
  let path=String(value).trim();
  try{
    if(/^https?:\/\//i.test(path)){
      const u=new URL(path);
      const marker='/storage/v1/object/';
      const at=u.pathname.indexOf(marker);
      if(at>=0){path=u.pathname.slice(at+marker.length).replace(/^(sign|signed|public|authenticated)\//,'');}
      else return path;
    }
  }catch{}
  path=path.replace(/^\/+/, '').replace(/^contact-voice\//,'');
  return decodeURIComponent(path);
}
async function dlRefreshVoiceUrl(message){
  try{
    const path=dlNormalizeVoicePath(message.voice_path);
    if(/^https?:\/\//i.test(path)){message.voice_url=path;message.voice_error=null;return}
    if(!path)throw new Error('No audio file path is saved for this message');
    const result=await sb.storage.from('contact-voice').createSignedUrl(path,3600);
    if(result.error)throw result.error;
    message.voice_url=result.data?.signedUrl||null;
    message.voice_error=message.voice_url?null:'Storage did not return a playable audio link';
  }catch(e){message.voice_url=null;message.voice_error=e?.message||'Could not create audio link'}
}
window.retryCustomerVoice=async function(id){
  const m=(window._adminMsgs||[]).find(x=>x.id===id);if(!m)return;
  await dlRefreshVoiceUrl(m);
  drawAdminMessagesV2(document.getElementById('admin-main'));
  if(!m.voice_url)toast('Audio link failed: '+(m.voice_error||'check Storage permissions'));
};
function drawAdminMessagesV2(main){
  const list=window._adminMsgs||[];
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Messages</div><div class="admin-kicker">${list.filter(x=>!x.is_read).length} unread · ${list.length} total</div></div><button class="btn btn-ghost btn-sm" onclick="renderAdminMessages(document.getElementById('admin-main'))">↻ Refresh</button></div>${!list.length?adminEmptyBlock('✉','No messages','Contact form submissions will appear here.'): `<div class="admin-message-list">${list.map(m=>`<div class="card admin-message-v2 ${m.is_read?'':'unread'}"><div class="message-row-top"><div><strong>${esc(m.name||'Customer')}</strong><div class="muted-note">${esc(m.phone||'No phone')} · ${m.created_at?new Date(m.created_at).toLocaleString():''}</div></div><span class="state-pill ${m.is_read?'is-off':'is-live'}"><i></i>${m.is_read?'read':'new'}</span></div><div class="message-body">${esc(m.message||'')}</div>${m.voice_path?`<div class="voice-message-box"><div class="voice-message-heading"><span>🎙 Voice note${m.voice_duration_ms?` · ${Math.round(m.voice_duration_ms/1000)}s`:''}</span>${m.voice_url?'<span class="voice-ready">Audio link ready</span>':'<span class="voice-unavailable">Audio link unavailable</span>'}</div>${m.voice_url?`<audio controls preload="metadata" playsinline src="${esc(m.voice_url)}" onerror="this.parentElement.classList.add('audio-failed')"></audio><a class="voice-open-link" href="${esc(m.voice_url)}" target="_blank" rel="noopener noreferrer">Open audio in new tab ↗</a>`:`<small class="voice-audio-error">${esc(m.voice_error||'Could not create a secure audio link. Check the contact-voice bucket and admin read policy.')}</small>`}<button type="button" class="btn btn-ghost btn-sm voice-retry-btn" onclick="retryCustomerVoice('${m.id}')">↻ Refresh audio link</button></div>`:''}<div class="message-actions"><button class="btn btn-ghost btn-sm" onclick="markMsgRead('${m.id}')">${m.is_read?'Mark unread':'Mark read'}</button><button class="btn btn-ghost btn-sm danger-outline" onclick="deleteMsgV2('${m.id}')">Delete</button></div></div>`).join('')}</div>`}`;
}
window.renderAdminMessages=renderAdminMessagesV2;window.drawAdminMessages=drawAdminMessagesV2;
window.markMsgRead=async function(id){const m=(window._adminMsgs||[]).find(x=>x.id===id);if(!m)return;const is_read=!m.is_read;const{error}=await sb.from('contact_messages').update({is_read}).eq('id',id);if(error){toast('Could not update message');return}m.is_read=is_read;drawAdminMessagesV2(document.getElementById('admin-main'))};
async function deleteMsgV2(id){const m=(window._adminMsgs||[]).find(x=>x.id===id);if(!m||!confirm('Delete this message?'))return;if(m.voice_path)await sb.storage.from('contact-voice').remove([m.voice_path]).catch(()=>{});const{error}=await sb.from('contact_messages').delete().eq('id',id);if(error){toast('Could not delete message');return}window._adminMsgs=window._adminMsgs.filter(x=>x.id!==id);drawAdminMessagesV2(document.getElementById('admin-main'))}

/* ---------------- Settings: brand, socials, pages, uploads ---------------- */
async function uploadStoreAsset(file,kind){
  if(!file)return null;
  if(!/^image\//.test(file.type)){toast('Please choose an image file');return null}
  if(file.size>5*1024*1024){toast('Image must be 5MB or less');return null}
  const ext=(file.type.split('/')[1]||'png').replace('jpeg','jpg');const path=`branding/${kind}-${Date.now()}-${Math.random().toString(36).slice(2,7)}.${ext}`;
  const {error}=await sb.storage.from('store-assets').upload(path,file,{contentType:file.type,upsert:false});
  if(error){toast(`Upload failed: ${error.message||'storage error'}`);return null}
  return sb.storage.from('store-assets').getPublicUrl(path).data.publicUrl;
}
async function renderAdminSettingsV2(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Store Settings</div><div class="admin-kicker">Brand, social links, page visibility and storefront behavior</div></div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('settings').select('*').eq('id',1).maybeSingle();if(error||!data){main.innerHTML=adminErrorBlock(`Could not load settings: ${error?.message||'settings row not found'}`);return}
  window._adminSettings=data;drawAdminSettingsV2(main);
}
function drawAdminSettingsV2(main){const s=window._adminSettings||{};const pages={offers:'Offers',wishlist:'Wishlist',orders:'Orders',points:'Points',account:'Account',contact:'Contact'};main.innerHTML=`<div class="settings-layout-v2">
  <div class="settings-col"><div class="card form-card"><div class="panel-kicker">Identity</div><div class="form-title">Store identity</div><div class="branding-upload"><div class="logo-preview">${s.logo_url?`<img src="${esc(s.logo_url)}" alt="">`:'<span>LOGO</span>'}</div><div><strong>Store logo</strong><div class="muted-note">Used in the header, browser tab fallback and invoices.</div><input id="st-logo-file" type="file" accept="image/*" class="finput" style="margin-top:8px;padding:8px"></div></div><div class="frow2"><div class="fgroup"><label class="flabel">Store name</label><input class="finput" id="st-name" value="${esc(s.store_name||'')}"></div><div class="fgroup"><label class="flabel">USD → LBP rate</label><input class="finput" id="st-rate" type="number" value="${s.currency_rate??0}"></div></div><div class="fgroup"><label class="flabel">Favicon / browser icon</label><div class="inline-upload"><div class="favicon-preview">${s.favicon_url?`<img src="${esc(s.favicon_url)}" alt="">`:'◈'}</div><input id="st-fav-file" type="file" accept="image/*" class="finput"></div></div><div class="fgroup"><label class="flabel">Hero title</label><input class="finput" id="st-hero" value="${esc(s.hero_title||'')}"></div><div class="fgroup"><label class="flabel">Hero subtitle</label><textarea class="ftextarea" id="st-sub">${esc(s.hero_subtitle||'')}</textarea></div><div class="fgroup"><label class="flabel">Announcement bar</label><input class="finput" id="st-announce" value="${esc(s.announcement||'')}"></div></div>
  <div class="card form-card"><div class="panel-kicker">Social presence</div><div class="form-title">Accounts shown on the website & invoice</div>${['instagram','facebook','tiktok'].map(t=>`<div class="social-setting"><div class="social-setting-icon">${dlIcon(t)}</div><div class="social-setting-fields"><label class="flabel">${t[0].toUpperCase()+t.slice(1)} URL</label><input class="finput" id="st-${t}-url" value="${esc(s[t+'_url']||'')}" placeholder="https://${t}.com/yourname"><label class="flabel small-gap">Username / page name</label><input class="finput" id="st-${t}-handle" value="${esc(s[t+'_handle']||dlSocialHandle(s[t+'_url'],t))}" placeholder="@yourname"></div></div>`).join('')}<div class="social-setting"><div class="social-setting-icon">${dlIcon('whatsapp')}</div><div class="social-setting-fields"><label class="flabel">WhatsApp number</label><input class="finput" id="st-wa" value="${esc(s.whatsapp_number||'')}"><label class="flabel small-gap">WhatsApp display name</label><input class="finput" id="st-wa-handle" value="${esc(s.whatsapp_handle||'')}" placeholder="WhatsApp / Your support number"></div></div><div class="fgroup"><label class="flabel">Contact email</label><input class="finput" id="st-email" type="email" value="${esc(s.contact_email||'')}"></div></div></div>
  <div class="settings-col"><div class="card form-card"><div class="panel-kicker">Navigation</div><div class="form-title">Page visibility</div><div class="muted-note" style="margin-bottom:12px">Turn pages on or off without deleting their content.</div>${Object.entries(pages).map(([key,label])=>{const on=(s.page_visibility||DL_PAGE_VIS_DEFAULT)[key]!==false;return `<div class="toggle-row"><div><div class="toggle-lbl">${label}</div><div class="toggle-sub">${on?'Visible to customers':'Hidden from customers'}</div></div><label class="switch"><input type="checkbox" class="page-vis-input" data-page="${key}" ${on?'checked':''}><span class="switch-track"></span></label></div>`}).join('')}</div><div class="card form-card"><div class="panel-kicker">Loyalty & cancellation</div><div class="form-title">Commerce settings</div><div class="frow2"><div class="fgroup"><label class="flabel">Points per $</label><input class="finput" id="st-pts" type="number" value="${s.points_per_dollar??0}"></div><div class="fgroup"><label class="flabel">Cancel fee ($)</label><input class="finput" id="st-fee" type="number" value="${s.cancel_fee??0}"></div></div><div class="fgroup"><label class="flabel">Free cancellation window (hours)</label><input class="finput" id="st-hours" type="number" value="${s.free_cancel_hours??24}"></div></div><div class="admin-fab-save"><button class="btn btn-primary" style="width:auto;padding:13px 26px" onclick="saveStoreSettingsV2()">Save everything</button></div><div class="card form-card" style="border-color:var(--danger)"><div class="panel-kicker" style="color:var(--danger)">Danger zone</div><div class="form-title">Delete all system data</div><div class="muted-note" style="margin-bottom:12px">Permanently removes customer accounts, orders, products, settings, messages, and uploaded files. Your current admin account remains.</div><button class="btn btn-danger" onclick="deleteAllSystemData()">Delete all data</button></div></div></div>`}
async function saveStoreSettingsV2(){
  const old=window._adminSettings||{};let logo=old.logo_url||null,fav=old.favicon_url||null;
  const lf=document.getElementById('st-logo-file')?.files?.[0];if(lf)logo=await uploadStoreAsset(lf,'logo');
  const ff=document.getElementById('st-fav-file')?.files?.[0];if(ff)fav=await uploadStoreAsset(ff,'favicon');
  const page_visibility={...DL_PAGE_VIS_DEFAULT};document.querySelectorAll('.page-vis-input').forEach(i=>page_visibility[i.dataset.page]=i.checked);
  const row={store_name:document.getElementById('st-name').value.trim(),currency_rate:parseFloat(document.getElementById('st-rate').value)||0,hero_title:document.getElementById('st-hero').value.trim(),hero_subtitle:document.getElementById('st-sub').value.trim(),announcement:document.getElementById('st-announce').value.trim(),points_per_dollar:parseFloat(document.getElementById('st-pts').value)||0,cancel_fee:parseFloat(document.getElementById('st-fee').value)||0,free_cancel_hours:parseInt(document.getElementById('st-hours').value)||24,whatsapp_number:document.getElementById('st-wa').value.trim(),whatsapp_handle:document.getElementById('st-wa-handle').value.trim()||null,contact_email:document.getElementById('st-email').value.trim(),instagram_url:document.getElementById('st-instagram-url').value.trim(),instagram_handle:document.getElementById('st-instagram-handle').value.trim()||null,facebook_url:document.getElementById('st-facebook-url').value.trim(),facebook_handle:document.getElementById('st-facebook-handle').value.trim()||null,tiktok_url:document.getElementById('st-tiktok-url').value.trim(),tiktok_handle:document.getElementById('st-tiktok-handle').value.trim()||null,logo_url:logo,favicon_url:fav,page_visibility};
  const{error}=await sb.from('settings').update(row).eq('id',1);if(error){toast(`Could not save settings: ${error.message||'database error'}`);return}S.settings={...S.settings,...row};window._adminSettings=S.settings;applySettingsToChrome();dlApplyPageVisibility();toast('Store settings saved');drawAdminSettingsV2(document.getElementById('admin-main'));
}
async function deleteAllSystemData(){
  if(!S.isAdmin||!S.session?.user?.id){toast('Admin access is required');return}
  if(!confirm('This permanently deletes all system data and other accounts, while keeping your current admin account. Continue?'))return;
  if(prompt('Type DELETE ALL DATA to confirm')!=='DELETE ALL DATA'){toast('Deletion cancelled');return}
  const{data,error}=await sb.rpc('delete_all_system_data');
  if(error||!data?.success){console.error(error);toast(`Could not delete system data: ${error?.message||'database error'}`);return}
  localStorage.removeItem('dl_cart');S.cart=[];S.wishlist=[];S.products=[];S.categories=[];S.settings=null;window._adminOrders=[];window._adminProducts=[];window._adminCats=[];
  toast('All system data deleted. Your admin account is still active.');
  resetHome();
}
window.renderAdminSettings=renderAdminSettingsV2;window.drawAdminSettings=drawAdminSettingsV2;

/* ---------------- User block enforcement / hidden pages ---------------- */
const _v2BaseLoadProfile=window.loadProfileAndWishlist;
window.loadProfileAndWishlist=async function(){await _v2BaseLoadProfile();const status=S.profile?.account_status||'enabled';if(status!=='enabled'){await sb.auth.signOut().catch(()=>{});S.session=null;S.profile=null;S.wishlist=[];S.deliveryLocation=null;S.isAdmin=false;toast(status==='banned'?'This account is blocked.':'This account is disabled.');resetHome();}}
const _v2BaseNav=window.nav;
window.nav=function(page,data=null,push=true){if(!dlPageVisible(page)){toast('This page is currently unavailable');return _v2BaseNav('home',null,push)}return _v2BaseNav(page,data,push)};

/* ---------------- Customer order page with invoice action ---------------- */
window.pOrders=async function(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your orders');return}
  app().innerHTML=`<div class="page"><div class="page-heading-v2"><div><div class="eyebrow-mini">Account</div><div class="section-title">My Orders</div></div><span class="heading-mark">▤</span></div><div class="spin spin-dark" style="margin:40px auto;display:block"></div></div>`;
  const{data}=await sb.from('orders').select('*, order_items(*)').eq('user_id',S.session.user.id).order('created_at',{ascending:false});const orders=data||[];
  if(!orders.length){app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button>${adminEmptyBlock('▤','No orders yet','Your orders will show up here.')}<div style="text-align:center"><button class="btn btn-primary btn-sm" onclick="resetHome()">Browse products</button></div></div>`;return}
  app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button><div class="page-heading-v2"><div><div class="eyebrow-mini">Account</div><div class="section-title">My Orders</div></div></div><div class="customer-order-list">${orders.map(o=>`<div class="card order-row-v2"><button class="order-row-main" onclick="nav('order-detail','${o.id}')"><div class="order-icon">▤</div><div class="order-row-copy"><strong>${esc(o.order_number)}</strong><span>${o.order_items?.length||0} item${(o.order_items?.length||0)!==1?'s':''} · ${fmt(o.total)}</span><small>${o.created_at?new Date(o.created_at).toLocaleDateString():''}</small></div><span class="state-pill ${o.status==='delivered'?'is-on':o.status==='cancelled'?'is-off':'is-live'}"><i></i>${esc(dlStatusLabel(o.status))}</span></button><button class="btn btn-ghost btn-sm order-invoice-btn" onclick="printCustomerInvoice('${o.id}')">Print invoice</button></div>`).join('')}</div></div>`;
  S.currentOrder=orders[0];window._customerOrders=orders;
}
function printCustomerInvoice(id){const o=(window._customerOrders||[]).find(x=>x.id===id);if(!o){toast('Invoice not found');return}dlOpenPrint(dlPrintOneDocument(o))}
window.pOrderDetail=async function(){
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data:o}=await sb.from('orders').select('*, order_items(*)').eq('id',S.data).eq('user_id',S.session?.user?.id||'00000000-0000-0000-0000-000000000000').maybeSingle();if(!o){nav('orders');return}S.currentOrder=o;
  const steps=['pending','confirmed','processing','shipping','delivered'];const cur=steps.indexOf(o.status);const cancelled=o.status==='cancelled';const canCancel=!cancelled&&o.status!=='delivered';
  app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button><div class="section-head"><div><div class="eyebrow-mini">Order</div><div class="section-title">${esc(o.order_number)}</div></div><span class="state-pill ${o.status==='delivered'?'is-on':o.status==='cancelled'?'is-off':'is-live'}"><i></i>${esc(dlStatusLabel(o.status))}</span></div>${!cancelled?`<div class="card tracking-card-v2"><div class="track-steps">${steps.map((s,i)=>`<div class="track-step"><div class="track-dot ${i<=cur?'done':''}">${i<=cur?'✓':i+1}</div><div class="track-lbl">${s}</div></div>`).join('')}</div></div>`:`<div class="alert alert-err">This order was cancelled.${o.cancel_reason?' Reason: '+esc(o.cancel_reason):''}</div>`}<div class="card form-card order-summary-v2"><div class="invoice-toolbar"><div class="form-title">Order summary</div><button class="btn btn-primary btn-sm" onclick="printCustomerInvoice('${o.id}')">Print invoice</button></div>${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)}${i.is_bundle?' ('+esc(i.bundle_label)+')':''} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}<div class="summary-row"><span>Subtotal</span><span>${fmt(o.subtotal)}</span></div>${o.discount_amount>0?`<div class="summary-row invoice-discount-row"><span>Discount${o.coupon_code?' · '+esc(o.coupon_code):''}</span><span>-${fmt(o.discount_amount)}</span></div>`:''}<div class="summary-row"><span>Delivery</span><span>${fmt(o.delivery_fee)}</span></div><div class="summary-row total"><span>Total</span><span>${fmt(o.total)}</span></div></div><div class="card form-card"><div class="form-title">Delivery details</div><div class="detail-list-v2"><div><span>Name</span><strong>${esc(o.full_name)}</strong></div><div><span>Phone</span><strong>${esc(o.phone)}</strong></div><div><span>Address</span><strong>${esc(o.city||'')}${o.district?`, ${esc(o.district)}`:''} — ${esc(o.full_address||'')}</strong></div>${o.floor?`<div><span>Floor</span><strong>${esc(o.floor)}</strong></div>`:''}</div></div>${canCancel?`<button class="btn btn-danger" onclick="cancelOrder('${esc(o.id)}','${esc(o.created_at)}')">Cancel order</button>`:''}</div>`;
}

/* ---------------- Chrome / animations ---------------- */
const _v2BaseApply=window.applySettingsToChrome;
window.applySettingsToChrome=function(){_v2BaseApply();dlRefreshBrandChrome();dlApplyPageVisibility();
  const st=S.settings||{};const soc=dlSocialsHTML(st);const f=document.getElementById('footer-soc');const d=document.getElementById('drawer-soc');if(f)f.innerHTML=soc;if(d)d.innerHTML=soc;
  const wa=st.whatsapp_number?`https://wa.me/${st.whatsapp_number.replace(/\D/g,'')}?text=${encodeURIComponent('مرحبا، بدي استفسر عن منتجاتكم.')}`:'';if(wa)document.querySelectorAll('[data-whatsapp-link]').forEach(a=>a.href=wa)
}
