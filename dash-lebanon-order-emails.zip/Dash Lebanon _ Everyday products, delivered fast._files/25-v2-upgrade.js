/* =========================================================
   DASH LEBANON — V2 UX / INVOICES / BRAND / PAGES / USERS / VOICE
   Additive upgrade. Keeps the existing palette and Supabase app.
========================================================= */

const DL_PAGE_VIS_DEFAULT={home:true,offers:true,wishlist:true,orders:true,points:true,account:true,contact:true};
const DL_SOCIALS=['instagram','facebook','tiktok','whatsapp'];
let dlVoiceState={recorder:null,chunks:[],blob:null,mime:'',duration:0,timer:null,start:0};

function dlPageVisible(key){
  if(key==='home'||key==='cart'||key==='checkout'||key==='success'||key==='product'||key==='order-detail'||key==='admin'||key==='admin-login') return true;
  const v=S.settings?.page_visibility||{};
  return v[key]!==false;
}

function dlSocialHandle(url,type){
  if(!url)return '';
  try{
    const u=new URL(url);
    let parts=u.pathname.split('/').filter(Boolean);
    if(type==='tiktok' && parts[0]?.startsWith('@')) return parts[0];
    if(type==='instagram') return parts[0]?`@${parts[0].replace(/^@/,'')}`:'';
    if(type==='facebook') return parts[0]?`/${parts.join('/')}`:'';
    return parts[parts.length-1]||'';
  }catch{return ''}
}
function dlSocialLabel(st,type){
  const key=type+'_handle';
  return (st&&st[key]&&st[key].trim()) || dlSocialHandle(st?.[type+'_url'],type) || '';
}
function dlIcon(type){
  const common='viewBox="0 0 24 24" aria-hidden="true" focusable="false"';
  const paths={
    instagram:`<svg ${common} fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4.2"/><circle cx="17.3" cy="6.8" r="1" fill="currentColor" stroke="none"/></svg>`,
    facebook:`<svg ${common} fill="currentColor"><path d="M13.5 21v-8h2.7l.4-3h-3.1V8.1c0-.87.24-1.46 1.5-1.46h1.6V3.98c-.28-.04-1.24-.12-2.36-.12-2.34 0-3.95 1.43-3.95 4.06V10H7.6v3h2.7v8h3.2z"/></svg>`,
    tiktok:`<svg ${common} fill="currentColor"><path d="M15.3 3.2c.54 1.92 1.7 3.02 3.52 3.48v3.18c-1.35-.08-2.45-.45-3.52-1.07v6.4a4.9 4.9 0 1 1-4.9-4.9c.3 0 .6.03.9.08v3.28a1.95 1.95 0 1 0 1.82 1.94V3.2h2.18z"/></svg>`,
    whatsapp:`<svg ${common} fill="currentColor"><path d="M12 2.3a9.7 9.7 0 0 0-8.4 14.55L2.7 21.7l4.96-.9A9.7 9.7 0 1 0 12 2.3zm0 17.6a7.9 7.9 0 0 1-4.02-1.1l-.29-.17-2.94.53.55-2.86-.19-.3A7.9 7.9 0 1 1 12 19.9zm4.38-5.95c-.24-.12-1.43-.7-1.65-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1-.37-1.9-1.18-.7-.62-1.18-1.38-1.32-1.61-.14-.24-.01-.37.1-.49.1-.1.24-.27.36-.41.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.31-.74-1.79-.19-.47-.39-.41-.54-.42h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2 0 1.18.86 2.32.98 2.48.12.16 1.68 2.56 4.07 3.59.57.25 1.01.4 1.35.51.57.18 1.09.16 1.5.1.46-.07 1.43-.58 1.63-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28z"/></svg>`
  };
  return paths[type]||'';
}
function dlSocialsHTML(st, opts={}){
  const cls=opts.className||'social-icon-row';
  const only=opts.only||DL_SOCIALS;
  return only.map(type=>{
    const url=type==='whatsapp'
      ? ((st?.whatsapp_number||'').replace(/\D/g,'')?`https://wa.me/${st.whatsapp_number.replace(/\D/g,'')}?text=${encodeURIComponent('مرحبا، بدي استفسر عن منتجاتكم.')}`:(st?.whatsapp_link||'').trim())
      : (st?.[type+'_url']||'');
    if(!url)return '';
    return `<a class="social-icon" href="${esc(url)}" target="_blank" rel="noopener noreferrer" aria-label="${type}"><span>${dlIcon(type)}</span><span class="social-icon-name">${esc(dlSocialLabel(st,type))}</span></a>`;
  }).join('');
}
function dlBrandMarkup(st,compact=false){
  const name=esc(st?.store_name||'Dash Lebanon');
  return st?.logo_url
    ? `<img class="brand-logo" src="${esc(st.logo_url)}" alt="${name}" onerror="this.classList.add('broken')"><span class="brand-word">${name}</span>`
    : `<span class="dot"></span><span class="brand-word">${name}</span>`;
}
function dlRefreshBrandChrome(){
  const st=S.settings||{};
  document.querySelectorAll('.brand').forEach(el=>el.innerHTML=dlBrandMarkup(st));
  const fb=document.getElementById('footer-brand');
  if(fb)fb.innerHTML=dlBrandMarkup(st,true);
  let fav=document.getElementById('site-favicon');
  if(!fav){fav=document.createElement('link');fav.id='site-favicon';fav.rel='icon';document.head.appendChild(fav)}
  fav.href=st.favicon_url||st.logo_url||'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="%232952e3"/><circle cx="32" cy="32" r="11" fill="%23f5a623"/></svg>';
  const themeMeta=document.querySelector('meta[name="theme-color"]');if(themeMeta&&st.primary_color)themeMeta.content=themeMeta.content;
}
function dlApplyPageVisibility(){
  const mapping={offers:'offers',wishlist:'wishlist',orders:'orders',contact:'contact'};
  document.querySelectorAll('[data-page-gate]').forEach(el=>el.classList.toggle('hide',!dlPageVisible(el.dataset.pageGate)));
  Object.entries(mapping).forEach(([k])=>{
    document.querySelectorAll(`[data-nav="${k}"]`).forEach(el=>el.classList.toggle('hide',!dlPageVisible(k)));
  });
}

function dlAdminNav(id,label,icon){return `<button class="admin-nav-btn ${S.adminSection===id?'on':''}" onclick="navAdminSection('${id}')"><span class="admin-nav-icon">${icon}</span><span>${label}</span></button>`}
function dlAdminShell(){
  return `<div class="admin-shell v2-admin-shell">
    <aside class="admin-sidebar v2-admin-sidebar">
      <div class="admin-brand-panel"><div class="admin-brand-kicker">Control center</div><div class="admin-brand-title">${esc(S.settings?.store_name||'Store')} <span>Workspace</span></div></div>
      <div class="admin-sidebar-title">Manage</div>
      ${dlAdminNav('overview','Overview','◈')}
      ${dlAdminNav('orders','Orders','▤')}
      ${dlAdminNav('products','Products','◇')}
      ${dlAdminNav('categories','Categories','⌘')}
      ${dlAdminNav('reviews','Reviews','★')}
      ${dlAdminNav('messages','Messages','✉')}
      ${dlAdminNav('users','Customers','◯')}
      <div class="admin-sidebar-title" style="margin-top:14px">Growth</div>
      ${dlAdminNav('coupons','Coupons & Offers','%')}
      <div class="admin-sidebar-title" style="margin-top:14px">Configuration</div>
      ${dlAdminNav('settings','Store Settings','⚙')}
      ${dlAdminNav('ai','AI Assistant','✦')}
      <div class="admin-sidebar-status"><span class="status-dot"></span> Secure admin session</div>
    </aside>
    <main class="admin-main v2-admin-main" id="admin-main">${skeletonAdminBlock()}</main>
  </div>`;
}
window.pAdmin=function(){app().innerHTML=dlAdminShell();loadAdminSection(S.adminSection||'overview')};

const _v2BaseLoad=window.loadAdminSection;
window.loadAdminSection=async function(id){
  const main=document.getElementById('admin-main');
  if(id==='users')return renderAdminUsers(main);
  if(id==='orders')return renderAdminOrdersV2(main);
  if(id==='messages')return renderAdminMessagesV2(main);
  if(id==='settings')return renderAdminSettingsV2(main);
  return _v2BaseLoad(id);
};

async function renderAdminUsers(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Customers</div><div class="admin-kicker">Account access and customer overview</div></div></div><div class="admin-card-grid"><div class="card admin-command"><div class="admin-command-icon">◯</div><div><strong>Account controls</strong><div class="muted-note">Disable or re-enable an account from here. Password changes use a secure reset email.</div></div></div></div>${skeletonAdminBlock()}`;
  const {data,error}=await sb.rpc('admin_list_users');
  if(error){main.innerHTML=adminErrorBlock(`Could not load users: ${error.message||'database error'}`);return}
  window._adminUsers=data||[];
  drawAdminUsers(main);
}
function drawAdminUsers(main){
  const list=window._adminUsers||[];
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Customers</div><div class="admin-kicker">${list.length} account${list.length===1?'':'s'} in your store</div></div></div>
  ${!list.length?adminEmptyBlock('◯','No users','Registered customers will appear here.'): `<div class="card admin-table-wrap v2-table-card"><table class="admin-table v2-table"><thead><tr><th>Customer</th><th>Contact</th><th>Role</th><th>Access</th><th>Joined</th><th></th></tr></thead><tbody>${list.map(u=>{
    const status=u.account_status||'enabled';
    return `<tr><td><div class="user-cell"><div class="user-avatar">${esc((u.first_name||u.email||'U').slice(0,1).toUpperCase())}</div><div><strong>${esc([u.first_name,u.last_name].filter(Boolean).join(' ')||u.username||'Unnamed')}</strong><div class="muted-note">@${esc(u.username||'—')}</div></div></div></td><td><div>${esc(u.email||'—')}</div><div class="muted-note">${esc(u.phone||'')}</div></td><td><span class="status-badge ${u.role==='admin'?'st-admin':'st-user'}">${u.role==='admin'?'Admin':'Customer'}</span></td><td><span class="state-pill ${status==='enabled'?'is-on':status==='disabled'?'is-off':'is-ban'}"><i></i>${status}</span></td><td>${u.created_at?new Date(u.created_at).toLocaleDateString():'—'}</td><td class="actions-cell"><button class="btn btn-ghost btn-sm" onclick="adminToggleUser('${u.id}','${status==='enabled'?'disabled':'enabled'}')">${status==='enabled'?'Disable':'Enable'}</button>${status!=='banned'?`<button class="btn btn-ghost btn-sm" onclick="adminToggleUser('${u.id}','banned')">Ban</button>`:`<button class="btn btn-ghost btn-sm" onclick="adminToggleUser('${u.id}','enabled')">Unban</button>`}<button class="btn btn-ghost btn-sm" onclick="adminSendReset('${esc(u.email||'')}')">Reset password</button></td></tr>`;
  }).join('')}</tbody></table></div>`}`;
}
async function adminToggleUser(id,status){
  const {data,error}=await sb.rpc('admin_set_account_status',{p_user_id:id,p_status:status});
  if(error){toast(`Could not update account: ${error.message||'error'}`);return}
  const u=(window._adminUsers||[]).find(x=>x.id===id);if(u)u.account_status=status;
  drawAdminUsers(document.getElementById('admin-main'));toast(status==='enabled'?'Account enabled':'Account disabled');
}
async function adminSendReset(email){
  if(!email){toast('This user has no email address available');return}
  if(!confirm(`Send a password reset link to ${email}?`))return;
  const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});
  if(error){toast(`Could not send reset: ${error.message}`);return}
  toast('Password reset email sent');
}

/* ---------------- Orders / invoices ---------------- */
function dlStatusLabel(s){return s?String(s).replace(/_/g,' '):'—'}
function dlInvoice(order, opts={}){
  const st=S.settings||{};
  const items=order.order_items||[];
  const hasDiscount=parseFloat(order.discount_amount||0)>0;
  const social=DL_SOCIALS.map(t=>{
    const url=t==='whatsapp'?(st.whatsapp_link||((st.whatsapp_number||'').replace(/\D/g,'')?`https://wa.me/${st.whatsapp_number.replace(/\D/g,'')}`:'')):(st[t+'_url']||'');
    if(!url)return '';
    return `<a href="${esc(url)}">${dlIcon(t)}<span>${esc(dlSocialLabel(st,t))}</span></a>`;
  }).join('');
  return `<section class="invoice ${opts.preview?'invoice-preview':''} ${opts.compact?'invoice-compact':''}
    ><div class="invoice-top"><div class="invoice-brand">${st.logo_url?`<img src="${esc(st.logo_url)}" alt="">`:''}<div><div class="invoice-store">${esc(st.store_name||'Store')}</div><div class="invoice-tag">${esc(st.hero_subtitle||'')}</div></div></div><div class="invoice-meta"><b>INVOICE</b><span>${esc(order.order_number||order.id||'')}</span><span>${order.created_at?new Date(order.created_at).toLocaleString():''}</span></div></div>
    <div class="invoice-grid"><div class="invoice-box"><div class="invoice-label">BILL TO</div><strong>${esc(order.full_name||'—')}</strong><div>${esc(order.phone||'')}</div>${order.phone2?`<div>${esc(order.phone2)}</div>`:''}<div>${esc(order.city||'')}${order.district?`, ${esc(order.district)}`:''}</div><div>${esc(order.full_address||'')}</div>${order.floor?`<div>Floor: ${esc(order.floor)}</div>`:''}</div><div class="invoice-box"><div class="invoice-label">ORDER</div><div>Status <strong>${esc(dlStatusLabel(order.status))}</strong></div>${order.coupon_code?`<div>Coupon <strong>${esc(order.coupon_code)}</strong></div>`:''}${order.notes?`<div>Notes: ${esc(order.notes)}</div>`:''}</div></div>
    <table class="invoice-items"><thead><tr><th>Product</th><th>Qty</th><th>Unit</th><th>Total</th></tr></thead><tbody>${items.map(i=>`<tr><td><strong>${esc(i.product_name||'Item')}</strong>${i.is_bundle&&i.bundle_label?`<small>${esc(i.bundle_label)}</small>`:''}</td><td>${i.quantity||0}</td><td>${fmt(i.unit_price)}</td><td>${fmt((parseFloat(i.unit_price)||0)*(i.quantity||0))}</td></tr>`).join('')}</tbody></table>
    <div class="invoice-summary"><div><span>Subtotal</span><b>${fmt(order.subtotal)}</b></div>${hasDiscount?`<div class="invoice-discount"><span>Discount${order.coupon_code?` · ${esc(order.coupon_code)}`:''}</span><b>-${fmt(order.discount_amount)}</b></div>`:''}<div><span>Delivery</span><b>${fmt(order.delivery_fee)}</b></div><div class="invoice-grand"><span>Total</span><b>${fmt(order.total)}</b></div></div>
    <div class="invoice-foot"><div><strong>Thank you for your order.</strong><span>Cash on delivery · Lebanon</span></div><div class="invoice-socials">${social}</div></div>
  </section>`;
}
function dlPrintDocument(invoices){
  const pages=[];
  for(let i=0;i<invoices.length;i+=2){pages.push(`<div class="print-page">${dlInvoice(invoices[i],{compact:true})}${invoices[i+1]?dlInvoice(invoices[i+1],{compact:true}):'<div class="invoice-spacer"></div>'}</div>`)}
  return `<!doctype html><html><head><meta charset="utf-8"><title>Invoices</title><style>${dlPrintCSS()}</style></head><body>${pages.join('')}</body></html>`;
}
function dlPrintOneDocument(order){return `<!doctype html><html><head><meta charset="utf-8"><title>Invoice ${esc(order.order_number||'')}</title><style>${dlPrintCSS()} .print-page.one{grid-template-rows:1fr}.print-page.one .invoice{height:100%}</style></head><body><div class="print-page one">${dlInvoice(order,{compact:false})}</div></body></html>`}
function dlPrintCSS(){return `
@page{size:A4;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}.print-page{width:210mm;height:297mm;padding:7mm;display:grid;grid-template-rows:1fr 1fr;overflow:hidden;page-break-after:always}.invoice{height:calc((297mm - 14mm)/2);border:1px solid #cfd5df;padding:7mm;display:flex;flex-direction:column;overflow:hidden;position:relative;background:#fff}.invoice-spacer{height:100%}.invoice-top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;border-bottom:1px solid #e3e7ef;padding-bottom:5mm}.invoice-brand{display:flex;align-items:center;gap:10px;min-width:0}.invoice-brand img{width:13mm;height:13mm;object-fit:contain;border-radius:3mm}.invoice-store{font-size:17pt;font-weight:800;letter-spacing:-.3px}.invoice-tag{font-size:8pt;color:#6a7382;margin-top:2px;max-width:85mm}.invoice-meta{display:flex;flex-direction:column;text-align:right;gap:2px;font-size:8pt;color:#6a7382}.invoice-meta b{font-size:11pt;color:#111}.invoice-grid{display:grid;grid-template-columns:1.3fr 1fr;gap:4mm;margin:4mm 0}.invoice-box{border:1px solid #e1e5ed;border-radius:3mm;padding:3.4mm;font-size:8pt;line-height:1.55}.invoice-label{font-size:6.5pt;font-weight:800;letter-spacing:1px;color:#788294;margin-bottom:1.5mm}.invoice-items{width:100%;border-collapse:collapse;font-size:7.5pt}.invoice-items th{text-transform:uppercase;font-size:6.5pt;color:#6d7685;letter-spacing:.5px;text-align:left;border-bottom:1px solid #d9dee7;padding:2.5mm 1.5mm}.invoice-items td{padding:2.6mm 1.5mm;border-bottom:1px solid #edf0f4;vertical-align:top}.invoice-items th:not(:first-child),.invoice-items td:not(:first-child){text-align:right}.invoice-items small{display:block;color:#7b8492;margin-top:1px}.invoice-summary{margin-left:auto;width:62mm;margin-top:4mm;font-size:8pt}.invoice-summary>div{display:flex;justify-content:space-between;padding:1.7mm 0}.invoice-discount{color:#16824d}.invoice-grand{font-size:11pt;border-top:1.5px solid #111;margin-top:1mm;padding-top:3mm!important}.invoice-foot{margin-top:auto;border-top:1px solid #e3e7ef;padding-top:3mm;display:flex;justify-content:space-between;align-items:flex-end;gap:12mm;font-size:7pt;color:#6d7682}.invoice-foot strong{display:block;color:#111;font-size:8pt}.invoice-foot span{display:block;margin-top:1px}.invoice-socials{display:flex;gap:3mm;align-items:center;flex-wrap:wrap;justify-content:flex-end}.invoice-socials a{display:flex;align-items:center;gap:1.5mm;color:#222;text-decoration:none}.invoice-socials svg{width:4mm;height:4mm}.invoice-socials span{font-size:6.5pt}.invoice-compact{padding:5.5mm}.invoice-compact .invoice-top{padding-bottom:3.5mm}.invoice-compact .invoice-brand img{width:9mm;height:9mm}.invoice-compact .invoice-store{font-size:12pt}.invoice-compact .invoice-tag{font-size:6.5pt}.invoice-compact .invoice-grid{margin:3mm 0;gap:3mm}.invoice-compact .invoice-box{padding:2.4mm;font-size:6.6pt}.invoice-compact .invoice-items{font-size:6.3pt}.invoice-compact .invoice-items th{font-size:5.5pt;padding:1.6mm 1mm}.invoice-compact .invoice-items td{padding:1.8mm 1mm}.invoice-compact .invoice-summary{font-size:6.7pt;width:48mm;margin-top:2.5mm}.invoice-compact .invoice-summary>div{padding:1mm 0}.invoice-compact .invoice-grand{font-size:8.5pt;padding-top:2mm!important}.invoice-compact .invoice-foot{padding-top:2mm;font-size:5.8pt}.invoice-compact .invoice-foot strong{font-size:6.5pt}.invoice-compact .invoice-socials{gap:2mm}.invoice-compact .invoice-socials svg{width:3mm;height:3mm}.invoice-compact .invoice-socials span{font-size:5.5pt}`}
function dlOpenPrint(html){
  // Open synchronously from the button click so popup blockers are less likely to interfere.
  let w=null;
  try{w=window.open('','_blank')}catch{}
  if(w){
    try{
      w.addEventListener('load',()=>setTimeout(()=>{try{w.focus();w.print()}catch(e){console.error('Print failed',e);}},350),{once:true});
      w.document.open();w.document.write(html);w.document.close();w.opener=null;
      return true;
    }catch(e){try{w.close()}catch{}console.error('Print window failed',e)}
  }
  // Fallback when the browser blocks new windows: print from a temporary hidden frame.
  try{
    const frame=document.createElement('iframe');
    frame.setAttribute('title','Invoice print preview');
    frame.setAttribute('aria-hidden','true');
    frame.style.cssText='position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;opacity:0;pointer-events:none';
    frame.onload=()=>setTimeout(()=>{try{frame.contentWindow.focus();frame.contentWindow.print()}catch(e){console.error('Frame print failed',e);toast('Printing failed. Try Ctrl+P or allow pop-ups for this site')}},350);
    document.body.appendChild(frame);
    frame.srcdoc=html;
    return true;
  }catch(e){console.error('Print setup failed',e);toast('Could not open print preview. Allow pop-ups or press Ctrl+P.');return false}
}
function viewInvoice(id){const o=(window._adminOrders||[]).find(x=>x.id===id)||S.currentOrder;if(!o)return;document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet invoice-modal" onclick="event.stopPropagation()"><div class="modal-handle"></div><div class="invoice-toolbar"><div><div class="modal-title">Invoice ${esc(o.order_number||'')}</div><div class="muted-note">Print-ready A4 invoice preview</div></div><button class="btn btn-primary btn-sm" onclick="printInvoice('${o.id}')">Print invoice</button></div><div class="invoice-preview-wrap">${dlInvoice(o,{preview:true})}</div></div></div>`}
function printInvoice(id){const o=(window._adminOrders||[]).find(x=>x.id===id)||S.currentOrder;if(!o){toast('Invoice not found');return}dlOpenPrint(dlPrintOneDocument(o))}
function printAllInvoices(){const list=window._adminOrders||[];if(!list.length){toast('No orders to print');return}dlOpenPrint(dlPrintDocument(list))}

async function renderAdminOrdersV2(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Orders</div><div class="admin-kicker">Orders, invoices, delivery details</div></div><div class="admin-head-actions"><button class="btn btn-primary btn-sm" onclick="printAllInvoices()">▣ Print all invoices</button></div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('orders').select('*, order_items(*)').order('created_at',{ascending:false}).limit(500);
  if(error){main.innerHTML=adminErrorBlock(`Could not load orders: ${error.message||'database error'}`);return}
  window._adminOrders=data||[];drawAdminOrdersV2(main);
}
function drawAdminOrdersV2(main){
  const list=(window._adminOrders||[]).filter(o=>adminOrderFilter==='all'||o.status===adminOrderFilter);
  const tabs=['all','pending','confirmed','processing','shipping','delivered','cancelled'];
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Orders</div><div class="admin-kicker">${list.length} visible order${list.length===1?'':'s'}</div></div><div class="admin-head-actions"><button class="btn btn-primary btn-sm" onclick="printAllInvoices()">▣ Print all invoices</button></div></div>
  <div class="admin-tabs v2-admin-tabs">${tabs.map(t=>`<button class="admin-tab ${adminOrderFilter===t?'on':''}" onclick="setAdminOrderFilter('${t}')">${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div>
  ${!list.length?adminEmptyBlock('▤','No orders','No orders match this filter yet.'): `<div class="card admin-table-wrap v2-table-card"><table class="admin-table v2-table"><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Date</th><th></th></tr></thead><tbody>${list.map(o=>`<tr class="clickable"><td onclick="openAdminOrderV2('${o.id}')"><span class="mono">${esc(o.order_number)}</span></td><td onclick="openAdminOrderV2('${o.id}')"><div><strong>${esc(o.full_name||'—')}</strong></div><div class="muted-note">${esc(o.phone||'')}</div></td><td onclick="openAdminOrderV2('${o.id}')">${o.order_items?.length||0}</td><td onclick="openAdminOrderV2('${o.id}')"><strong>${fmt(o.total)}</strong></td><td onclick="openAdminOrderV2('${o.id}')"><span class="state-pill ${o.status==='delivered'?'is-on':o.status==='cancelled'?'is-off':'is-live'}"><i></i>${esc(dlStatusLabel(o.status))}</span></td><td onclick="openAdminOrderV2('${o.id}')">${o.created_at?new Date(o.created_at).toLocaleDateString():''}</td><td class="actions-cell"><button class="btn btn-ghost btn-sm" onclick="viewInvoice('${o.id}')">Invoice</button></td></tr>`).join('')}</tbody></table></div>`}`;
}
window.renderAdminOrders=renderAdminOrdersV2;
window.drawAdminOrders=drawAdminOrdersV2;
window.setAdminOrderFilter=function(t){adminOrderFilter=t;drawAdminOrdersV2(document.getElementById('admin-main'))};
function openAdminOrderV2(id){const o=(window._adminOrders||[]).find(x=>x.id===id);if(!o)return;const statuses=['pending','confirmed','processing','shipping','delivered','cancelled'];S.currentOrder=o;document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet order-modal-v2" onclick="event.stopPropagation()"><div class="modal-handle"></div><div class="invoice-toolbar"><div><div class="modal-title">${esc(o.order_number)}</div><div class="muted-note">${esc(o.full_name||'')} · ${esc(o.phone||'')}</div></div><div class="modal-actions"><button class="btn btn-ghost btn-sm" onclick="viewInvoice('${o.id}')">View invoice</button><button class="btn btn-primary btn-sm" onclick="printInvoice('${o.id}')">Print</button></div></div><div class="order-detail-grid"><div class="card order-detail-panel"><div class="panel-kicker">Customer</div><h3>${esc(o.full_name||'—')}</h3><div>${esc(o.phone||'')}</div>${o.phone2?`<div>${esc(o.phone2)}</div>`:''}<div>${esc(o.city||'')}${o.district?`, ${esc(o.district)}`:''}</div><div>${esc(o.full_address||'')}</div>${o.floor?`<div>Floor: ${esc(o.floor)}</div>`:''}</div><div class="card order-detail-panel"><div class="panel-kicker">Totals</div>${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}<div class="summary-row"><span>Subtotal</span><span>${fmt(o.subtotal)}</span></div>${o.discount_amount>0?`<div class="summary-row invoice-discount-row"><span>Discount${o.coupon_code?' · '+esc(o.coupon_code):''}</span><span>-${fmt(o.discount_amount)}</span></div>`:''}<div class="summary-row"><span>Delivery</span><span>${fmt(o.delivery_fee)}</span></div><div class="summary-row total"><span>Total</span><span>${fmt(o.total)}</span></div></div></div><div class="card form-card"><div class="fgroup"><label class="flabel">Order status</label><select class="fselect" id="adm-order-status">${statuses.map(s=>`<option value="${s}" ${s===o.status?'selected':''}>${s}</option>`).join('')}</select></div><button class="btn btn-primary" onclick="saveOrderStatus('${o.id}')">Save status</button></div></div></div>`}

/* ---------------- Contact voice notes ---------------- */
function dlRecorderMime(){return ['audio/mp4;codecs=mp4a.40.2','audio/mp4','audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'].find(x=>window.MediaRecorder?.isTypeSupported?.(x))||''}
function dlVoiceReset(){clearInterval(dlVoiceState.timer);if(dlVoiceState.recorder?.state==='recording'){try{dlVoiceState.recorder.stop()}catch{}}dlVoiceState={recorder:null,chunks:[],blob:null,mime:'',duration:0,timer:null,start:0};const timer=document.getElementById('voice-timer');if(timer)timer.textContent='00:00'}
async function startVoiceNote(){
  if(!window.isSecureContext){toast('Voice recording requires HTTPS (or localhost)');return}
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('Voice recording is not supported in this browser');return}
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    const mime=dlRecorderMime();let r;
    try{r=mime?new MediaRecorder(stream,{mimeType:mime}):new MediaRecorder(stream)}catch{r=new MediaRecorder(stream)}
    dlVoiceState={recorder:r,chunks:[],blob:null,mime:r.mimeType||mime||'audio/webm',duration:0,timer:null,start:Date.now()};
    r.ondataavailable=e=>{if(e.data?.size)dlVoiceState.chunks.push(e.data)};
    r.onerror=()=>{stream.getTracks().forEach(t=>t.stop());clearInterval(dlVoiceState.timer);toast('Recording failed. Please try again.')};
    r.onstop=()=>{stream.getTracks().forEach(t=>t.stop());clearInterval(dlVoiceState.timer);dlVoiceState.duration=Math.min(60,Math.round((Date.now()-dlVoiceState.start)/1000));dlVoiceState.blob=new Blob(dlVoiceState.chunks,{type:dlVoiceState.mime});const a=document.getElementById('voice-preview');if(a){if(a.dataset.objectUrl)URL.revokeObjectURL(a.dataset.objectUrl);const url=URL.createObjectURL(dlVoiceState.blob);a.dataset.objectUrl=url;a.src=url;a.classList.remove('hide');a.load()}const b=document.getElementById('voice-record-btn');if(b){b.disabled=false;b.classList.remove('recording');b.textContent='● Record again'}};
    r.start(250);const b=document.getElementById('voice-record-btn');if(b){b.classList.add('recording');b.textContent='■ Stop recording'}
    dlVoiceState.timer=setInterval(()=>{const n=Math.floor((Date.now()-dlVoiceState.start)/1000);const el=document.getElementById('voice-timer');if(el)el.textContent=`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;if(n>=60)stopVoiceNote()},250)
  }catch(e){toast(e?.name==='NotAllowedError'?'Allow microphone access in your browser settings':'Could not start recording. Check your microphone and try again.')}
}
function stopVoiceNote(){const r=dlVoiceState.recorder;if(r&&r.state!=='inactive'){clearInterval(dlVoiceState.timer);try{r.stop()}catch{}const b=document.getElementById('voice-record-btn');if(b){b.classList.remove('recording');b.textContent='Preparing recording…';b.disabled=true;setTimeout(()=>{if(b.isConnected)b.disabled=false},300)}}}
function clearVoiceNote(){const a=document.getElementById('voice-preview');if(a){a.pause();a.removeAttribute('src');if(a.dataset.objectUrl)URL.revokeObjectURL(a.dataset.objectUrl);delete a.dataset.objectUrl;a.load();a.classList.add('hide')}dlVoiceReset();const b=document.getElementById('voice-record-btn');if(b){b.disabled=false;b.classList.remove('recording');b.textContent='● Record voice note'}}
function toggleVoiceRecord(){dlVoiceState.recorder?.state==='recording'?stopVoiceNote():startVoiceNote()}
window.pContact=function(){const st=S.settings||{};return `<div class="page contact-v2-page" style="max-width:700px"><button class="back-link" onclick="goBack()">← Back</button><div class="hero contact-hero-v2"><div class="hero-in"><div class="hero-eyebrow">Support & customer care</div><h1 style="font-size:1.7rem">Contact us</h1><p>Send a message or record a voice note. We'll get back to you.</p></div></div><div class="card form-card contact-card-v2"><div id="ct-msg"></div><div class="frow2"><div class="fgroup"><label class="flabel">Name <span class="req">*</span></label><input class="finput" id="ct-name"></div><div class="fgroup"><label class="flabel">Phone <span class="req">*</span></label><input class="finput" id="ct-phone" type="tel"></div></div><div class="fgroup"><label class="flabel">Message <span class="req">*</span></label><textarea class="ftextarea" id="ct-msg-txt" rows="5" placeholder="Tell us how we can help..."></textarea></div><div class="voice-recorder"><div><div class="voice-rec-title">Voice note</div><div class="voice-rec-sub">Optional · up to 60 seconds</div></div><div class="voice-rec-actions"><button type="button" class="btn btn-ghost btn-sm" id="voice-record-btn" onclick="toggleVoiceRecord()">● Record voice note</button><span class="voice-timer" id="voice-timer">00:00</span></div><audio id="voice-preview" class="voice-audio hide" controls></audio><button type="button" class="voice-clear" onclick="clearVoiceNote()">Clear recording</button></div><button class="btn btn-primary" id="ct-btn" onclick="sendContactV2()">Send message</button></div><div class="card contact-social-v2"><div class="footer-h">Find us online</div><div class="social-icon-row social-icon-row-large">${dlSocialsHTML(st)}</div></div></div>`}
async function sendContactV2(){
  if(dlVoiceState.recorder?.state==='recording'){toast('Stop the voice recording before sending');return}
  const name=document.getElementById('ct-name')?.value.trim();const phone=document.getElementById('ct-phone')?.value.trim();const msg=document.getElementById('ct-msg-txt')?.value.trim();
  if(!name||!phone||!msg){toast('Please fill in your name, phone and message');return}
  if(dlVoiceState.duration>60){toast('Voice note must be 60 seconds or less');return}
  const btn=document.getElementById('ct-btn');btn.disabled=true;btn.innerHTML='<div class="spin"></div>';
  let voicePath=null,voiceMime=null,voiceDuration=null;
  try{
    if(dlVoiceState.blob){const ext=dlVoiceState.mime.includes('ogg')?'ogg':dlVoiceState.mime.includes('mp4')?'m4a':'webm';voicePath=`${crypto.randomUUID()}.${ext}`;voiceMime=dlVoiceState.mime;voiceDuration=dlVoiceState.duration;const up=await sb.storage.from('contact-voice').upload(voicePath,dlVoiceState.blob,{contentType:dlVoiceState.mime,upsert:false});if(up.error)throw up.error}
    const {error}=await sb.from('contact_messages').insert({name,phone,message:msg,voice_path:voicePath,voice_mime:voiceMime,voice_duration_ms:voiceDuration?voiceDuration*1000:null});
    if(error)throw error;
    document.getElementById('ct-msg').innerHTML='<div class="alert alert-ok">Message sent — thank you. We will get back to you soon.</div>';
    document.getElementById('ct-name').value='';document.getElementById('ct-phone').value='';document.getElementById('ct-msg-txt').value='';clearVoiceNote();
  }catch(e){if(voicePath)await sb.storage.from('contact-voice').remove([voicePath]).catch(()=>{});document.getElementById('ct-msg').innerHTML=`<div class="alert alert-err">Could not send the message. ${esc(e.message||'Please try again.')}</div>`}
  btn.disabled=false;btn.textContent='Send message';
}

/* ---------------- Admin messages: voice playback ---------------- */
async function renderAdminMessagesV2(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Messages</div><div class="admin-kicker">Text and voice notes from customers</div></div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('contact_messages').select('*').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock(`Could not load messages: ${error.message||'database error'}`);return}
  window._adminMsgs=data||[];
  await Promise.all((window._adminMsgs||[]).filter(m=>m.voice_path).map(async m=>{await dlRefreshVoiceUrl(m)}));
  drawAdminMessagesV2(main);
}
function dlNormalizeVoicePath(value){
  if(!value)return '';
  let path=String(value).trim();
  try{
    if(/^https?:\/\//i.test(path)){
      const u=new URL(path);
      const marker='/storage/v1/object/';
      const at=u.pathname.indexOf(marker);
      if(at>=0){path=u.pathname.slice(at+marker.length).replace(/^(sign|signed|public|authenticated)\//,'');}
      else return path;
    }
  }catch{}
  path=path.replace(/^\/+/, '').replace(/^contact-voice\//,'');
  return decodeURIComponent(path);
}
async function dlRefreshVoiceUrl(message){
  try{
    const path=dlNormalizeVoicePath(message.voice_path);
    if(/^https?:\/\//i.test(path)){message.voice_url=path;message.voice_error=null;return}
    if(!path)throw new Error('No audio file path is saved for this message');
    const result=await sb.storage.from('contact-voice').createSignedUrl(path,3600);
    if(result.error)throw result.error;
    message.voice_url=result.data?.signedUrl||null;
    message.voice_error=message.voice_url?null:'Storage did not return a playable audio link';
  }catch(e){message.voice_url=null;message.voice_error=e?.message||'Could not create audio link'}
}
window.retryCustomerVoice=async function(id){
  const m=(window._adminMsgs||[]).find(x=>x.id===id);if(!m)return;
  await dlRefreshVoiceUrl(m);
  drawAdminMessagesV2(document.getElementById('admin-main'));
  if(!m.voice_url)toast('Audio link failed: '+(m.voice_error||'check Storage permissions'));
};
function drawAdminMessagesV2(main){
  const list=window._adminMsgs||[];
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Messages</div><div class="admin-kicker">${list.filter(x=>!x.is_read).length} unread · ${list.length} total</div></div><button class="btn btn-ghost btn-sm" onclick="renderAdminMessages(document.getElementById('admin-main'))">↻ Refresh</button></div>${!list.length?adminEmptyBlock('✉','No messages','Contact form submissions will appear here.'): `<div class="admin-message-list">${list.map(m=>`<div class="card admin-message-v2 ${m.is_read?'':'unread'}"><div class="message-row-top"><div><strong>${esc(m.name||'Customer')}</strong><div class="muted-note">${esc(m.phone||'No phone')} · ${m.created_at?new Date(m.created_at).toLocaleString():''}</div></div><span class="state-pill ${m.is_read?'is-off':'is-live'}"><i></i>${m.is_read?'read':'new'}</span></div><div class="message-body">${esc(m.message||'')}</div>${m.voice_path?`<div class="voice-message-box"><div class="voice-message-heading"><span>🎙 Voice note${m.voice_duration_ms?` · ${Math.round(m.voice_duration_ms/1000)}s`:''}</span>${m.voice_url?'<span class="voice-ready">Audio link ready</span>':'<span class="voice-unavailable">Audio link unavailable</span>'}</div>${m.voice_url?`<audio controls preload="metadata" playsinline src="${esc(m.voice_url)}" onerror="this.parentElement.classList.add('audio-failed')"></audio><a class="voice-open-link" href="${esc(m.voice_url)}" target="_blank" rel="noopener noreferrer">Open audio in new tab ↗</a>`:`<small class="voice-audio-error">${esc(m.voice_error||'Could not create a secure audio link. Check the contact-voice bucket and admin read policy.')}</small>`}<button type="button" class="btn btn-ghost btn-sm voice-retry-btn" onclick="retryCustomerVoice('${m.id}')">↻ Refresh audio link</button></div>`:''}<div class="message-actions"><button class="btn btn-ghost btn-sm" onclick="markMsgRead('${m.id}')">${m.is_read?'Mark unread':'Mark read'}</button><button class="btn btn-ghost btn-sm danger-outline" onclick="deleteMsgV2('${m.id}')">Delete</button></div></div>`).join('')}</div>`}`;
}
window.renderAdminMessages=renderAdminMessagesV2;window.drawAdminMessages=drawAdminMessagesV2;
window.markMsgRead=async function(id){const m=(window._adminMsgs||[]).find(x=>x.id===id);if(!m)return;const is_read=!m.is_read;const{error}=await sb.from('contact_messages').update({is_read}).eq('id',id);if(error){toast('Could not update message');return}m.is_read=is_read;drawAdminMessagesV2(document.getElementById('admin-main'))};
async function deleteMsgV2(id){const m=(window._adminMsgs||[]).find(x=>x.id===id);if(!m||!confirm('Delete this message?'))return;if(m.voice_path)await sb.storage.from('contact-voice').remove([m.voice_path]).catch(()=>{});const{error}=await sb.from('contact_messages').delete().eq('id',id);if(error){toast('Could not delete message');return}window._adminMsgs=window._adminMsgs.filter(x=>x.id!==id);drawAdminMessagesV2(document.getElementById('admin-main'))}

/* ---------------- Settings: brand, socials, pages, uploads ---------------- */
async function uploadStoreAsset(file,kind){
  if(!file)return null;
  if(!/^image\//.test(file.type)){toast('Please choose an image file');return null}
  if(file.size>5*1024*1024){toast('Image must be 5MB or less');return null}
  const ext=(file.type.split('/')[1]||'png').replace('jpeg','jpg');const path=`branding/${kind}-${Date.now()}-${Math.random().toString(36).slice(2,7)}.${ext}`;
  const {error}=await sb.storage.from('store-assets').upload(path,file,{contentType:file.type,upsert:false});
  if(error){toast(`Upload failed: ${error.message||'storage error'}`);return null}
  return sb.storage.from('store-assets').getPublicUrl(path).data.publicUrl;
}
async function renderAdminSettingsV2(main){
  main.innerHTML=`<div class="admin-head"><div><div class="admin-title">Store Settings</div><div class="admin-kicker">Brand, social links, page visibility and storefront behavior</div></div></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('settings').select('*').eq('id',1).maybeSingle();if(error||!data){main.innerHTML=adminErrorBlock(`Could not load settings: ${error?.message||'settings row not found'}`);return}
  window._adminSettings=data;drawAdminSettingsV2(main);
}
function drawAdminSettingsV2(main){const s=window._adminSettings||{};const pages={offers:'Offers',wishlist:'Wishlist',orders:'Orders',points:'Points',account:'Account',contact:'Contact'};main.innerHTML=`<div class="settings-layout-v2">
  <div class="settings-col"><div class="card form-card"><div class="panel-kicker">Identity</div><div class="form-title">Store identity</div><div class="branding-upload"><div class="logo-preview">${s.logo_url?`<img src="${esc(s.logo_url)}" alt="">`:'<span>LOGO</span>'}</div><div><strong>Store logo</strong><div class="muted-note">Used in the header, browser tab fallback and invoices.</div><input id="st-logo-file" type="file" accept="image/*" class="finput" style="margin-top:8px;padding:8px"></div></div><div class="frow2"><div class="fgroup"><label class="flabel">Store name</label><input class="finput" id="st-name" value="${esc(s.store_name||'')}"></div><div class="fgroup"><label class="flabel">USD → LBP rate</label><input class="finput" id="st-rate" type="number" value="${s.currency_rate??0}"></div></div><div class="fgroup"><label class="flabel">Favicon / browser icon</label><div class="inline-upload"><div class="favicon-preview">${s.favicon_url?`<img src="${esc(s.favicon_url)}" alt="">`:'◈'}</div><input id="st-fav-file" type="file" accept="image/*" class="finput"></div></div><div class="fgroup"><label class="flabel">Hero title</label><input class="finput" id="st-hero" value="${esc(s.hero_title||'')}"></div><div class="fgroup"><label class="flabel">Hero subtitle</label><textarea class="ftextarea" id="st-sub">${esc(s.hero_subtitle||'')}</textarea></div><div class="fgroup"><label class="flabel">Announcement bar</label><input class="finput" id="st-announce" value="${esc(s.announcement||'')}"></div></div>
  <div class="card form-card"><div class="panel-kicker">Social presence</div><div class="form-title">Accounts shown on the website & invoice</div>${['instagram','facebook','tiktok'].map(t=>`<div class="social-setting"><div class="social-setting-icon">${dlIcon(t)}</div><div class="social-setting-fields"><label class="flabel">${t[0].toUpperCase()+t.slice(1)} URL</label><input class="finput" id="st-${t}-url" value="${esc(s[t+'_url']||'')}" placeholder="https://${t}.com/yourname"><label class="flabel small-gap">Username / page name</label><input class="finput" id="st-${t}-handle" value="${esc(s[t+'_handle']||dlSocialHandle(s[t+'_url'],t))}" placeholder="@yourname"></div></div>`).join('')}<div class="social-setting"><div class="social-setting-icon">${dlIcon('whatsapp')}</div><div class="social-setting-fields"><label class="flabel">WhatsApp number</label><input class="finput" id="st-wa" value="${esc(s.whatsapp_number||'')}"><label class="flabel small-gap">WhatsApp display name</label><input class="finput" id="st-wa-handle" value="${esc(s.whatsapp_handle||'')}" placeholder="WhatsApp / Your support number"></div></div><div class="fgroup"><label class="flabel">Contact email</label><input class="finput" id="st-email" type="email" value="${esc(s.contact_email||'')}"></div></div></div>
  <div class="settings-col"><div class="card form-card"><div class="panel-kicker">Navigation</div><div class="form-title">Page visibility</div><div class="muted-note" style="margin-bottom:12px">Turn pages on or off without deleting their content.</div>${Object.entries(pages).map(([key,label])=>{const on=(s.page_visibility||DL_PAGE_VIS_DEFAULT)[key]!==false;return `<div class="toggle-row"><div><div class="toggle-lbl">${label}</div><div class="toggle-sub">${on?'Visible to customers':'Hidden from customers'}</div></div><label class="switch"><input type="checkbox" class="page-vis-input" data-page="${key}" ${on?'checked':''}><span class="switch-track"></span></label></div>`}).join('')}</div><div class="card form-card"><div class="panel-kicker">Loyalty & cancellation</div><div class="form-title">Commerce settings</div><div class="frow2"><div class="fgroup"><label class="flabel">Points per $</label><input class="finput" id="st-pts" type="number" value="${s.points_per_dollar??0}"></div><div class="fgroup"><label class="flabel">Cancel fee ($)</label><input class="finput" id="st-fee" type="number" value="${s.cancel_fee??0}"></div></div><div class="fgroup"><label class="flabel">Free cancellation window (hours)</label><input class="finput" id="st-hours" type="number" value="${s.free_cancel_hours??24}"></div></div><div class="admin-fab-save"><button class="btn btn-primary" style="width:auto;padding:13px 26px" onclick="saveStoreSettingsV2()">Save everything</button></div><div class="card form-card" style="border-color:var(--danger)"><div class="panel-kicker" style="color:var(--danger)">Danger zone</div><div class="form-title">Delete all system data</div><div class="muted-note" style="margin-bottom:12px">Permanently removes customer accounts, orders, products, settings, messages, and uploaded files. Your current admin account remains.</div><button class="btn btn-danger" onclick="deleteAllSystemData()">Delete all data</button></div></div></div>`}
async function saveStoreSettingsV2(){
  const old=window._adminSettings||{};let logo=old.logo_url||null,fav=old.favicon_url||null;
  const lf=document.getElementById('st-logo-file')?.files?.[0];if(lf)logo=await uploadStoreAsset(lf,'logo');
  const ff=document.getElementById('st-fav-file')?.files?.[0];if(ff)fav=await uploadStoreAsset(ff,'favicon');
  const page_visibility={...DL_PAGE_VIS_DEFAULT};document.querySelectorAll('.page-vis-input').forEach(i=>page_visibility[i.dataset.page]=i.checked);
  const row={store_name:document.getElementById('st-name').value.trim(),currency_rate:parseFloat(document.getElementById('st-rate').value)||0,hero_title:document.getElementById('st-hero').value.trim(),hero_subtitle:document.getElementById('st-sub').value.trim(),announcement:document.getElementById('st-announce').value.trim(),points_per_dollar:parseFloat(document.getElementById('st-pts').value)||0,cancel_fee:parseFloat(document.getElementById('st-fee').value)||0,free_cancel_hours:parseInt(document.getElementById('st-hours').value)||24,whatsapp_number:document.getElementById('st-wa').value.trim(),whatsapp_handle:document.getElementById('st-wa-handle').value.trim()||null,contact_email:document.getElementById('st-email').value.trim(),instagram_url:document.getElementById('st-instagram-url').value.trim(),instagram_handle:document.getElementById('st-instagram-handle').value.trim()||null,facebook_url:document.getElementById('st-facebook-url').value.trim(),facebook_handle:document.getElementById('st-facebook-handle').value.trim()||null,tiktok_url:document.getElementById('st-tiktok-url').value.trim(),tiktok_handle:document.getElementById('st-tiktok-handle').value.trim()||null,logo_url:logo,favicon_url:fav,page_visibility};
  const{error}=await sb.from('settings').update(row).eq('id',1);if(error){toast(`Could not save settings: ${error.message||'database error'}`);return}S.settings={...S.settings,...row};window._adminSettings=S.settings;applySettingsToChrome();dlApplyPageVisibility();toast('Store settings saved');drawAdminSettingsV2(document.getElementById('admin-main'));
}
async function deleteAllSystemData(){
  if(!S.isAdmin||!S.session?.user?.id){toast('Admin access is required');return}
  if(!confirm('This permanently deletes all system data and other accounts, while keeping your current admin account. Continue?'))return;
  if(prompt('Type DELETE ALL DATA to confirm')!=='DELETE ALL DATA'){toast('Deletion cancelled');return}
  const{data,error}=await sb.rpc('delete_all_system_data');
  if(error||!data?.success){console.error(error);toast(`Could not delete system data: ${error?.message||'database error'}`);return}
  localStorage.removeItem('dl_cart');S.cart=[];S.wishlist=[];S.products=[];S.categories=[];S.settings=null;window._adminOrders=[];window._adminProducts=[];window._adminCats=[];
  toast('All system data deleted. Your admin account is still active.');
  resetHome();
}
window.renderAdminSettings=renderAdminSettingsV2;window.drawAdminSettings=drawAdminSettingsV2;

/* ---------------- User block enforcement / hidden pages ---------------- */
const _v2BaseLoadProfile=window.loadProfileAndWishlist;
window.loadProfileAndWishlist=async function(){await _v2BaseLoadProfile();const status=S.profile?.account_status||'enabled';if(status!=='enabled'){await sb.auth.signOut().catch(()=>{});S.session=null;S.profile=null;S.wishlist=[];S.deliveryLocation=null;S.isAdmin=false;toast(status==='banned'?'This account is blocked.':'This account is disabled.');resetHome();}}
const _v2BaseNav=window.nav;
window.nav=function(page,data=null,push=true){if(!dlPageVisible(page)){toast('This page is currently unavailable');return _v2BaseNav('home',null,push)}return _v2BaseNav(page,data,push)};

/* ---------------- Customer order page with invoice action ---------------- */
window.pOrders=async function(){
  if(!S.session){app().innerHTML=authRequiredHTML('view your orders');return}
  app().innerHTML=`<div class="page"><div class="page-heading-v2"><div><div class="eyebrow-mini">Account</div><div class="section-title">My Orders</div></div><span class="heading-mark">▤</span></div><div class="spin spin-dark" style="margin:40px auto;display:block"></div></div>`;
  const{data}=await sb.from('orders').select('*, order_items(*)').eq('user_id',S.session.user.id).order('created_at',{ascending:false});const orders=data||[];
  if(!orders.length){app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button>${adminEmptyBlock('▤','No orders yet','Your orders will show up here.')}<div style="text-align:center"><button class="btn btn-primary btn-sm" onclick="resetHome()">Browse products</button></div></div>`;return}
  app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button><div class="page-heading-v2"><div><div class="eyebrow-mini">Account</div><div class="section-title">My Orders</div></div></div><div class="customer-order-list">${orders.map(o=>`<div class="card order-row-v2"><button class="order-row-main" onclick="nav('order-detail','${o.id}')"><div class="order-icon">▤</div><div class="order-row-copy"><strong>${esc(o.order_number)}</strong><span>${o.order_items?.length||0} item${(o.order_items?.length||0)!==1?'s':''} · ${fmt(o.total)}</span><small>${o.created_at?new Date(o.created_at).toLocaleDateString():''}</small></div><span class="state-pill ${o.status==='delivered'?'is-on':o.status==='cancelled'?'is-off':'is-live'}"><i></i>${esc(dlStatusLabel(o.status))}</span></button><button class="btn btn-ghost btn-sm order-invoice-btn" onclick="printCustomerInvoice('${o.id}')">Print invoice</button></div>`).join('')}</div></div>`;
  S.currentOrder=orders[0];window._customerOrders=orders;
}
function printCustomerInvoice(id){const o=(window._customerOrders||[]).find(x=>x.id===id);if(!o){toast('Invoice not found');return}dlOpenPrint(dlPrintOneDocument(o))}
window.pOrderDetail=async function(){
  app().innerHTML=`<div class="page"><div class="spin spin-dark" style="margin:60px auto;display:block"></div></div>`;
  const{data:o}=await sb.from('orders').select('*, order_items(*)').eq('id',S.data).eq('user_id',S.session?.user?.id||'00000000-0000-0000-0000-000000000000').maybeSingle();if(!o){nav('orders');return}S.currentOrder=o;
  const steps=['pending','confirmed','processing','shipping','delivered'];const cur=steps.indexOf(o.status);const cancelled=o.status==='cancelled';const canCancel=!cancelled&&o.status!=='delivered';
  app().innerHTML=`<div class="page"><button class="back-link" onclick="goBack()">← Back</button><div class="section-head"><div><div class="eyebrow-mini">Order</div><div class="section-title">${esc(o.order_number)}</div></div><span class="state-pill ${o.status==='delivered'?'is-on':o.status==='cancelled'?'is-off':'is-live'}"><i></i>${esc(dlStatusLabel(o.status))}</span></div>${!cancelled?`<div class="card tracking-card-v2"><div class="track-steps">${steps.map((s,i)=>`<div class="track-step"><div class="track-dot ${i<=cur?'done':''}">${i<=cur?'✓':i+1}</div><div class="track-lbl">${s}</div></div>`).join('')}</div></div>`:`<div class="alert alert-err">This order was cancelled.${o.cancel_reason?' Reason: '+esc(o.cancel_reason):''}</div>`}<div class="card form-card order-summary-v2"><div class="invoice-toolbar"><div class="form-title">Order summary</div><button class="btn btn-primary btn-sm" onclick="printCustomerInvoice('${o.id}')">Print invoice</button></div>${o.order_items.map(i=>`<div class="summary-row"><span>${esc(i.product_name)}${i.is_bundle?' ('+esc(i.bundle_label)+')':''} × ${i.quantity}</span><span>${fmt(i.unit_price*i.quantity)}</span></div>`).join('')}<div class="summary-row"><span>Subtotal</span><span>${fmt(o.subtotal)}</span></div>${o.discount_amount>0?`<div class="summary-row invoice-discount-row"><span>Discount${o.coupon_code?' · '+esc(o.coupon_code):''}</span><span>-${fmt(o.discount_amount)}</span></div>`:''}<div class="summary-row"><span>Delivery</span><span>${fmt(o.delivery_fee)}</span></div><div class="summary-row total"><span>Total</span><span>${fmt(o.total)}</span></div></div><div class="card form-card"><div class="form-title">Delivery details</div><div class="detail-list-v2"><div><span>Name</span><strong>${esc(o.full_name)}</strong></div><div><span>Phone</span><strong>${esc(o.phone)}</strong></div><div><span>Address</span><strong>${esc(o.city||'')}${o.district?`, ${esc(o.district)}`:''} — ${esc(o.full_address||'')}</strong></div>${o.floor?`<div><span>Floor</span><strong>${esc(o.floor)}</strong></div>`:''}</div></div>${canCancel?`<button class="btn btn-danger" onclick="cancelOrder('${esc(o.id)}','${esc(o.created_at)}')">Cancel order</button>`:''}</div>`;
}

/* ---------------- Chrome / animations ---------------- */
const _v2BaseApply=window.applySettingsToChrome;
window.applySettingsToChrome=function(){_v2BaseApply();dlRefreshBrandChrome();dlApplyPageVisibility();
  const st=S.settings||{};const soc=dlSocialsHTML(st);const f=document.getElementById('footer-soc');const d=document.getElementById('drawer-soc');if(f)f.innerHTML=soc;if(d)d.innerHTML=soc;
  const wa=st.whatsapp_number?`https://wa.me/${st.whatsapp_number.replace(/\D/g,'')}?text=${encodeURIComponent('مرحبا، بدي استفسر عن منتجاتكم.')}`:'';if(wa)document.querySelectorAll('[data-whatsapp-link]').forEach(a=>a.href=wa)
}
