/* AI image attachment: keeps images client-side until the AI request. */
let aiPendingImages=[];

/* Keep AI image requests small enough for browser/serverless request limits. */
async function aiPrepareImage(file){
  if(!file||!file.type.startsWith('image/'))throw new Error('invalid_image');
  if(file.size>8*1024*1024)throw new Error('image_too_large');
  const dataUrl=await new Promise((resolve,reject)=>{
    const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);
  });
  const img=await new Promise((resolve,reject)=>{
    const el=new Image();el.onload=()=>resolve(el);el.onerror=reject;el.src=dataUrl;
  });
  const maxSide=1280;
  const scale=Math.min(1,maxSide/Math.max(img.naturalWidth||img.width,img.naturalHeight||img.height));
  const canvas=document.createElement('canvas');
  canvas.width=Math.max(1,Math.round((img.naturalWidth||img.width)*scale));
  canvas.height=Math.max(1,Math.round((img.naturalHeight||img.height)*scale));
  canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);
  let quality=0.78, out=canvas.toDataURL('image/jpeg',quality);
  while(out.length>1_200_000&&quality>0.5){
    quality-=0.08;out=canvas.toDataURL('image/jpeg',quality);
  }
  if(out.length>1_500_000)throw new Error('image_too_large');
  return {name:file.name,type:'image/jpeg',dataUrl:out};
}
function aiHandleImages(event){
  const files=Array.from(event.target.files||[])
    .filter(f=>f.type.startsWith('image/')).slice(0,4);
  if(!files.length)return;
  Promise.all(files.map(aiPrepareImage)).then(items=>{
    const total=items.reduce((n,x)=>n+x.dataUrl.length,0);
    if(total>4_500_000)throw new Error('images_too_large');
    aiPendingImages=items;
    toast(`${items.length} image${items.length>1?'s':''} attached`);
    renderAiBody();
  }).catch(e=>{
    console.error('AI image preparation failed:',e);
    toast('الصورة كبيرة أو غير صالحة. جرّب صورة أصغر.');
    aiPendingImages=[];
  });
}

/* Patch AI call to include attached images without exposing provider keys. */
const _dashOriginalAiCallEdge=window.aiCallEdge;
window.aiCallEdge=async function(text){
  if(!aiPendingImages.length)return _dashOriginalAiCallEdge(text);
  const originalInvoke=sb.functions.invoke.bind(sb.functions);
  // The existing AI function accepts JSON. We temporarily wrap invoke so the original function receives images.
  sb.functions.invoke=async function(name,opts){
    if(name===AI_FUNCTION_NAME && opts?.body){opts={...opts,body:{...opts.body,images:aiPendingImages.map(x=>({type:x.type,dataUrl:x.dataUrl}))}}}
    return originalInvoke(name,opts);
  };
  try{return await _dashOriginalAiCallEdge(text)}finally{sb.functions.invoke=originalInvoke;aiPendingImages=[];const input=document.getElementById('ai-image-input');if(input)input.value='';}
};

