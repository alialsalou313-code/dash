/* =========================================================
   GROWTH FEATURES — COUPONS + PROMOTIONS ADMIN
========================================================= */
function growthAdminNav(){
  return `${adminNavBtn('coupons','🎟 Coupons & Offers')}`;
}

/* Re-declare admin shell so the new section is visible. */
function pAdmin(){
  app().innerHTML=`<div class="admin-shell">
    <div class="admin-sidebar">
      <div class="admin-sidebar-title">Dashboard</div>
      ${adminNavBtn('overview','📊 Overview')}
      ${adminNavBtn('orders','📦 Orders')}
      ${adminNavBtn('products','🏷 Products')}
      ${adminNavBtn('categories','🗂 Categories')}
      ${adminNavBtn('reviews','⭐ Reviews')}
      ${adminNavBtn('messages','✉ Messages')}
      <div class="admin-sidebar-title" style="margin-top:10px">Growth</div>
      ${growthAdminNav()}
      <div class="admin-sidebar-title" style="margin-top:10px">Configuration</div>
      ${adminNavBtn('ai','✨ إعدادات الذكاء الاصطناعي')}
      ${adminNavBtn('settings','⚙ Store Settings')}
    </div>
    <div class="admin-main" id="admin-main">${skeletonAdminBlock()}</div>
  </div>`;
  loadAdminSection(S.adminSection||'overview');
}

/* Extend the original dispatcher with the new coupon section. */
const _growthOriginalLoadAdminSection=window.loadAdminSection;
window.loadAdminSection=async function(id){
  if(id==='coupons') return renderAdminCoupons(document.getElementById('admin-main'));
  return _growthOriginalLoadAdminSection(id);
};

async function renderAdminCoupons(main){
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Coupons & Offers</div><button class="btn btn-primary btn-sm" onclick="openCouponModal()">+ New coupon</button></div>${skeletonAdminBlock()}`;
  const{data,error}=await sb.from('coupons').select('*').order('created_at',{ascending:false});
  if(error){main.innerHTML=adminErrorBlock('Could not load coupons. Run the supplied SQL first.');return}
  window._adminCoupons=data||[];
  drawAdminCoupons(main);
}
function drawAdminCoupons(main){
  const list=window._adminCoupons||[];
  main.innerHTML=`<div class="admin-head"><div class="admin-title">Coupons & Offers</div><button class="btn btn-primary btn-sm" onclick="openCouponModal()">+ New coupon</button></div>
  <div class="muted-note" style="margin-bottom:12px">Create percentage or fixed-amount discounts, minimum order values, start/end dates, and per-user usage limits. Rules are enforced server-side.</div>
  ${!list.length?adminEmptyBlock('🎟','No coupons yet','Create your first promotion.'):`
  <div class="card admin-table-wrap"><table class="admin-table"><tr><th>Code</th><th>Discount</th><th>Minimum</th><th>Uses</th><th>Dates</th><th>Status</th><th></th></tr>
  ${list.map(c=>{
    const active=!!c.is_active && (!c.expires_at||new Date(c.expires_at)>new Date()) && (!c.starts_at||new Date(c.starts_at)<=new Date());
    const d=c.discount_type==='percent'?`${c.discount_value}%`:`${fmt(c.discount_value)}`;
    return `<tr><td class="mono"><strong>${esc(c.code)}</strong><div style="font-size:.72rem;color:var(--muted)">${esc(c.description||'')}</div></td><td>${d}</td><td>${fmt(c.min_subtotal||0)}</td><td>${c.used_count||0}${c.max_uses?` / ${c.max_uses}`:''}</td><td style="font-size:.72rem">${c.starts_at?new Date(c.starts_at).toLocaleDateString():'Now'} → ${c.expires_at?new Date(c.expires_at).toLocaleDateString():'∞'}</td><td><span class="status-badge ${active?'st-approved':'st-cancelled'}">${active?'Active':'Off'}</span></td><td style="text-align:right;white-space:nowrap"><button class="btn btn-ghost btn-sm" onclick="openCouponModal('${c.id}')">Edit</button> <button class="btn btn-ghost btn-sm" onclick="toggleCoupon('${c.id}',${!c.is_active})">${c.is_active?'Disable':'Enable'}</button></td></tr>`;
  }).join('')}</table></div>`}`;
}
function openCouponModal(id){
  const c=id?(window._adminCoupons||[]).find(x=>x.id===id):null;
  const iso=v=>v?new Date(v).toISOString().slice(0,16):'';
  document.getElementById('modal-root').innerHTML=`<div class="modal-ov" onclick="closeModal(event)"><div class="modal-sheet" onclick="event.stopPropagation()" style="max-width:540px">
    <div class="modal-handle"></div><div class="modal-title">${c?'Edit coupon':'New coupon'}</div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Code *</label><input class="finput" id="cp-code" maxlength="40" value="${esc(c?.code||'')}" placeholder="DASH20"></div><div class="fgroup"><label class="flabel">Type</label><select class="fselect" id="cp-type"><option value="percent" ${c?.discount_type==='percent'||!c?'selected':''}>Percentage</option><option value="fixed" ${c?.discount_type==='fixed'?'selected':''}>Fixed amount</option></select></div></div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Discount *</label><input class="finput" id="cp-value" type="number" step="0.01" min="0" value="${c?.discount_value??''}"></div><div class="fgroup"><label class="flabel">Minimum order</label><input class="finput" id="cp-min" type="number" step="0.01" min="0" value="${c?.min_subtotal??0}"></div></div>
    <div class="fgroup"><label class="flabel">Description</label><input class="finput" id="cp-desc" maxlength="160" value="${esc(c?.description||'')}" placeholder="20% off your order"></div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Starts</label><input class="finput" id="cp-start" type="datetime-local" value="${iso(c?.starts_at)}"></div><div class="fgroup"><label class="flabel">Expires</label><input class="finput" id="cp-end" type="datetime-local" value="${iso(c?.expires_at)}"></div></div>
    <div class="frow2"><div class="fgroup"><label class="flabel">Max total uses</label><input class="finput" id="cp-max" type="number" min="1" value="${c?.max_uses??''}" placeholder="Unlimited"></div><div class="fgroup"><label class="flabel">Max uses / customer</label><input class="finput" id="cp-usermax" type="number" min="1" value="${c?.max_uses_per_user??''}" placeholder="Unlimited"></div></div>
    <label style="display:flex;align-items:center;gap:9px;margin:8px 0 14px"><input id="cp-active" type="checkbox" ${c?.is_active!==false?'checked':''}> Active</label>
    <button class="btn btn-primary" onclick="saveCoupon('${c?.id||''}')">Save coupon</button>
  </div></div>`;
}
async function saveCoupon(id){
  const code=document.getElementById('cp-code').value.trim().toUpperCase().replace(/\s+/g,'');
  const type=document.getElementById('cp-type').value;
  const value=parseFloat(document.getElementById('cp-value').value);
  const min=parseFloat(document.getElementById('cp-min').value)||0;
  if(!/^[A-Z0-9_-]{3,40}$/.test(code)||!(value>0)){toast('Enter a valid code and discount');return}
  if(type==='percent'&&value>100){toast('Percentage cannot exceed 100');return}
  const payload={
    code,
    discount_type:type,
    discount_value:value,
    min_subtotal:min,
    description:document.getElementById('cp-desc').value.trim()||null,
    starts_at:document.getElementById('cp-start').value?new Date(document.getElementById('cp-start').value).toISOString():null,
    expires_at:document.getElementById('cp-end').value?new Date(document.getElementById('cp-end').value).toISOString():null,
    max_uses:parseInt(document.getElementById('cp-max').value)||null,
    max_uses_per_user:parseInt(document.getElementById('cp-usermax').value)||null,
    is_active:document.getElementById('cp-active').checked
  };
  if(payload.expires_at&&payload.starts_at&&new Date(payload.expires_at)<=new Date(payload.starts_at)){toast('Expiry must be after start');return}

  const{data,error}=await sb.rpc('admin_save_coupon',{p_id:id||null,p_coupon:payload});
  if(error){
    console.error('admin_save_coupon',error);
    const detail=[error.code,error.message,error.details,error.hint].filter(Boolean).join(' — ');
    toast(error.code==='23505'?'Coupon code already exists':`Could not save coupon: ${detail||'database error'}`);
    return;
  }
  if(!data){toast('Could not save coupon: no response from database');return}
  closeModal();toast('Coupon saved');await renderAdminCoupons(document.getElementById('admin-main'));
}
async function toggleCoupon(id,active){
  const{data,error}=await sb.rpc('admin_toggle_coupon',{p_id:id,p_active:active});
  if(error){
    console.error('admin_toggle_coupon',error);
    const detail=[error.code,error.message,error.details,error.hint].filter(Boolean).join(' — ');
    toast(`Could not update coupon: ${detail||'database error'}`);
    return;
  }
  const c=(window._adminCoupons||[]).find(x=>x.id===id);if(c)c.is_active=active;drawAdminCoupons(document.getElementById('admin-main'));toast(active?'Coupon enabled':'Coupon disabled');
}
