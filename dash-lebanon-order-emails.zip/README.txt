Deploy index.html and its accompanying "Dash Lebanon _ Everyday products, delivered fast._files" folder at the site publish root.
WhatsApp chat buttons open your configured number with the Arabic greeting prefilled. The customer must tap Send in WhatsApp.
Run the separate product-costs-and-delete-all-data.sql file in Supabase SQL Editor for the earlier store changes; it is intentionally outside this ZIP.


Order email setup: The separate setup files order-email-notifications.sql and order-email-function.ts are supplied alongside this ZIP; apply the SQL in Supabase SQL Editor and deploy the TypeScript file as Supabase Edge Function order-email; add RESEND_API_KEY, RESEND_FROM_EMAIL, and ORDER_EMAIL_WEBHOOK_SECRET as Edge Function secrets; then create a Database Webhook on public.orders for INSERT and UPDATE with header x-order-email-secret. The function skips updates where status did not change.
